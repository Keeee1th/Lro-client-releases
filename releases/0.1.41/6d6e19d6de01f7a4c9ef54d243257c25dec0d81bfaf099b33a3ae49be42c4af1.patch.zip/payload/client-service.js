/**
 * 仙境传说 网页客户端 · 本机客户端服务（单文件 / 零第三方依赖）
 *
 * 干什么：
 *   1) 本机页面服务：把启动器和客户端放在 http://127.0.0.1:<页面端口>/ 下，只监听本机
 *   2) 反向代理：把 /client_re/* 等请求转发到官方 https://game.lastro.cn，绕开浏览器跨域限制
 *   3) WS→TCP 桥：浏览器连 ws://127.0.0.1:<桥端口>/<目标IP:端口>，客户端服务用原生 TCP 连过去
 *
 * 用法：node client-service.js [-p 8971] [-b 5999]
 * 安全：只监听 127.0.0.1；桥只允许白名单目标，不会被当成公共代理。
 */
'use strict';

const http = require('http');
const net = require('net');
const os = require('os');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const childProcess = require('child_process');
const { pathToFileURL } = require('url');
const accountTransfer = require('./account-transfer');

/* ---------------- 参数 ---------------- */
const argv = process.argv.slice(2);
function argOf(flag, def) {
  const i = argv.indexOf(flag);
  return i >= 0 && argv[i + 1] ? argv[i + 1] : def;
}
const PAGE_PORT = Number(argOf('-p', process.env.ROE_PAGE_PORT || 8971));
const BRIDGE_PORT = Number(argOf('-b', process.env.ROE_BRIDGE_PORT || 5999));
/* 桥拨号超时：服务器不可达时必须在有限时间内失败并释放连接，不能把页面永久挂在「连接中」。 */
const BRIDGE_DIAL_TIMEOUT_MS = Math.max(100, Number(process.env.ROE_BRIDGE_DIAL_TIMEOUT_MS || 12000));
/* 上游基址可用 ROE_UPSTREAM 覆盖：便于把反代临时指向镜像/黑洞做「上游不可达」验收，默认仍是官方服务器。 */
const UPSTREAM_RAW = String(process.env.ROE_UPSTREAM || 'https://game.lastro.cn');
const UPSTREAM = UPSTREAM_RAW.charAt(UPSTREAM_RAW.length - 1) === '/' ? UPSTREAM_RAW.slice(0, -1) : UPSTREAM_RAW;
/* 本地路径 → 上游路径 映射（官方资源都在 /ro/ 下） */
const PREFIX_MAP = [
  ['/client_re/', '/ro/client_re/'],
  ['/statics/', '/ro/statics/'],
  ['/ro/', '/ro/']
];

/* 本地中文覆盖：官方数据是韩文(CP949)或中韩混合，按 GBK 解会乱码；
   物品名/说明/技能说明/地图名表改用无头端中文数据（client_re/data/ 下本地文件） */
const ITEM_TXT_OVERRIDES = [
  'data/num2itemdisplaynametable.txt',
  'data/idnum2itemdisplaynametable.txt',
  'data/num2itemdesctable.txt',
  'data/idnum2itemdesctable.txt',
  'data/skilldesctable.txt',
  'data/mapnametable.txt',
  'data/num2itemresnametable.txt',
  'data/idnum2itemresnametable.txt'
];

/* 便携路径的静默证据：登记本进程真实拉起过的客户端浏览器 pid。
   独立执行体 client-update-apply.mjs 会自己核对这些 pid 是否确实退出，所以「服务说没会话」不是唯一依据。 */
const clientSessionPids = new Set();
function liveSessionPids() {
  const alive = [];
  clientSessionPids.forEach(function (pid) { try { process.kill(pid, 0); alive.push(pid); } catch (e) { clientSessionPids.delete(pid); } });
  return alive;
}

const ROOT = __dirname;
// Update authority is minted for this helper instance and only served to its same-origin launcher.
const UPDATE_ORIGIN = 'http://127.0.0.1:' + PAGE_PORT;
const UPDATE_SESSION = crypto.randomBytes(32).toString('hex');
/* 更新宿主：原生启动器注入 NATIVE_AUTHORITY 时才交出可信生命周期，否则保持 fail-closed。
   落盘替换由独立进程 client-update-apply.mjs 执行（替换目标含本进程正在加载的文件），
   本进程随即让位退出，替换成功后由权威通道重启启动器。 */
const updateLifecycle = require('./client-update-authority').createLifecycle({
  env: process.env, root: ROOT, nodePath: process.execPath,
  applierPath: path.join(ROOT, 'client-update-apply.mjs'), pid: process.pid,
  spawn: childProcess.spawn, exit: function () { setTimeout(function () { try { process.exit(0); } catch (e) { /* ignore */ } }, 300); },
  /* 便携包（启动客户端.cmd）显式置 ROE_PORTABLE_APPLY=1；原生启动器走权威通道，两条路互斥。 */
  portable: process.env.ROE_PORTABLE_APPLY === '1', sessions: { pids: liveSessionPids },
  /* 更新恢复要把本服务重新拉起来，所以端口与服务文件名由本进程给出，执行体不猜路径。 */
  pagePort: PAGE_PORT, bridgePort: BRIDGE_PORT, serviceFile: path.basename(__filename)
});
const clientUpdates = require('./client-update-host').createUpdateHost({root:ROOT,token:UPDATE_SESSION,origin:UPDATE_ORIGIN,lifecycle:updateLifecycle,configFile: () => CLIENT_UPDATE_CONFIG_FILE});

/* ---------------- 本地中文覆盖硬化（防乱码静默回源） ----------------
   上游官方物品文本表是韩文 EUC-KR，客户端按 GBK 解 → 乱码；包内 client_re/data/ 是中文表。
   覆盖判定必须让「同一个资源的各种等价写法」全部命中（浏览器 / 反代会送大小写、%2F、%2E、
   双斜杠、尾随空格、/ro 前缀…）。命中后：
     · 本地有中文表 → 直供（cache-control: no-store，绝不让浏览器缓存）；
     · 本地缺失 / 为空 → 502 硬失败 LOCAL_OVERLAY_MISSING，绝不静默回源上游韩文。 */
const OVERLAY_REQUEST_PREFIX = '/client_re/';
/* 包内中文表目录；ROE_OVERLAY_DIR 仅供自动化测试换根，默认就是包内 client_re。 */
const OVERLAY_LOCAL_DIR = process.env.ROE_OVERLAY_DIR ? path.resolve(process.env.ROE_OVERLAY_DIR) : path.join(ROOT, 'client_re');
const ITEM_TXT_OVERRIDE_MAP = new Map();
ITEM_TXT_OVERRIDES.forEach(function (tail) { ITEM_TXT_OVERRIDE_MAP.set(tail.toLowerCase(), tail); });

/* 归一化「未解码的请求路径」→ `/client_re/<tail>` 形式的规范路径；不适用返回 null。
   顺序（与验收用例一一对应）：
     ① decodeURIComponent —— 失败按「不命中」处理，绝不抛
     ② 折叠重复 /        ③ 消掉 /./ 段        ④ 去尾部空白与尾部点
     ⑤ 去可选 /ro 前缀   ⑥ 只保留 /client_re/ 之后的 tail 参与白名单比对 */
function normalizeClientRePath(rawPath) {
  if (typeof rawPath !== 'string' || !rawPath) return null;
  let s;
  try { s = decodeURIComponent(rawPath); } catch (e) { return null; } /* 编码坏掉 = 不命中 */
  s = s.replace(/\/{2,}/g, '/');
  s = s.replace(/\/\.\//g, '/');
  s = s.replace(/\/\.$/, '/');
  s = s.replace(/[.\s]+$/, ''); /* 尾随空白（table.txt%20）与尾随点（table.txt.）一起归一 */
  if (s === '/ro') s = '/';
  else if (s.indexOf('/ro/') === 0) s = s.slice('/ro'.length);
  if (s.indexOf(OVERLAY_REQUEST_PREFIX) !== 0) return null;
  return s;
}

/* 覆盖白名单判定：返回白名单里的规范 tail（大小写不敏感），不是白名单返回 null。 */
function overlayTailOf(rawPath) {
  const normalized = normalizeClientRePath(rawPath);
  if (normalized === null) return null;
  const canonical = ITEM_TXT_OVERRIDE_MAP.get(normalized.slice(OVERLAY_REQUEST_PREFIX.length).toLowerCase());
  return canonical === undefined ? null : canonical;
}

/* 覆盖白名单 tail → 包内绝对路径；非白名单 / 越界返回 null。 */
function overlayLocalPath(tail, baseDir) {
  const canonical = typeof tail === 'string' ? ITEM_TXT_OVERRIDE_MAP.get(tail.toLowerCase()) : undefined;
  if (canonical === undefined) return null;
  const base = baseDir ? path.resolve(baseDir) : OVERLAY_LOCAL_DIR;
  const full = path.resolve(base, canonical);
  return full.indexOf(base + path.sep) === 0 ? full : null;
}

/* 覆盖表直供。命中 → 本地中文表（no-store）；缺失 / 空 → 502 LOCAL_OVERLAY_MISSING，
   并 console.error 一行（含 tail 与期望文件）—— 绝不代理上游（上游那份是韩文 = 乱码）。 */
function serveOverlayText(req, res, tail, rawPath, baseDir) {
  const full = overlayLocalPath(tail, baseDir);
  let st = null;
  if (full) { try { st = fs.statSync(full); } catch (e) { st = null; } }
  if (!full || !st || !st.isFile() || st.size <= 0) {
    const expected = full || path.join((baseDir ? path.resolve(baseDir) : OVERLAY_LOCAL_DIR), tail);
    console.error('[OVERLAY-MISSING] ' + tail + ' 本地中文表缺失或为空，期望文件 ' + expected + '（请求 ' + String(rawPath) + '）');
    const body = Buffer.from('LOCAL_OVERLAY_MISSING ' + tail + '\n', 'utf8');
    res.writeHead(502, {
      'content-type': 'text/plain; charset=utf-8', 'content-length': body.length,
      'cache-control': 'no-store', 'x-roe-overlay': 'local-missing', 'x-roe-overlay-tail': tail,
      'access-control-allow-origin': '*'
    });
    if (req.method === 'HEAD') return res.end();
    return res.end(body);
  }
  res.writeHead(200, {
    'content-type': 'text/plain; charset=gbk', 'content-length': st.size,
    'cache-control': 'no-store', 'x-roe-overlay': 'local-zh', 'x-roe-overlay-tail': tail,
    'access-control-allow-origin': '*'
  });
  if (req.method === 'HEAD') return res.end();
  return fs.createReadStream(full).pipe(res);
}

/* ---------------- 覆盖自检（启动横幅 + /health + 验收） ----------------
   校验 8 张中文表：存在、非空、GBK 可解码；抽查 4040 → 克瑞米卡片、501 → 红色药水。
   另比对「已知上游韩文 sha256 前缀」：本地表撞上它就是泄漏（把上游韩文表误当本地中文表）。 */
const OVERLAY_KR_SHA_PREFIX = {
  'data/num2itemdisplaynametable.txt': '9f0b773015d9d446',
  'data/idnum2itemdisplaynametable.txt': '4879fdef810a61d9',
  'data/num2itemdesctable.txt': 'f2509bb6',
  'data/idnum2itemdesctable.txt': '781ad693'
};
/* 本包中文表的参考 sha256（前 16）：只用于提示「与验收基线是否一致」，不影响 ok。 */
const OVERLAY_REFERENCE_SHA_PREFIX = {
  'data/num2itemdisplaynametable.txt': '49676b9b4de770a4',
  'data/idnum2itemdisplaynametable.txt': 'e7986197ba9046ff',
  'data/num2itemdesctable.txt': '25069bfa',
  'data/idnum2itemdesctable.txt': 'c0d401e8b6156403'
};
const OVERLAY_SHA_TAIL = 'data/idnum2itemdisplaynametable.txt'; /* 抽查物品名用这张表 */
const OVERLAY_PROBES = [['4040', '克瑞米卡片'], ['501', '红色药水']];
let overlayGbkFatalDecoder = null;
let overlayGbkPlainDecoder = null;
let overlayGbkAvailable = null;
function gbkDecoders() {
  if (overlayGbkAvailable === null) {
    try {
      overlayGbkFatalDecoder = new TextDecoder('gbk', { fatal: true });
      overlayGbkPlainDecoder = new TextDecoder('gbk');
      overlayGbkAvailable = true;
    } catch (e) { overlayGbkAvailable = false; }
  }
  return overlayGbkAvailable;
}
/* 返回 { ok, missing, empty, errors, leaked, shaMismatch, sha, sha256, probes, gbkChecked } */
function scanOverlayTables(baseDir) {
  const base = baseDir ? path.resolve(baseDir) : OVERLAY_LOCAL_DIR;
  const missing = [], empty = [], errors = [], leaked = [], shaMismatch = [];
  const sha = {}, sha256 = {};
  let nameTable = '';
  ITEM_TXT_OVERRIDES.forEach(function (tail) {
    const file = path.join(base, tail);
    let buf = null;
    try { buf = fs.readFileSync(file); } catch (e) { buf = null; }
    if (!buf) { missing.push(tail); return; }
    if (!buf.length) { empty.push(tail); return; }
    let hex;
    try { hex = crypto.createHash('sha256').update(buf).digest('hex'); } catch (e) { hex = ''; }
    sha256[tail] = hex;
    sha[tail] = hex.slice(0, 16);
    const kr = OVERLAY_KR_SHA_PREFIX[tail];
    if (kr && hex.indexOf(kr) === 0) leaked.push(tail);
    const ref = OVERLAY_REFERENCE_SHA_PREFIX[tail];
    if (ref && hex.indexOf(ref) !== 0) shaMismatch.push(tail);
    if (gbkDecoders()) {
      try { overlayGbkFatalDecoder.decode(buf); } catch (e) { errors.push(tail); }
    }
    if (tail === OVERLAY_SHA_TAIL && gbkDecoders()) {
      try { nameTable = overlayGbkPlainDecoder.decode(buf); } catch (e2) { nameTable = ''; }
    }
  });
  const got = {};
  let probesOk = true;
  OVERLAY_PROBES.forEach(function (pair) {
    const m = new RegExp('(?:^|\\n)' + pair[0] + '#([^#\\r\\n]*)#').exec(nameTable);
    got[pair[0]] = m ? m[1] : null;
    if (!m || m[1] !== pair[1]) probesOk = false;
  });
  const gbkChecked = gbkDecoders();
  const bad = missing.concat(empty);
  return {
    ok: bad.length === 0 && errors.length === 0 && leaked.length === 0 && probesOk,
    dir: base,
    missing: bad, empty: empty, errors: errors, leaked: leaked, shaMismatch: shaMismatch,
    sha: sha, sha256: sha256, gbkChecked: gbkChecked,
    probes: { ok: probesOk, expected: { '4040': OVERLAY_PROBES[0][1], '501': OVERLAY_PROBES[1][1] }, got: got }
  };
}
let overlayStatusCache = null;
function overlaySelfCheck() {
  if (!overlayStatusCache) overlayStatusCache = scanOverlayTables(OVERLAY_LOCAL_DIR);
  return overlayStatusCache;
}

/* 覆盖白名单表的缓存条目一律删除：上游那份是韩文，留着就是乱码定时炸弹
   （2026-10-02 --prewarm 曾把这批表整批回源写进 .ro-cache）。返回删除条数。 */
function purgeOverlayCacheEntries() {
  const victims = [];
  cacheIndex.forEach(function (entry, key) { if (overlayTailOf(key)) victims.push(key); });
  let removed = 0;
  victims.forEach(function (key) {
    const entry = cacheIndex.get(key);
    try { fs.unlinkSync(entry.file); } catch (e) {}
    cacheIndex.delete(key);
    cacheStats.bytes -= entry.size;
    removed++;
    cacheDirty = true;
  });
  if (removed) {
    cacheStats.files = cacheIndex.size;
    log('覆盖缓存清理：删除 ' + removed + ' 条白名单表的缓存条目（上游是韩文，命中即乱码）');
    try { cachePersist(); } catch (e) {}
  }
  return removed;
}

const UI_SKIN_VARIANTS = [
  'Aurora Age', 'Aurora Age - Aqua', 'Aurora Age - Brown', 'Aurora Age - Dark Gray',
  'Aurora Age - Gray', 'Aurora Age - Green', 'Aurora Age - Indigo', 'Aurora Age - Lucid',
  'Aurora Age - Orange', 'Aurora Age - Pink', 'Aurora Age - Purity', 'Aurora Age - Purple',
  'Aurora Age - Raspberry', 'Aurora Age - Sky Blue', 'Aurora Age - YoRHa'
];
/* 皮肤目录逐级解析（前一级没有再看下一级；都没有 = null）：
     ① ROE_SKIN_DIR 环境变量（部署 / 验收用，只由命令行设置，不写进源码）
     ② 包内 ROOT/skin/<变体>（随包分发，解压到任何目录都自给自足）
     ③ 使用者本机配置文件 skin-root.txt（与 ui-skin.json 同目录，一行目录路径；
        使用者本机数据，不随包分发，也不经静态目录对外提供）
     ④ 都没有 → null（= 官方默认素材，贴图全部回源 LastRO，不覆盖）
   源码里不留任何作者本机路径，日志也不打印这些目录。 */
const PACKAGE_SKIN_DIR = path.join(ROOT, 'skin');
const ENV_SKIN_ROOT = process.env.ROE_SKIN_DIR ? path.resolve(process.env.ROE_SKIN_DIR) : null;
/* 兼容旧导出名 PACKAGE_SKIN_ROOT：环境变量优先，否则包内 skin 目录 */
const PACKAGE_SKIN_ROOT = ENV_SKIN_ROOT || PACKAGE_SKIN_DIR;
const UI_SKIN_STATE_FILE = path.join(ROOT, 'ui-skin.json');
/* 使用者本机皮肤根配置文件：第一行有效行是目录路径（'#' 开头为注释，可加引号）。
   默认与 ui-skin.json 同目录；路径可用 ROE_SKIN_ROOT_FILE 覆盖（自动化测试用）。 */
const SKIN_ROOT_FILE = process.env.ROE_SKIN_ROOT_FILE ? path.resolve(process.env.ROE_SKIN_ROOT_FILE) : path.join(ROOT, 'skin-root.txt');
function skinDirectoryUnder(root, name) {
  const directory = path.resolve(root, name);
  const prefix = path.resolve(root) + path.sep;
  return directory.startsWith(prefix) ? directory : null;
}
/* 读使用者配置文件里的第一个有效路径；文件缺失 / 空行 / 只有注释都返回 null。
   相对路径按配置文件所在目录解析。 */
function userSkinRoot() {
  let text;
  try { text = fs.readFileSync(SKIN_ROOT_FILE, 'utf8'); } catch (e) { return null; }
  const lines = String(text).split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    let line = lines[i].trim();
    if (!line || line.charAt(0) === '#') continue;
    const first = line.charAt(0), last = line.charAt(line.length - 1);
    if (line.length > 1 && ((first === '"' && last === '"') || (first === "'" && last === "'"))) {
      line = line.slice(1, -1).trim();
    }
    if (!line) continue;
    try { return path.resolve(path.dirname(SKIN_ROOT_FILE), line); } catch (e) { return null; }
  }
  return null;
}
/* 候选皮肤根，按优先级排：环境变量 → 包内 → 使用者配置文件（同一路径只留一次）。 */
function uiSkinRoots() {
  const roots = [];
  const candidates = [ENV_SKIN_ROOT, PACKAGE_SKIN_DIR, userSkinRoot()];
  for (let i = 0; i < candidates.length; i++) {
    if (!candidates[i]) continue;
    let resolved;
    try { resolved = path.resolve(candidates[i]); } catch (e) { continue; }
    if (roots.indexOf(resolved) >= 0) continue;
    roots.push(resolved);
  }
  return roots;
}
/* 命中返回该候选根下的真实目录；全都没命中返回 null（null = 官方默认素材，不覆盖） */
function uiSkinDirectory(name) {
  if (!UI_SKIN_VARIANTS.includes(name)) return null;
  const roots = uiSkinRoots();
  for (let i = 0; i < roots.length; i++) {
    const directory = skinDirectoryUnder(roots[i], name);
    if (!directory) continue;
    try {
      if (fs.statSync(directory).isDirectory()) return directory;
    } catch (e) {}
  }
  return null;
}
function loadUiSkin() {
  try {
    const selected = JSON.parse(fs.readFileSync(UI_SKIN_STATE_FILE, 'utf8')).skin;
    const directory = uiSkinDirectory(selected);
    if (directory && fs.existsSync(directory)) return selected;
  } catch (e) {}
  return 'Aurora Age';
}
let currentUiSkin = loadUiSkin();

/* 用户本机 ROui Aurora Age 本地素材；按白名单变体读取，未覆盖文件仍回源 LastRO。 */
const UI_FALLBACK_DIR = uiSkinDirectory(currentUiSkin);

/* ---------------- 中文 UI 位图覆盖根（ui-zh） ----------------
   韩文界面贴图（basic_interface / inventory / statuswnd / …）用包内中文重绘版替换。
   查找顺序：ROE_UI_ZH_DIR 环境变量 → 包内 <ROOT>/ui-zh。
   相对路径约定 = 请求路径去掉韩文接口目录后的尾部，即
     <根>/client_re/data/texture-ui-fallback/<tail>
     （例：<ROOT>/ui-zh/client_re/data/texture-ui-fallback/basic_interface/quest_window.bmp）。
   覆盖根优先于皮肤兜底；两者都未命中才回落上游。打包时 _dist/ui-zh/** 原样复制到包根 ui-zh\。 */
const UI_ZH_RELATIVE_DIR = path.join('client_re', 'data', 'texture-ui-fallback');
const ENV_UI_ZH_DIR = process.env.ROE_UI_ZH_DIR ? path.resolve(process.env.ROE_UI_ZH_DIR) : null;
const PACKAGE_UI_ZH_DIR = path.join(ROOT, 'ui-zh');
function uiZhRoots() {
  const roots = [];
  [ENV_UI_ZH_DIR, PACKAGE_UI_ZH_DIR].forEach(function (candidate) {
    if (!candidate) return;
    let resolved;
    try { resolved = path.resolve(candidate); } catch (e) { return; }
    if (roots.indexOf(resolved) >= 0) return;
    roots.push(resolved);
  });
  return roots;
}
/* 在一个根目录下解析相对路径；越界（../、绝对路径、盘符）或不是文件 → null。 */
function resolveUnderRoot(root, relative) {
  if (!root || typeof relative !== 'string' || !relative) return null;
  let base;
  try { base = path.resolve(root); } catch (e) { return null; }
  const full = path.resolve(base, relative);
  if (full.indexOf(base + path.sep) !== 0) return null;
  try { return fs.statSync(full).isFile() ? full : null; } catch (e) { return null; }
}
/* 在 ui-zh 覆盖根里找贴图；命中返回 { file, root }，都没命中返回 null。 */
function uiZhLocalFile(relative) {
  const roots = uiZhRoots();
  for (let i = 0; i < roots.length; i++) {
    const dir = path.join(roots[i], UI_ZH_RELATIVE_DIR);
    let isDir = false;
    try { isDir = fs.statSync(dir).isDirectory(); } catch (e) { isDir = false; }
    if (!isDir) continue;
    const full = resolveUnderRoot(dir, relative);
    if (full) return { file: full, root: roots[i] };
  }
  return null;
}
/* 贴图相对路径越界防护：任何 .. 段都拒绝（含 Windows 反斜杠写法）。 */
function textureRelativeEscapes(relative) {
  const segments = String(relative).split(/[\\/]+/);
  for (let i = 0; i < segments.length; i++) if (segments[i] === '..') return true;
  return false;
}
/* 本地贴图直供：来源头区分 ui-zh 覆盖根 / 皮肤；两者都带 x-roe-local-override。 */
function serveLocalBmp(req, res, file, source) {
  const st = fs.statSync(file);
  res.writeHead(200, {
    'content-type': 'image/bmp', 'content-length': st.size, 'cache-control': 'no-store',
    'x-local-ui-fallback': source, 'x-roe-local-override': '1', 'access-control-allow-origin': '*'
  });
  if (req.method === 'HEAD') return res.end();
  return fs.createReadStream(file).pipe(res);
}

/* ---------------- 反代健壮性 + 本地磁盘缓存 ----------------
   背景：上游（game.lastro.cn）偶发慢/挂住。旧实现的上游 fetch 没有任何超时，
   一旦挂住：浏览器 worker（ThreadEventHandler.js 的 FileManager.getHTTP）里的
   promise 永不 settle ⇒ 回调永不触发 ⇒ 客户端启动序列停在「登录背景贴图」这一步，
   之后再也不发新请求（表现为 canvas=0、页面只请求 4 个资源、helper 上游请求悬挂）。
   现在：
     ① 每个上游请求有硬预算（默认单次 12s / 整请求 20s），超时或失败快速返回 504/502；
     ② 传输类失败/5xx 单次重试；
     ③ GET 的静态资源（贴图/精灵/数据表）落本地磁盘缓存，TTL 内命中直接本地供，
        完全不碰上游；TTL 过期且回源失败时宁可回旧缓存（stale）也不把客户端钉死；
     ④ 每次反代请求写日志（URL / 耗时 / 状态 / 缓存结果 / 重试），并可经 /proxy-log 读取。 */
const UPSTREAM_TIMEOUT_MS = Math.max(1000, Number(argOf('-ut', process.env.ROE_UPSTREAM_TIMEOUT_MS || 12000)));
const UPSTREAM_BUDGET_MS = Math.max(2000, Number(argOf('-ub', process.env.ROE_UPSTREAM_BUDGET_MS || 20000)));
const UPSTREAM_RETRIES = Math.max(0, Math.min(3, Number(argOf('-ur', process.env.ROE_UPSTREAM_RETRIES || 1))));
const UPSTREAM_RETRY_DELAY_MS = Math.max(0, Number(process.env.ROE_UPSTREAM_RETRY_DELAY_MS || 250));
/* 熔断：上游一旦出现传输层失败（超时/连接被拒），接下来这段时间不再回源，
   缺缓存的请求直接快速失败 —— 上游不可达时启动不会为每个缺失文件各等一次完整预算。 */
const UPSTREAM_COOLDOWN_MS = Math.max(0, Number(process.env.ROE_UPSTREAM_COOLDOWN_MS || 30000));
/* 单次上游响应超过这个体积就不整体缓冲，改为带空闲超时的流式转发 */
const PROXY_BUFFER_MAX = Math.max(1024 * 1024, Number(process.env.ROE_PROXY_BUFFER_MAX || 48 * 1024 * 1024));

const CACHE_DIR = process.env.ROE_CACHE_DIR ? path.resolve(process.env.ROE_CACHE_DIR) : path.join(ROOT, '.ro-cache');
const CACHE_INDEX_FILE = path.join(CACHE_DIR, 'index.json');
/* 缓存目录格式标记（2026-10-07）：缓存目录出现过「形状/语义不兼容」的变更时，
   旧目录必须整体作废一次，而不是继续按老规则读取。
   为什么需要它：2026-10-06 修的分片缺陷只阻止**新的** 206/content-range 分片落盘
   （upstreamIsPartial 落盘闸门），但已经登记进 index.json 的 14B 分片不是 HTML 假条目，
   cachePurgeFake 认不出来 —— 被污染过的机器装上修复版后仍然会命中那段分片（主城地图坏）。
   标记缺失或低于当前版本 = 目录来自旧版本 → 一次清理（见 cacheEnsureFormat）。 */
const CACHE_FORMAT_VERSION = 2;
const CACHE_FORMAT_FILE = path.join(CACHE_DIR, '.format');
const CACHE_MAX_BYTES = Math.max(16 * 1024 * 1024, Number(process.env.ROE_CACHE_MAX_BYTES || 2 * 1024 * 1024 * 1024));
const CACHE_FILE_MAX = Math.max(1024 * 1024, Number(process.env.ROE_CACHE_FILE_MAX || 64 * 1024 * 1024));
const CACHE_TTL_MS = Math.max(60 * 1000, Number(process.env.ROE_CACHE_TTL_MS || 24 * 3600 * 1000));
/* 负缓存：上游确定性的「文件不存在」（404 / 200+text/html 软 404）也落盘。
   上游不可达时这些条目能立刻返回，否则客户端要为每个真正缺失的文件各等一次超时预算。
   TTL 故意短（默认 30 分钟）：上游本身会间歇性 404，负结果不该压过 24 小时。 */
/* 设为 0 可整体关闭负缓存（ROE_CACHE_NEG_TTL_MS=0），此时只缓存确认存在的文件。 */
const CACHE_NEG_TTL_MS = Math.max(0, Number(process.env.ROE_CACHE_NEG_TTL_MS === undefined ? 30 * 60 * 1000 : process.env.ROE_CACHE_NEG_TTL_MS));
const CACHE_NEG_MAX_BYTES = Math.max(1024, Number(process.env.ROE_CACHE_NEG_MAX_BYTES || 64 * 1024));
/* 上游对「不存在的路径」并不总是回 404：实测 /client_re/System/Font/SCDream4.otf
   返回 200 + text/html + 437B 的反爬脚本页。只看 content-type 会漏掉伪装成
   application/octet-stream 的同类响应，所以再按正文字节嗅探（只嗅探小体积响应）。
   命中这些特征一律判为「上游说没有这个文件」→ 走负缓存，绝不进正常缓存。 */
const SOFT_HTML_MAX_BYTES = Math.max(1024, Number(process.env.ROE_SOFT_HTML_MAX_BYTES || 64 * 1024));
const SOFT_HTML_MARKERS = ['<!doctype html', '<html', '<head', '<body', '<script', '<meta ', '<iframe'];
function sniffHtmlBody(buffer) {
  if (!buffer || !buffer.length || buffer.length > SOFT_HTML_MAX_BYTES) return false;
  const head = buffer.slice(0, 1024).toString('latin1').toLowerCase();
  for (let i = 0; i < SOFT_HTML_MARKERS.length; i++) {
    if (head.indexOf(SOFT_HTML_MARKERS[i]) >= 0) return true;
  }
  return false;
}
function contentTypeIsHtml(contentType) {
  return String(contentType || '').toLowerCase().indexOf('text/html') >= 0;
}
/* 上游是否「确定性地没有这个文件」：真 404/410，或 200 但正文是反爬/网关 HTML 页。 */
function upstreamSaysMissing(status, contentType, buffer) {
  if (status === 404 || status === 410) return true;
  if (status !== 200) return false;
  return contentTypeIsHtml(contentType) || sniffHtmlBody(buffer);
}
/* 只读文件头几个字节（启动时校验缓存里有没有假条目用）。 */
function readHeadBytes(file, maxBytes) {
  try {
    const fd = fs.openSync(file, 'r');
    try {
      const buf = Buffer.alloc(maxBytes);
      const n = fs.readSync(fd, buf, 0, maxBytes, 0);
      return buf.slice(0, n);
    } finally { try { fs.closeSync(fd); } catch (e2) {} }
  } catch (e) { return null; }
}
/* 只缓存这些后缀的静态资源。动态接口（/prefs、/accounts、/requests、/userconfig/*、
   /batch 之类）没有这些后缀，天然不会被缓存；另外再加一条显式黑名单兜底。 */
const CACHE_EXT = new Set([
  '.bmp', '.png', '.jpg', '.jpeg', '.gif', '.tga', '.spr', '.act', '.pal', '.str', '.dds',
  '.gnd', '.gat', '.rsw', '.rsx', '.rsm', '.mp3', '.ogg', '.wav', '.ttf', '.otf', '.woff',
  '.woff2', '.eot', '.xml', '.txt', '.csv', '.lub', '.lua', '.json'
]);
const CACHE_DENY = /(\/prefs|\/accounts|\/requests|\/health|\/ui-skin|\/proxy-log|\/userconfig\/|\/batch$|\/save)/i;

const cacheIndex = new Map(); /* 上游路径 → { file, size, at, ct } */
let cacheIndexMtime = 0; /* index.json 的 mtime：外部进程（--prewarm）改写索引后据此热加载 */
const cacheStats = { bytes: 0, files: 0, hits: 0, stale: 0, writes: 0, evicts: 0, errors: 0, calls: 0, negatives: 0, negHits: 0, softNegatives: 0, rejects: 0, rangeSkips: 0, fakePurged: 0, orphans: 0 };
let cacheDirty = false;
let cachePersistTimer = null;

function cacheExtOf(p) {
  const ext = path.extname(String(p)).toLowerCase();
  return CACHE_EXT.has(ext) ? ext : null;
}
function cacheKeyOf(p) { return crypto.createHash('sha1').update(String(p)).digest('hex'); }
/* 返回可缓存的后缀，null 表示不缓存（非 GET / 带 query / 黑名单 / 后缀不在白名单） */
function cacheableProxyPath(p, method, rawQuery) {
  if (String(method).toUpperCase() !== 'GET') return null;
  if (rawQuery) return null;
  if (CACHE_DENY.test(String(p))) return null;
  return cacheExtOf(p);
}
/* 分片安全（2026-10-06 修复）：带 content-range 或状态 206 的上游响应是**一段分片**，
   缓存层没有整份资源可写。旧版本把 14 字节的 .gat 头（magic 4 + 版本 2 + 宽高 8）
   当成完整地图缓存进 .ro-cache，之后任何不带 Range 的请求都拿到那段分片
   （geffen.gat 1152014B → 14B，主城地图加载损坏）。
   判据只看响应本身、不看请求：只要上游说这是分片，就一律透传、绝不落盘。 */
function upstreamIsPartial(out) {
  if (!out) return false;
  if (Number(out.status) === 206) return true;
  const headers = out.headers;
  return !!(headers && typeof headers.get === 'function' && headers.get('content-range'));
}
/* 单段 Range 解析（bytes=a-b / bytes=a- / bytes=-n），size 是完整文件长度。
   返回：{ start, end } 可满足的单段；{ unsatisfiable: true } 越界（按 RFC 9110 回 416）；
   null 表示多段 / 语法不认识 —— 本地切不了就绕开缓存交给上游，绝不猜。 */
function parseRangeHeader(value, size) {
  const m = /^bytes=(\d*)-(\d*)$/.exec(String(value == null ? '' : value).trim());
  if (!m) return null;
  const startRaw = m[1], endRaw = m[2];
  if (!startRaw && !endRaw) return null;
  const total = Number(size);
  if (!Number.isFinite(total) || total <= 0) return { unsatisfiable: true };
  let start, end;
  if (!startRaw) {
    const suffix = Number(endRaw);
    if (!Number.isFinite(suffix) || suffix <= 0) return { unsatisfiable: true };
    start = suffix >= total ? 0 : total - suffix;
    end = total - 1;
  } else {
    start = Number(startRaw);
    end = endRaw === '' ? total - 1 : Math.min(Number(endRaw), total - 1);
  }
  if (!Number.isFinite(start) || !Number.isFinite(end)) return null;
  if (start >= total || end < start) return { unsatisfiable: true };
  return { start: start, end: end };
}
/* 扫描缓存目录并恢复索引；不存在的条目会被丢弃。
   索引缺失/损坏也要能起来：先试 index.json，再试 index.json.bak，都不可用就按空缓存继续
   （磁盘上的旧文件只计为孤儿、不误供），坏索引改名留证。 */
function cacheLoadIndexFile(file) {
  const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
  const entries = (raw && raw.entries) || {};
  let n = 0;
  Object.keys(entries).forEach(function (key) {
    const value = entries[key];
    if (!value || typeof value.f !== 'string') return;
    const full = path.join(CACHE_DIR, value.f);
    let st;
    try { st = fs.statSync(full); } catch (e) { return; }
    if (!st.isFile()) return;
    cacheIndex.set(key, { file: full, size: st.size, at: Number(value.at) || st.mtimeMs, ct: value.ct || '', status: Number(value.s) || 200, neg: !!value.neg, soft: !!value.soft || (!!value.neg && Number(value.s) === 200) });
    if (value.neg) { cacheStats.negatives++; if (value.soft || Number(value.s) === 200) cacheStats.softNegatives++; }
    cacheStats.bytes += st.size;
    n++;
  });
  return n;
}
/* 磁盘上形如 <sha1>.<ext> 的缓存文件里，有多少没被索引引用（索引损坏后的孤儿）。 */
function cacheOrphanCount() {
  const used = new Set();
  cacheIndex.forEach(function (value) { used.add(path.basename(value.file)); });
  let names = [];
  try { names = fs.readdirSync(CACHE_DIR).filter(function (name) { return /^[0-9a-f]{40}[.][a-z0-9]+$/.test(name); }); } catch (e) { return 0; }
  let n = 0;
  names.forEach(function (name) { if (!used.has(name)) n++; });
  return n;
}
/* 读缓存格式标记；读不到（缺失/不可读）返回空串 = 旧目录。 */
function cacheFormatRead() {
  try { return String(fs.readFileSync(CACHE_FORMAT_FILE, 'utf8')).trim(); } catch (e) { return ''; }
}
/* 写格式标记（同目录临时文件 + rename）。失败只记日志、绝不抛。 */
function cacheFormatWrite() {
  try {
    const tmp = CACHE_FORMAT_FILE + '.tmp-' + process.pid;
    fs.writeFileSync(tmp, String(CACHE_FORMAT_VERSION), 'utf8');
    fs.renameSync(tmp, CACHE_FORMAT_FILE);
    return true;
  } catch (e) {
    log('缓存格式标记写入失败（忽略，不影响服务启动）：' + (e && e.message ? e.message : e));
    return false;
  }
}
/* 一次清理：删掉缓存目录里的索引与缓存文件（只删本层、只删可识别的缓存文件，
   别的文件一律不动）。单个文件删不掉不中断 —— 服务必须起得来。返回删除的文件数。 */
function cacheWipeForFormat() {
  let names = [];
  try { names = fs.readdirSync(CACHE_DIR); } catch (e) { return 0; }
  const indexName = path.basename(CACHE_INDEX_FILE);
  let removed = 0;
  names.forEach(function (name) {
    if (name === path.basename(CACHE_FORMAT_FILE)) return;
    const isCacheFile = /^[0-9a-f]{40}[.][a-z0-9]+$/.test(name);
    const isIndex = name === indexName || name.indexOf(indexName + '.') === 0;
    if (!isCacheFile && !isIndex) return;
    try { fs.unlinkSync(path.join(CACHE_DIR, name)); removed++; } catch (e) {}
  });
  return removed;
}
/* 格式闸门：标记不是当前版本就整体作废一次并写入新标记；返回 true 表示本次清理过。
   只在 cacheInit() 里调用，一次启动最多清一次；全程 try/catch（清理失败也照常起服务）。 */
function cacheEnsureFormat() {
  const found = cacheFormatRead();
  if (found === String(CACHE_FORMAT_VERSION)) return false;
  let removed = 0;
  try { removed = cacheWipeForFormat(); } catch (e) { log('缓存格式迁移清理失败（忽略）：' + (e && e.message ? e.message : e)); }
  cacheFormatWrite();
  log('缓存格式升级：目录标记 ' + (found ? 'v' + found : '缺失') + ' → v' + CACHE_FORMAT_VERSION
    + '，旧缓存整体作废一次（删除 ' + removed + ' 个缓存文件、索引清空，按需自动重建；无需手动删目录）');
  return true;
}
function cacheInit() {
  try { fs.mkdirSync(CACHE_DIR, { recursive: true }); } catch (e) { log('缓存目录不可用：' + (e && e.message ? e.message : e)); }
  /* 格式闸门必须排在读索引之前：旧目录（分片缺陷期写下的 14B 分片会被当作完整资源供出）
     在这里整体作废，之后走全新的空缓存。 */
  try { cacheEnsureFormat(); } catch (e) { log('缓存格式闸门异常（忽略）：' + (e && e.message ? e.message : e)); }
  /* 重新初始化：内存索引整体重建（索引缺失/损坏时按空缓存继续，不留半截状态） */
  cacheIndex.clear();
  cacheStats.bytes = 0;
  cacheStats.files = 0;
  cacheStats.negatives = 0;
  cacheStats.softNegatives = 0;
  let restored = 0;
  try {
    restored = cacheLoadIndexFile(CACHE_INDEX_FILE);
  } catch (e) {
    if (e && e.code === 'ENOENT') {
      log('缓存索引缺失（首次启动 / 被清理）：按空缓存继续，命中会逐步重建；可用 --prewarm 重新预热');
    } else {
      log('缓存索引损坏（' + (e && e.message ? e.message : e) + '）：尝试从 index.json.bak 恢复');
      try {
        restored = cacheLoadIndexFile(CACHE_INDEX_FILE + '.bak');
        log('缓存索引已从备份恢复 ' + restored + ' 条');
      } catch (e2) {
        log('备份也不可用（' + (e2 && e2.message ? e2.message : e2) + '）：按空缓存继续，孤儿文件只计数不误供');
      }
      try { fs.renameSync(CACHE_INDEX_FILE, CACHE_INDEX_FILE + '.bad-' + Date.now()); } catch (e3) {}
    }
  }
  cacheStats.files = cacheIndex.size;
  cacheStats.orphans = cacheOrphanCount();
  try { cacheIndexMtime = fs.statSync(CACHE_INDEX_FILE).mtimeMs; } catch (e) { cacheIndexMtime = 0; }
  try { cachePurgeFake(); } catch (e) { log('缓存自检失败（忽略）：' + (e && e.message ? e.message : e)); }
  /* 覆盖白名单表的历史韩文缓存（--prewarm 误落盘的那批）启动即清，永不再供出 */
  try { purgeOverlayCacheEntries(); } catch (e) { log('覆盖缓存自检失败（忽略）：' + (e && e.message ? e.message : e)); }
  return restored;
}
/* 旧版本把上游的反爬/软 404 页（200 + HTML）当成正常文件缓存了下来
   （例如 /client_re/System/Font/SCDream4.otf 曾缓存 437B 反爬页）。
   这类条目客户端永远解析不了，属假条目：启动时与 --purge-fake 各清一次。
   判据与运行期一致：content-type 是 text/html，或正文字节嗅探为 HTML。 */
function cachePurgeFake() {
  const victims = [];
  cacheIndex.forEach(function (entry, key) {
    if (entry.neg) return;
    let fake = contentTypeIsHtml(entry.ct);
    if (!fake) {
      const head = readHeadBytes(entry.file, 1024);
      fake = !!head && sniffHtmlBody(head);
    }
    if (fake) victims.push(key);
  });
  let removed = 0, freed = 0;
  victims.forEach(function (key) {
    const entry = cacheIndex.get(key);
    try { fs.unlinkSync(entry.file); } catch (e) {}
    cacheIndex.delete(key);
    cacheStats.bytes -= entry.size;
    freed += entry.size;
    removed++;
    cacheDirty = true;
  });
  if (removed) {
    cacheStats.files = cacheIndex.size;
    cacheStats.fakePurged += removed;
    log('缓存清理：删除 ' + removed + ' 条「反爬/软 404 页被当正常文件缓存」的假条目（' + freed + 'B）');
    cachePersist();
  }
  return removed;
}
function cachePersist() {
  if (!cacheDirty) return;
  cacheDirty = false;
  try {
    const entries = {};
    cacheIndex.forEach(function (value, key) {
      entries[key] = { f: path.basename(value.file), size: value.size, at: value.at, ct: value.ct || '', s: value.status || 200, neg: value.neg ? 1 : 0, soft: value.soft ? 1 : 0 };
    });
    const tmp = CACHE_INDEX_FILE + '.tmp-' + process.pid;
    fs.writeFileSync(tmp, JSON.stringify({ version: 1, savedAt: new Date().toISOString(), entries: entries }), 'utf8');
    /* 保留上一版索引：索引损坏/被清空时 cacheInit 能从 .bak 恢复 */
    try { if (fs.existsSync(CACHE_INDEX_FILE)) fs.copyFileSync(CACHE_INDEX_FILE, CACHE_INDEX_FILE + '.bak'); } catch (e) {}
    fs.renameSync(tmp, CACHE_INDEX_FILE);
  } catch (e) { cacheStats.errors++; }
}
function cachePersistSoon() {
  if (cachePersistTimer) return;
  cachePersistTimer = setTimeout(function () { cachePersistTimer = null; cachePersist(); }, 2000);
  if (cachePersistTimer.unref) cachePersistTimer.unref();
}
/* 索引文件被外部进程（node client-service.js --prewarm）改写时热加载合并，
   这样「预热」不必重启 helper 也能立刻命中。 */
function cacheIndexRefreshIfChanged() {
  let st;
  try { st = fs.statSync(CACHE_INDEX_FILE); } catch (e) { return false; }
  if (!st.isFile() || st.mtimeMs === cacheIndexMtime) return false;
  cacheIndexMtime = st.mtimeMs;
  let parsed;
  try { parsed = JSON.parse(fs.readFileSync(CACHE_INDEX_FILE, 'utf8')); } catch (e) { return false; }
  const entries = (parsed && parsed.entries) || {};
  let added = 0;
  Object.keys(entries).forEach(function (key) {
    if (cacheIndex.has(key)) return;
    const value = entries[key];
    if (!value || typeof value.f !== 'string') return;
    const file = path.join(CACHE_DIR, value.f);
    let fileStat;
    try { fileStat = fs.statSync(file); } catch (e) { return; }
    if (!fileStat.isFile()) return;
    cacheIndex.set(key, { file: file, size: fileStat.size, at: Number(value.at) || fileStat.mtimeMs, ct: value.ct || '', status: Number(value.s) || 200, neg: !!value.neg, soft: !!value.soft });
    if (value.neg) { cacheStats.negatives++; if (value.soft) cacheStats.softNegatives++; }
    cacheStats.bytes += fileStat.size;
    added++;
  });
  cacheStats.files = cacheIndex.size;
  if (added) log('缓存索引热加载：+ ' + added + ' 条（共 ' + cacheIndex.size + ' 条）');
  return added > 0;
}
function cacheLookup(p) {
  let entry = cacheIndex.get(String(p));
  if (!entry && cacheIndexRefreshIfChanged()) entry = cacheIndex.get(String(p));
  if (!entry) return null;
  try {
    const st = fs.statSync(entry.file);
    if (!st.isFile()) throw new Error('not a file');
    entry.size = st.size;
    return entry;
  } catch (e) { cacheIndex.delete(String(p)); return null; }
}
/* 新鲜度：负缓存用更短的 TTL，避免把上游的一时 404 固定 24 小时。 */
function cacheEntryFresh(entry) {
  if (!entry) return false;
  const ttl = entry.neg ? CACHE_NEG_TTL_MS : CACHE_TTL_MS;
  return Date.now() - entry.at <= ttl;
}
/* 落盘：同目录临时文件 + rename，成功后才更新内存索引与统计。 */
function cacheStore(p, buffer, contentType, opts) {
  opts = opts || {};
  const neg = !!opts.neg; /* 负缓存：确定性的 404 / 200+text/html 软 404 */
  if (neg && CACHE_NEG_TTL_MS <= 0) return null; /* 负缓存已关闭 */
  if (!buffer || !buffer.length) return null;
  if (buffer.length > (neg ? CACHE_NEG_MAX_BYTES : CACHE_FILE_MAX)) return null;
  /* 上游对不存在的路径会返回 200 + 一小段 HTML 错误页（软 404）。正常缓存不能收它
     （客户端拿到 text/html 会判定「不是二进制数据」，缓存下来只会把错误固化）；
     但作为负缓存收下来是对的：下次同一条路径立刻拿到同样的失败，不必再等超时。 */
  if (!neg && (contentTypeIsHtml(contentType) || sniffHtmlBody(buffer))) {
    /* 上游反爬页 / 软 404：绝不当正常文件缓存 */
    cacheStats.rejects++;
    return null;
  }
  const ext = cacheExtOf(p);
  if (!ext) return null;
  const file = path.join(CACHE_DIR, cacheKeyOf(p) + ext);
  try {
    fs.mkdirSync(CACHE_DIR, { recursive: true });
    const tmp = file + '.tmp-' + process.pid + '-' + Date.now();
    fs.writeFileSync(tmp, buffer);
    fs.renameSync(tmp, file);
  } catch (e) { cacheStats.errors++; return null; }
  const previous = cacheIndex.get(String(p));
  if (previous) cacheStats.bytes -= previous.size;
  const entry = { file: file, size: buffer.length, at: Date.now(), ct: contentType || '', status: neg ? (Number(opts.status) || 404) : 200, neg: neg, soft: neg && !!opts.soft };
  cacheIndex.set(String(p), entry);
  cacheStats.bytes += buffer.length;
  cacheStats.files = cacheIndex.size;
  cacheStats.writes++;
  if (neg) { cacheStats.negatives++; if (opts.soft) cacheStats.softNegatives++; }
  cacheEvict();
  cacheDirty = true;
  cachePersistSoon();
  return entry;
}
/* 体积上限：超限时按写入时间从旧到新淘汰。 */
function cacheEvict() {
  if (cacheStats.bytes <= CACHE_MAX_BYTES) return;
  const list = Array.from(cacheIndex.entries()).sort(function (a, b) { return a[1].at - b[1].at; });
  for (let i = 0; i < list.length && cacheStats.bytes > CACHE_MAX_BYTES; i++) {
    try { fs.unlinkSync(list[i][1].file); } catch (e) {}
    cacheIndex.delete(list[i][0]);
    cacheStats.bytes -= list[i][1].size;
    cacheStats.evicts++;
    cacheDirty = true;
  }
  cacheStats.files = cacheIndex.size;
  cachePersistSoon();
}
function cacheSummary() {
  return {
    dir: CACHE_DIR, maxBytes: CACHE_MAX_BYTES, fileMax: CACHE_FILE_MAX, ttlMs: CACHE_TTL_MS, negTtlMs: CACHE_NEG_TTL_MS,
    files: cacheStats.files, bytes: cacheStats.bytes, hits: cacheStats.hits, stale: cacheStats.stale,
    writes: cacheStats.writes, evicts: cacheStats.evicts, errors: cacheStats.errors,
    negatives: cacheStats.negatives, negHits: cacheStats.negHits,
    softNegatives: cacheStats.softNegatives, rejects: cacheStats.rejects,
    rangeSkips: cacheStats.rangeSkips, fakePurged: cacheStats.fakePurged, orphans: cacheStats.orphans
  };
}

/* ---------------- 上游熔断 ---------------- */
let upstreamDownUntil = 0;
let upstreamDownReason = null;
function upstreamIsDown() { return Date.now() < upstreamDownUntil; }
function upstreamMarkDown(reason) {
  if (UPSTREAM_COOLDOWN_MS <= 0) return;
  const wasUp = !upstreamIsDown();
  upstreamDownUntil = Date.now() + UPSTREAM_COOLDOWN_MS;
  upstreamDownReason = reason || 'unreachable';
  if (wasUp) log('上游熔断：' + upstreamDownReason + '，' + UPSTREAM_COOLDOWN_MS + 'ms 内只供本地缓存（缺缓存的请求立即 504）');
}
function upstreamMarkUp() {
  if (upstreamDownUntil || upstreamDownReason) log('上游恢复：熔断解除');
  upstreamDownUntil = 0;
  upstreamDownReason = null;
}

/* ---------------- 反代请求日志 / 在途请求 ---------------- */
const proxyLogRing = [];
const proxyInFlight = new Map();
function proxyLog(kind, path, status, ms, bytes, cache, attempts) {
  const record = { at: new Date().toISOString(), kind: kind, url: path, status: status, ms: ms, bytes: bytes, cache: cache };
  if (attempts && attempts.length > 1) record.attempts = attempts;
  proxyLogRing.push(record);
  if (proxyLogRing.length > 500) proxyLogRing.splice(0, proxyLogRing.length - 500);
  let line = 'PROXY ' + kind + ' ' + status + ' ' + ms + 'ms ' + bytes + 'B cache=' + cache + ' ' + path;
  if (record.attempts) line += ' attempts=' + attempts.map(function (a) { return a.status + '/' + a.ms + 'ms' + (a.err ? '(' + a.err + ')' : ''); }).join(',');
  log(line);
}

/* 单次上游请求：响应头 + 响应体都在 timeoutMs 内完成，否则 abort。
   返回 { status, headers, body|stream, ms, err, oversized } —— 绝不无限挂住。 */
async function fetchUpstreamOnce(url, method, headers, timeoutMs) {
  const controller = new AbortController();
  let timedOut = false;
  const timer = setTimeout(function () { timedOut = true; controller.abort(); }, timeoutMs);
  const t0 = Date.now();
  try {
    const response = await fetch(url, { method: method, headers: headers, signal: controller.signal, redirect: 'follow' });
    const result = { status: response.status, headers: response.headers, body: null, stream: null, ms: Date.now() - t0, err: null, oversized: false, controller: controller, timer: timer };
    if (method === 'HEAD' || !response.body) {
      clearTimeout(timer);
      result.body = Buffer.alloc(0);
      result.ms = Date.now() - t0;
      return result;
    }
    const length = Number(response.headers.get('content-length') || 0);
    if (length > PROXY_BUFFER_MAX) {
      clearTimeout(timer); /* 改由调用方按空闲超时读流 */
      result.oversized = true;
      result.stream = response.body;
      result.ms = Date.now() - t0;
      return result;
    }
    result.body = Buffer.from(await response.arrayBuffer());
    clearTimeout(timer);
    result.ms = Date.now() - t0;
    return result;
  } catch (e) {
    clearTimeout(timer);
    const reason = timedOut ? 'timeout' : (e && e.name === 'AbortError' ? 'aborted' : (e && e.message ? e.message : String(e)));
    return { status: 0, headers: null, body: null, stream: null, ms: Date.now() - t0, err: reason, oversized: false };
  }
}

/* 候选路径（原路径 + GBK 变体）+ 单次重试，整体不超过 deadline。
   返回 { out, usedPath, attempts }；out.err 非空 / out.status>=500 表示没拿到确定答案。 */
async function fetchUpstreamWithPolicy(proxyPath, rawQuery, method, headers, deadline) {
  const candidates = [];
  const known = gbkPathCache.get(proxyPath);
  if (known) {
    candidates.push(known);
    if (known !== proxyPath) candidates.push(proxyPath);
  } else {
    candidates.push(proxyPath);
    const variant = gbkVariant(proxyPath);
    if (variant && variant !== proxyPath) candidates.push(variant);
  }
  let out = null;
  let usedPath = candidates[0];
  const attempts = [];
  for (let ci = 0; ci < candidates.length; ci++) {
    for (let attempt = 0; attempt <= UPSTREAM_RETRIES; attempt++) {
      const remain = deadline - Date.now();
      if (remain < 250) break;
      const budget = Math.min(UPSTREAM_TIMEOUT_MS, remain);
      const result = await fetchUpstreamOnce(UPSTREAM + candidates[ci] + rawQuery, method, headers, budget);
      attempts.push({ path: candidates[ci], n: attempt + 1, status: result.status, ms: result.ms, err: result.err });
      out = result;
      usedPath = candidates[ci];
      const transient = !!result.err || result.status >= 500;
      if (transient && attempt < UPSTREAM_RETRIES && deadline - Date.now() > UPSTREAM_RETRY_DELAY_MS + 250) {
        await new Promise(function (r) { setTimeout(r, UPSTREAM_RETRY_DELAY_MS); });
        continue;
      }
      break;
    }
    const settled = out && !out.err && out.status < 500 && out.status !== 404;
    if (settled) break;
    if (ci + 1 >= candidates.length) break;
  }
  return { out: out, usedPath: usedPath, attempts: attempts };
}

/* 本地缓存直供（命中 / 过期回退）。
   Range 语义（2026-10-06 修复）：缓存里存的是**完整 200** 正文，客户端要一段就按本地文件
   切片回 206（content-range + content-length 都按切片算），绝不整份返回、也绝不回错的分片。
   切不了的情况一律「绕开缓存」交给上游，而不是猜：负缓存/非 200 条目没有完整正文可切；
   多段或语法不认识的 Range 也不在本地处理。 */
function serveCached(req, res, entry, mode, extraHeaders) {
  let st;
  try { st = fs.statSync(entry.file); } catch (e) { return false; }
  const status = Number(entry.status) || 200;
  const rangeRaw = req.headers ? req.headers.range : null;
  let slice = null;
  if (rangeRaw) {
    if (entry.neg || status !== 200) return false;
    const parsed = parseRangeHeader(rangeRaw, st.size);
    if (!parsed) return false;
    if (parsed.unsatisfiable) {
      const badHeaders = {
        'content-type': entry.ct || mimeOf(entry.file),
        'content-range': 'bytes */' + st.size,
        'content-length': 0,
        'x-roe-cache': mode,
        'x-roe-cache-status': String(status),
        'x-roe-cache-age-ms': String(Date.now() - entry.at),
        'access-control-allow-origin': '*'
      };
      if (extraHeaders) Object.assign(badHeaders, extraHeaders);
      res.writeHead(416, badHeaders);
      res.end();
      return true;
    }
    slice = parsed;
  }
  const headers = {
    'content-type': entry.ct || mimeOf(entry.file),
    'content-length': slice ? (slice.end - slice.start + 1) : st.size,
    'accept-ranges': 'bytes',
    'cache-control': 'public, max-age=3600',
    'x-roe-cache': mode,
    'x-roe-cache-status': String(status),
    'x-roe-cache-age-ms': String(Date.now() - entry.at),
    'access-control-allow-origin': '*'
  };
  if (slice) headers['content-range'] = 'bytes ' + slice.start + '-' + slice.end + '/' + st.size;
  if (extraHeaders) Object.assign(headers, extraHeaders);
  res.writeHead(slice ? 206 : status, headers);
  if (req.method === 'HEAD') { res.end(); return true; }
  if (slice) fs.createReadStream(entry.file, { start: slice.start, end: slice.end }).pipe(res);
  else fs.createReadStream(entry.file).pipe(res);
  return true;
}

/* 把上游响应（已缓冲 / 大文件流）转发给客户端。 */
async function sendUpstream(req, res, out, usedPath, extraHeaders) {
  const headers = {};
  ['content-type', 'content-range', 'accept-ranges', 'etag', 'last-modified', 'cache-control'].forEach(function (k) {
    const v = out.headers.get(k);
    if (v) headers[k] = v;
  });
  if (out.body) headers['content-length'] = out.body.length;
  headers['access-control-allow-origin'] = '*';
  /* 覆盖白名单表的回源响应：no-store + x-roe-overlay: upstream-kr（覆盖上游的 max-age=3600） */
  if (extraHeaders) Object.assign(headers, extraHeaders);
  headers['x-roe-upstream-ms'] = String(out.ms);
  headers['x-roe-upstream-path'] = encodeURI(usedPath);
  res.writeHead(out.status, headers);
  if (req.method === 'HEAD') {
    if (out.stream) { try { await out.stream.cancel(); } catch (e) {} }
    res.end();
    return 0;
  }
  if (out.body) { res.end(out.body); return out.body.length; }
  if (!out.stream) { res.end(); return 0; }
  const reader = out.stream.getReader();
  let bytes = 0;
  for (;;) {
    let timer = null;
    const chunk = await Promise.race([
      reader.read(),
      new Promise(function (_, reject) { timer = setTimeout(function () { reject(new Error('idle-timeout')); }, UPSTREAM_TIMEOUT_MS); })
    ]).finally(function () { if (timer) clearTimeout(timer); });
    if (chunk.done) break;
    bytes += chunk.value.length;
    proxyStats.bytes += chunk.value.length;
    res.write(Buffer.from(chunk.value));
  }
  res.end();
  return bytes;
}

/* 反代主流程。
   opts.overlayTail 非空 = 这个上游路径属于中文覆盖白名单却走到了回源分支（正常永远不该发生）：
   上游那份是韩文，必须强制 no-store、打 x-roe-overlay: upstream-kr、记 [OVERLAY-KR-LEAK]，
   并且绝不把它写进本地缓存。 */
async function handleProxy(req, res, proxyPath, rawQuery, alreadyCounted, opts) {
  const started = Date.now();
  const deadline = started + UPSTREAM_BUDGET_MS;
  let overlayGuard = null;
  if (opts && opts.overlayTail) {
    console.error('[OVERLAY-KR-LEAK] ' + opts.overlayTail + ' 命中中文覆盖白名单却走了上游回源分支（上游为韩文；请求 ' + proxyPath + '）');
    overlayGuard = { 'cache-control': 'no-store', 'x-roe-overlay': 'upstream-kr', 'x-roe-overlay-tail': opts.overlayTail };
  }
  const headers = { 'accept-encoding': 'identity', 'user-agent': 'roe-helper/1.0' };
  if (req.headers.range) headers.range = req.headers.range;
  if (req.headers['if-none-match']) headers['if-none-match'] = req.headers['if-none-match'];
  if (req.headers['if-modified-since']) headers['if-modified-since'] = req.headers['if-modified-since'];

  const inflightKey = proxyPath + rawQuery;
  proxyInFlight.set(inflightKey, started);
  if (!alreadyCounted) { proxyStats.requests++; proxyStats.lastPath = proxyPath; }
  cacheStats.calls++;

  try {
    /* ① TTL 内直接命中本地缓存（含负缓存：确定不存在的文件也立刻回同样的失败） */
    const cached = cacheLookup(proxyPath);
    if (cacheEntryFresh(cached)) {
      cacheStats.hits++;
      if (cached.neg) cacheStats.negHits++;
      if (serveCached(req, res, cached, 'hit', overlayGuard)) {
        proxyLog('HIT', proxyPath, Number(cached.status) || 200, Date.now() - started, cached.size, 'hit', null);
        return;
      }
    }
    /* ①.5 上游熔断中：只供本地缓存，缺缓存立刻失败，不再等超时 */
    if (upstreamIsDown()) {
      proxyStats.down++;
      proxyInFlight.delete(inflightKey);
      const body = Buffer.from('上游熔断中（' + upstreamDownReason + '）: ' + proxyPath + '\n', 'utf8');
      const downHeaders = { 'content-type': 'text/plain; charset=utf-8', 'content-length': body.length, 'x-roe-cache': 'miss', 'x-roe-upstream': 'down', 'access-control-allow-origin': '*' };
      if (overlayGuard) Object.assign(downHeaders, overlayGuard);
      res.writeHead(504, downHeaders);
      res.end(req.method === 'HEAD' ? undefined : body);
      proxyLog('FAIL-DOWN', proxyPath, 504, Date.now() - started, 0, 'miss', null);
      return;
    }
    /* ② 回源 */
    const result = await fetchUpstreamWithPolicy(proxyPath, rawQuery, req.method, headers, deadline);
    const out = result.out;
    const definitive = !!(out && !out.err && out.status < 500);
    if (out && out.status === 404) proxyStats.notFound++;
    if (out && out.status === 200 && upstreamSaysMissing(out.status, out.headers.get('content-type') || '', out.body)) proxyStats.softNotFound++;
    if (reqLog.length < 400) reqLog.push((out && out.status ? out.status : 'ERR') + ' ' + result.usedPath);
    if (result.usedPath !== proxyPath && definitive && out.status < 400) gbkPathCache.set(proxyPath, result.usedPath);

    if (definitive) {
      upstreamMarkUp();
      let bytes = 0;
      try { bytes = await sendUpstream(req, res, out, result.usedPath, overlayGuard); }
      catch (e) {
        proxyStats.failures++;
        proxyLog('STREAM-FAIL', proxyPath, out.status, Date.now() - started, bytes, 'miss', result.attempts);
        try { res.destroy(); } catch (e2) {}
        return;
      }
      const ct = out.headers.get('content-type') || '';
      const missing = upstreamSaysMissing(out.status, ct, out.body);
      /* 落盘健全性检查（2026-10-06 修复）：
         ① 206 / 带 content-range 的响应是分片，一律不写缓存（旧版把分片当完整资源写盘，
            geffen.gat 就此变成 14 字节，之后所有无 Range 请求都拿到那段分片）；
         ② 正常缓存只收 status === 200 的完整响应（3xx/4xx 的正文不是「确认存在的文件」）；
         ③ 负缓存（404/410 / 200+反爬 HTML 软 404）保持原样，它本来就是「上游说没有」。 */
      const partial = upstreamIsPartial(out);
      if (partial) {
        cacheStats.rangeSkips++;
      } else if (out.body && !overlayGuard && cacheableProxyPath(result.usedPath, req.method, rawQuery)) {
        if (missing) {
          /* 负缓存：上游明确说「没有这个文件」（404，或 200 + 反爬/软 404 HTML 页），
             记下来，下次（尤其上游不可达时）立刻返回，不必再等超时。 */
          cacheStore(proxyPath, out.body, ct || 'text/html', { neg: true, soft: out.status === 200, status: out.status });
        } else if (out.status === 200) {
          cacheStore(proxyPath, out.body, ct);
        }
      }
      proxyLog(missing ? (out.status === 200 ? 'SOFT-404' : 'NOTFOUND') : (partial ? 'PARTIAL' : 'OK'), proxyPath, out.status, Date.now() - started, bytes, 'miss', result.attempts);
      return;
    }

    /* ③ 拿不到确定答案：有旧缓存就用旧的，绝不把客户端钉死 */
    if (cached) {
      cacheStats.stale++;
      if (serveCached(req, res, cached, 'stale', overlayGuard)) {
        proxyLog('STALE', proxyPath, 200, Date.now() - started, cached.size, 'stale', result.attempts);
        return;
      }
    }
    const status = (out && out.err === 'timeout') || !out ? 504 : (out.err ? 502 : 504);
    if (out && out.err) upstreamMarkDown(out.err);
    proxyStats.failures++;
    if (status === 504) proxyStats.timeouts++;
    const detail = out && out.err ? out.err : ('HTTP ' + (out ? out.status : '?'));
    const body = Buffer.from('上游不可用（' + detail + '）: ' + proxyPath + '\n', 'utf8');
    const failHeaders = { 'content-type': 'text/plain; charset=utf-8', 'content-length': body.length, 'x-roe-cache': 'miss', 'access-control-allow-origin': '*' };
    if (overlayGuard) Object.assign(failHeaders, overlayGuard);
    res.writeHead(status, failHeaders);
    res.end(req.method === 'HEAD' ? undefined : body);
    proxyLog('FAIL', proxyPath, status, Date.now() - started, 0, 'miss', result.attempts);
  } finally {
    proxyInFlight.delete(inflightKey);
  }
}

/* ---------------- 预热：把启动必经资源先落到缓存 ----------------
   prewarm.json 里是本机路径（/client_re/... 形式），会按 PREFIX_MAP 映射到上游。
   用法：node client-service.js --prewarm [--refresh] [清单文件] —— 一键刷新，无需启动服务。 */
const PREWARM_FILE = path.join(ROOT, 'prewarm.json');
const PREWARM_DEFAULT_PATHS = [];
function toUpstreamPath(localPath) {
  for (let i = 0; i < PREFIX_MAP.length; i++) {
    if (String(localPath).indexOf(PREFIX_MAP[i][0]) === 0) return PREFIX_MAP[i][1] + String(localPath).slice(PREFIX_MAP[i][0].length);
  }
  return null;
}
function prewarmPaths(listFile) {
  const file = listFile ? path.resolve(listFile) : PREWARM_FILE;
  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    const list = Array.isArray(parsed) ? parsed : (parsed && Array.isArray(parsed.paths) ? parsed.paths : null);
    if (list) return list.filter(function (x) { return typeof x === 'string' && x; });
  } catch (e) {
    if (e && e.code !== 'ENOENT') log('预热清单读取失败：' + (e && e.message ? e.message : e));
  }
  return PREWARM_DEFAULT_PATHS.slice();
}
async function prewarm(options) {
  options = options || {};
  const paths = options.paths || prewarmPaths(options.listFile);
  const started = Date.now();
  const rows = [];
  let ok = 0, failed = 0, skipped = 0, bytes = 0, negatives = 0, overlaySkipped = 0;
  /* 先清掉白名单表的历史韩文缓存，保证「缓存里没有韩文」这条不变式 */
  const overlayPurged = purgeOverlayCacheEntries();
  const headers = { 'accept-encoding': 'identity', 'user-agent': 'roe-helper/0-prewarm' };
  for (let i = 0; i < paths.length; i++) {
    const raw = paths[i];
    /* 覆盖白名单里的 8 张表一律不预热：它们是本地中文表，上游那份是韩文，
       预热只会把韩文写进 .ro-cache（2026-10-02 那批回源落盘就是这么漏的）。 */
    const overlayTail = overlayTailOf(raw);
    if (overlayTail) {
      rows.push({ path: raw, result: 'overlay-skip', tail: overlayTail });
      overlaySkipped++;
      skipped++;
      continue;
    }
    /* 缓存键与运行期完全一致：反代用的是 req.url 的原始（仍是百分号编码的）路径，
       所以预热也必须保留编码形式，解码后再映射会对不上键、永远 miss。 */
    const proxyPath = toUpstreamPath(raw);
    if (!proxyPath) { rows.push({ path: raw, result: 'unmapped' }); failed++; continue; }
    const cacheable = cacheableProxyPath(proxyPath, 'GET', '');
    if (!cacheable) { rows.push({ path: raw, result: 'not-cacheable' }); skipped++; continue; }
    if (!options.refresh) {
      const existing = cacheLookup(proxyPath);
      if (existing && cacheEntryFresh(existing) && options.onlyMissing !== false) {
        rows.push({ path: raw, result: 'cached', bytes: existing.size });
        bytes += existing.size;
        skipped++;
        continue;
      }
    }
    const out = await fetchUpstreamWithPolicy(proxyPath, '', 'GET', headers, Date.now() + UPSTREAM_BUDGET_MS);
    const result = out.out;
    const contentType = result && result.headers ? (result.headers.get('content-type') || '') : '';
    const softMissing = !!(result && !result.err && result.body && upstreamSaysMissing(result.status, contentType, result.body));
    if (result && !result.err && result.status === 200 && result.body && !softMissing && !upstreamIsPartial(result)) {
      const entry = cacheStore(proxyPath, result.body, contentType);
      rows.push({ path: raw, result: 'fetched', bytes: result.body.length, ms: result.ms, file: entry ? path.basename(entry.file) : null });
      bytes += result.body.length;
      ok++;
    } else if (softMissing) {
      /* 负缓存：上游确认不存在（或软 404）。落盘后，上游不可达时这条路径也是毫秒级返回。 */
      const entry = cacheStore(proxyPath, result.body, contentType || 'text/html', { neg: true, soft: result.status === 200, status: result.status });
      rows.push({ path: raw, result: result.status === 404 ? 'negative-404' : 'negative-soft-404', status: result.status, bytes: result.body.length, file: entry ? path.basename(entry.file) : null });
      bytes += result.body.length;
      negatives++;
    } else {
      rows.push({ path: raw, result: 'FAILED', status: result ? result.status : 0, err: result ? result.err : 'no-response', ms: result ? result.ms : null, attempts: out.attempts });
      failed++;
    }
  }
  try { cachePersist(); } catch (e) {}
  const summary = { total: paths.length, ok: ok, negatives: negatives, skipped: skipped, overlaySkipped: overlaySkipped, overlayPurged: overlayPurged, failed: failed, bytes: bytes, ms: Date.now() - started, cache: cacheSummary(), rows: rows };
  return summary;
}


/* ---------------- 包内持久化（客户端偏好 / 账号表） ----------------
   客户端 Preferences 与账号表落到便携包侧两个各自独立的 JSON 文件：
     client-prefs.json    —— 客户端全部偏好，按 key 存 JSON（Audio/Graphics/窗口位置/…）
     client-accounts.json —— 账号表，单独文件，不与偏好混存
   约束：只监听 127.0.0.1；写入原子（同目录临时文件 + rename）；保留上一版 .bak 备份；
        文件名只来自白名单且解析结果必须落在包目录内（防目录穿越）。 */
const PACKAGE_STATE_DIR = process.env.ROE_STATE_DIR ? path.resolve(process.env.ROE_STATE_DIR) : ROOT;
const PACKAGE_STATE_MAX_BYTES = 256 * 1024;
const PACKAGE_STATE_FILES = { prefs: 'client-prefs.json', accounts: 'client-accounts.json' };
const PACKAGE_PREF_KEY = /^[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}$/;
/* 带点键会按段展开成嵌套路径，这几段会改写对象原型，一律拒收 */
const PACKAGE_PREF_RESERVED_SEGMENTS = ['__proto__', 'prototype', 'constructor'];
const PACKAGE_PREF_KEY_MAX = 500;
const PACKAGE_ACCOUNT_MAX = 2000;

/* 文件名 → 包内绝对路径。白名单 + 目录内校验，任何越界输入直接抛错。 */
function packageFileInDir(name) {
  if (typeof name !== 'string' || !name || name !== path.basename(name) || name.indexOf('..') >= 0) {
    throw new Error('invalid package state file name: ' + String(name));
  }
  const root = path.resolve(PACKAGE_STATE_DIR);
  const resolved = path.resolve(root, name);
  if (resolved.indexOf(root + path.sep) !== 0) {
    throw new Error('package state path escapes package directory: ' + name);
  }
  return resolved;
}
function packageStatePath(state) {
  if (!Object.prototype.hasOwnProperty.call(PACKAGE_STATE_FILES, state)) {
    throw new Error('unknown package state: ' + String(state));
  }
  return packageFileInDir(PACKAGE_STATE_FILES[state]);
}
/* 包内状态文件不通过静态目录对外提供：偏好 / 账号库（加密件 + 一次性明文备份）/ 本机工具配置与缓存
   都是本机用户数据，绝不能经静态目录外泄。 */
const PACKAGE_STATE_ARTIFACTS = [
  PACKAGE_STATE_FILES.prefs, PACKAGE_STATE_FILES.accounts,
  'client-accounts.enc.json', 'client-accounts.json.plaintext-backup',
  /* 使用者本机皮肤根配置：本机数据，不随包分发、不经静态目录外泄（打包排除清单） */
  'skin-root.txt', path.basename(SKIN_ROOT_FILE)
];
function isPackageStateArtifact(rel) {
  const text = String(rel || '').replace(/\\/g, '/');
  let base = path.basename(text);
  if (base.charAt(0) === '.') base = base.slice(1);
  return PACKAGE_STATE_ARTIFACTS.some(function (file) {
    return base === file || base.indexOf(file + '.') === 0 || text.indexOf(file + '/') === 0;
  });
}
function readPackageState(state, fallback) {
  const file = packageStatePath(state);
  let raw;
  try {
    raw = fs.readFileSync(file, 'utf8');
  } catch (e) {
    if (e && e.code === 'ENOENT') return { file: file, data: fallback, exists: false };
    throw e;
  }
  try {
    return { file: file, data: JSON.parse(raw), exists: true };
  } catch (e) {
    throw new Error('state file is not valid JSON: ' + path.basename(file) + '（上一版保留在 ' + path.basename(file) + '.bak）');
  }
}
/* 原子写：同目录写临时文件 → rename 覆盖；覆盖前把上一版复制成 .bak。内容没变则不落盘、不刷备份。 */
function writePackageState(state, data) {
  const file = packageStatePath(state);
  const text = JSON.stringify(data, null, 2) + '\n';
  let previous = null;
  try {
    previous = fs.readFileSync(file, 'utf8');
  } catch (e) {}
  if (previous === text) return { file: file, changed: false, backup: false };
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = path.join(path.dirname(file), '.' + path.basename(file) + '.tmp-' + process.pid + '-' + Date.now());
  let backup = false;
  try {
    if (previous !== null) {
      fs.copyFileSync(file, file + '.bak');
      backup = true;
    }
    fs.writeFileSync(tmp, text, 'utf8');
    fs.renameSync(tmp, file);
  } catch (e) {
    try { fs.unlinkSync(tmp); } catch (e2) {}
    throw e;
  }
  return { file: file, changed: true, backup: backup };
}
/* 只接受本机页面 / file:// 启动器；公网页面既不能读也不能写包内数据。 */
function packageStateOriginAllowed(req) {
  const origin = req.headers.origin;
  if (!origin || origin === 'null') return true;
  let host;
  try { host = new URL(origin).hostname; } catch (e) { return false; }
  return host === '127.0.0.1' || host === 'localhost' || host === '::1';
}
function readJsonBody(req, res, fn) {
  let body = '';
  let tooLarge = false;
  req.on('data', function (chunk) {
    if (tooLarge) return;
    body += chunk;
    if (body.length > PACKAGE_STATE_MAX_BYTES) { tooLarge = true; body = ''; }
  });
  req.on('error', function () { try { json(res, 400, { ok: false, error: 'request error' }); } catch (e) {} });
  req.on('end', function () {
    if (tooLarge) return json(res, 413, { ok: false, error: 'payload too large' });
    let parsed;
    try { parsed = JSON.parse(body); } catch (e) { return json(res, 400, { ok: false, error: 'invalid json' }); }
    fn(parsed);
  });
}
/* 带点键按段展开：'Controls.snap' → Controls.snap 嵌套；段为空或命中保留段（原型改写）一律拒收。 */
function prefKeyAllowed(key) {
  if (!PACKAGE_PREF_KEY.test(key)) return false;
  const segments = key.split('.');
  for (let i = 0; i < segments.length; i++) {
    if (!segments[i] || PACKAGE_PREF_RESERVED_SEGMENTS.indexOf(segments[i]) >= 0) return false;
  }
  return true;
}
/* 把一个键写进（草稿）偏好表。中间层已存在但不是对象时报错，绝不覆盖成半截结构。 */
function assignPrefValue(state, key, value) {
  const segments = key.split('.');
  let node = state;
  for (let i = 0; i < segments.length - 1; i++) {
    const current = node[segments[i]];
    if (current === undefined) {
      const created = {};
      node[segments[i]] = created;
      node = created;
    } else if (current && typeof current === 'object' && !Array.isArray(current)) {
      node = current;
    } else {
      return 'pref key path conflicts with a non-object value: ' + segments.slice(0, i + 1).join('.');
    }
  }
  node[segments[segments.length - 1]] = value;
  return null;
}
/* 先在一个草稿上把整批写完：任何一键失败都整批拒绝，state 保持原样（先全量校验后落盘）。
   草稿只深拷贝会被写到的顶层键，成功后才回写 state。 */
function writePreferenceEntries(entries, state) {
  const draft = {};
  const keys = [];
  for (let i = 0; i < entries.length; i++) {
    const root = entries[i][0].split('.')[0];
    if (!Object.prototype.hasOwnProperty.call(draft, root)) {
      const current = state[root];
      draft[root] = current && typeof current === 'object' ? JSON.parse(JSON.stringify(current)) : current;
    }
  }
  for (let i = 0; i < entries.length; i++) {
    const conflict = assignPrefValue(draft, entries[i][0], entries[i][1]);
    if (conflict) return { error: conflict };
    keys.push(entries[i][0]);
  }
  Object.keys(draft).forEach(function (root) { state[root] = draft[root]; });
  return { keys: keys };
}
/* 偏好写入：单 key {key,value} 或批量 {keys:{...}}。
   普通键（无点）仍是顶层整键替换；带点键（'Controls.snap'）合并进嵌套结构 —— 客户端读的是
   嵌套对象，写成顶层扁平键会「写成功但读不到」。 */
function applyPrefsWrite(payload, state) {
  if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
    if (typeof payload.key === 'string') {
      if (!prefKeyAllowed(payload.key)) return { error: 'invalid pref key' };
      return writePreferenceEntries([[payload.key, payload.value === undefined ? null : payload.value]], state);
    }
    if (payload.keys && typeof payload.keys === 'object' && !Array.isArray(payload.keys)) {
      const names = Object.keys(payload.keys);
      if (!names.length) return { error: 'empty payload' };
      if (names.length > PACKAGE_PREF_KEY_MAX) return { error: 'too many pref keys' };
      for (let i = 0; i < names.length; i++) {
        if (!prefKeyAllowed(names[i])) return { error: 'invalid pref key: ' + names[i] };
      }
      const entries = names.map(function (name) { return [name, payload.keys[name]]; });
      return writePreferenceEntries(entries, state);
    }
  }
  return { error: 'invalid payload' };
}
/* 账号表写入：整表替换 {accounts:[...]} / 按账号名增改 {upsert:{account}} / 删除 {remove:"account"}。
   老接口只有账号名这一个身份（游戏客户端 autoLogin 时 rememberAccount 走的就是它），
   而账号库里同一个账号可能还是启动器写的 {id,label,user,server,password} 形状 ——
   所以「按账号名增改 / 删除」必须按账号名跨形状匹配（sameAccount 见下：账号名相同且服务器不冲突），
   否则同名会被当成两条记录插进去（这正是「一次新增出现 2 个账号」的来源）。 */
function applyAccountsWrite(payload, table) {
  const list = Array.isArray(table) ? table : [];
  if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
    if (Array.isArray(payload.accounts)) {
      if (payload.accounts.length > PACKAGE_ACCOUNT_MAX) return { error: 'too many accounts' };
      for (let i = 0; i < payload.accounts.length; i++) {
        const entry = payload.accounts[i];
        if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return { error: 'invalid account entry' };
      }
      return { accounts: dedupeAccountRecords(payload.accounts) };
    }
    if (payload.upsert && typeof payload.upsert === 'object' && !Array.isArray(payload.upsert)) {
      const name = payload.upsert.account;
      if (typeof name !== 'string' || !name.trim() || name.length > 64) return { error: 'invalid account name' };
      /* 匹配用的是 sameAccount（账号名相同且服务器不冲突）：账号名只认已经校验过的
         payload.upsert.account 本身，user / id 回退不参与，判据与 dedupeAccountRecords 一致。 */
      const probe = { account: name, server: accountServerKey(payload.upsert) };
      const matched = [];
      const kept = [];
      list.forEach(function (entry) {
        if (sameAccount(entry, probe)) matched.push(entry); else kept.push(entry);
      });
      /* 同一账号并成一条：新载荷里显式给出的字段为准，老记录里更全的字段补齐；
         同名但服务器冲突的记录各自原样保留，绝不并成一条；
         没有同名记录时就是老行为 —— 追加一条只有账号名的记录。 */
      let merged = payload.upsert;
      if (matched.length) {
        merged = mergeAccountRecords(matched[0], merged);
        for (let i = 1; i < matched.length; i++) kept.push(matched[i]);
      }
      return { accounts: dedupeAccountRecords(kept.concat([merged])) };
    }
    if (typeof payload.remove === 'string') {
      const key = payload.remove.trim().toLowerCase();
      if (!key) return { accounts: list.slice() };
      return { accounts: dedupeAccountRecords(list.filter(function (entry) { return accountNameKey(entry) !== key; })) };
    }
  }
  return { error: 'invalid payload' };
}
function handlePackageState(req, res, state) {
  if (!packageStateOriginAllowed(req)) return json(res, 403, { ok: false, error: 'origin not allowed' });
  const isPrefs = state === 'prefs';

  if (req.method === 'GET') {
    try {
      if (!isPrefs) {
        /* 账号表走加密保险箱：同一个接入点，避免出现第二份明文库；
           响应只给视图（不含 password），明文只经 /api/accounts/reveal 一次性交回 */
        const accounts = accountsStoreLoad();
        return json(res, 200, { ok: true, file: ACCOUNTS_ENC_FILE, accounts: accountViews(accounts), count: accounts.length, exists: fs.existsSync(accountsPaths().encrypted), crypto: ACCOUNTS_CRYPTO_MODE });
      }
      const current = readPackageState(state, {});
      if (!current.data || typeof current.data !== 'object' || Array.isArray(current.data)) {
        return json(res, 500, { ok: false, error: 'state file is not a preference map', file: path.basename(current.file) });
      }
      return json(res, 200, { ok: true, file: path.basename(current.file), prefs: current.data, count: Object.keys(current.data).length, exists: current.exists });
    } catch (e) {
      return json(res, 500, { ok: false, error: isPrefs ? (e && e.message ? e.message : String(e)) : accountsStoreErrorText(e) });
    }
  }

  if (req.method !== 'POST') return json(res, 405, { ok: false, error: 'method not allowed' });

  readJsonBody(req, res, function (payload) {
    try {
      if (!isPrefs) {
        const applied = applyAccountsWrite(payload, accountsStoreLoad());
        if (applied.error) return json(res, 400, { ok: false, error: applied.error });
        const written = accountsStoreSave(applied.accounts);
        return json(res, 200, { ok: true, file: ACCOUNTS_ENC_FILE, count: applied.accounts.length, changed: written.changed, permissions: written.permissions, crypto: ACCOUNTS_CRYPTO_MODE });
      }
      const current = readPackageState(state, {});
      if (!current.data || typeof current.data !== 'object' || Array.isArray(current.data)) {
        return json(res, 500, { ok: false, error: 'state file is not a preference map', file: path.basename(current.file) });
      }
      const applied = applyPrefsWrite(payload, current.data);
      if (applied.error) return json(res, 400, { ok: false, error: applied.error });
      const written = writePackageState('prefs', current.data);
      return json(res, 200, { ok: true, file: path.basename(written.file), keys: applied.keys, changed: written.changed, backup: written.backup });
    } catch (e) {
      return json(res, 500, { ok: false, error: isPrefs ? (e && e.message ? e.message : String(e)) : accountsStoreErrorText(e) });
    }
  });
}

/* ================= 账号加密保险箱（AES-256-GCM + scrypt，零依赖） =================
   落盘 client-accounts.enc.json；接入点就是 accountsStoreLoad / accountsStoreSave 两个函数
   （/api/accounts 与老的 /accounts 都走它们，不再有第二份明文库）。
   密钥 = scrypt(每装机随机盐, SHA-256(机器标识))。诚实说明：机器标识同机可读，所以它防的是
   「随手打开文件看 / 把文件拷给别人 / 误传」，防不住同机恶意软件，也防不住任何能以该账号
   运行程序的人（威胁模型与 PoC 一致）。
   错误文案固定：不含盐 / 密文 / 明文 / 账号名；权限收紧在 Unix 用 0600、Windows 用 icacls，
   失败如实报告（不假装成功）。 */
const ACCOUNTS_ENC_FILE = 'client-accounts.enc.json';
const ACCOUNTS_PLAIN_BACKUP_FILE = 'client-accounts.json.plaintext-backup';
const ACCOUNTS_CRYPTO_MODE = 'aes-256-gcm+scrypt';
const ACCOUNTS_ERROR_TEXT = '账号库不可用：无法解密（换机器 / 文件被改过 / 权限不足）或文件已损坏';
const VAULT_FILE_VERSION = 1;
const VAULT_AAD = Buffer.from('dsh-ro-accounts|v' + VAULT_FILE_VERSION, 'utf8');
const VAULT_KDF = { name: 'scrypt', N: 16384, r: 8, p: 1, keylen: 32, maxmem: 64 * 1024 * 1024 };

class VaultError extends Error {
  constructor(code) {
    super({
      auth: 'decrypt failed: integrity check',
      format: 'decrypt failed: malformed vault file',
      version: 'decrypt failed: unsupported vault version'
    }[code] || 'decrypt failed');
    this.name = 'VaultError';
    this.code = code;
  }
}
function wipeBuffer(buf) {
  if (Buffer.isBuffer(buf)) { try { buf.fill(0); } catch (e) {} }
  return buf;
}
/* 机器标识：对主机名 / 用户名 / 平台 / 架构 / 家目录做一次 SHA-256，明文不进任何日志。 */
function vaultMachineId() {
  let user = '';
  try { user = os.userInfo().username || ''; } catch (e) { user = String(process.env.USERNAME || process.env.USER || ''); }
  const facts = [
    'host=' + String(os.hostname() || ''), 'user=' + user,
    'plat=' + String(os.platform() || ''), 'arch=' + String(os.arch() || ''),
    'homedir=' + String(os.homedir() || '')
  ].join('|');
  return crypto.createHash('sha256').update('dsh-ro-machine-v1' + String.fromCharCode(0) + facts, 'utf8').digest('hex');
}
function vaultDeriveKey(salt) {
  if (!Buffer.isBuffer(salt) || salt.length < 16) throw new VaultError('format');
  return crypto.scryptSync('m:' + vaultMachineId(), salt, VAULT_KDF.keylen, { N: VAULT_KDF.N, r: VAULT_KDF.r, p: VAULT_KDF.p, maxmem: VAULT_KDF.maxmem });
}
function vaultEncrypt(value, salt) {
  const actualSalt = salt || crypto.randomBytes(32);
  const key = vaultDeriveKey(actualSalt);
  const iv = crypto.randomBytes(12);
  try {
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
    cipher.setAAD(VAULT_AAD);
    const plain = Buffer.from(JSON.stringify(value), 'utf8');
    let body;
    try { body = Buffer.concat([cipher.update(plain), cipher.final()]); }
    finally { wipeBuffer(plain); }
    return {
      v: VAULT_FILE_VERSION,
      kdf: { name: VAULT_KDF.name, salt: actualSalt.toString('base64'), n: VAULT_KDF.N, r: VAULT_KDF.r, p: VAULT_KDF.p, keylen: VAULT_KDF.keylen },
      cipher: { alg: 'aes-256-gcm', iv: iv.toString('base64'), tag: cipher.getAuthTag().toString('base64') },
      payload: body.toString('base64'),
      writtenAt: new Date().toISOString()
    };
  } finally { wipeBuffer(key); }
}
function vaultDecrypt(file) {
  if (!file || typeof file !== 'object') throw new VaultError('format');
  if (file.v !== VAULT_FILE_VERSION) throw new VaultError(file.v === undefined ? 'format' : 'version');
  const kdf = file.kdf, cipher = file.cipher;
  if (!kdf || kdf.name !== VAULT_KDF.name || !cipher || cipher.alg !== 'aes-256-gcm') throw new VaultError('format');
  let salt, iv, tag, body;
  try {
    salt = Buffer.from(String(kdf.salt || ''), 'base64');
    iv = Buffer.from(String(cipher.iv || ''), 'base64');
    tag = Buffer.from(String(cipher.tag || ''), 'base64');
    body = Buffer.from(String(file.payload || ''), 'base64');
  } catch (e) { throw new VaultError('format'); }
  if (salt.length < 16 || iv.length !== 12 || tag.length !== 16) throw new VaultError('format');
  const key = vaultDeriveKey(salt);
  let plain = null;
  try {
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAAD(VAULT_AAD);
    decipher.setAuthTag(tag);
    plain = Buffer.concat([decipher.update(body), decipher.final()]);
  } catch (e) {
    /* OpenSSL 的报错文本里没有明文，但仍然不放出去，统一成固定文案 */
    throw new VaultError('auth');
  } finally { wipeBuffer(key); }
  try {
    return JSON.parse(plain.toString('utf8'));
  } catch (e) {
    throw new VaultError('format');
  } finally {
    wipeBuffer(plain);
  }
}

function accountsPaths() {
  return {
    root: PACKAGE_STATE_DIR,
    encrypted: packageFileInDir(ACCOUNTS_ENC_FILE),
    legacyPlain: packageStatePath('accounts'),
    legacyBackup: packageFileInDir(ACCOUNTS_PLAIN_BACKUP_FILE)
  };
}
/* ---- 同一账号归并（账号名相同 + 服务器不冲突只留一行） ----
   背景：同一个账号名在账号库里会以两种形状并存 ——
     · 启动器写的 {id,label,user,server,password}（POST /api/accounts，按 id 增改）；
     · 老明文账号表 / 游戏客户端 autoLogin 时 rememberAccount 写的 {account:账号名}
       （POST /accounts，只有账号名，没有备注名 / 服务器 / 密码）。
   老形状记录的 id 会回退成账号名，和新形状的 id 不同 —— 按 id 永远合不到一起，账号簿于是
   同一个账号出现两行。这里统一按「账号名」认账号：user → account → id 依次回退。
   同一账号归并成一行（字段取更全的那份、密码以能取到密码的那条为准、id 用更全那条的），
   不同账号名一律各留一行 —— 绝不误删不同账号。
   「同一账号」= 账号名相同【且服务器不冲突】（sameAccount 见下）：账号簿里「服务器」是一列，
   同名刻意配两个不同服务器是合理用法，那种记录必须各留一行，绝不并成一条。 */
function accountNameOf(entry) {
  const raw = isPlainObject(entry) ? entry : {};
  const fields = [raw.user, raw.account, raw.id];
  for (let i = 0; i < fields.length; i++) {
    if (typeof fields[i] === 'string' && fields[i].trim()) return fields[i].trim();
  }
  return '';
}
/* 认账号用的键：大小写不敏感（同一个账号名不许因为大小写被当成两个账号） */
function accountNameKey(entry) { return accountNameOf(entry).toLowerCase(); }
/* 服务器的键：去空白 + 大小写不敏感；没填返回空串（空 = 这一列没填，不代表某个具体服务器） */
function accountServerKey(entry) {
  const raw = isPlainObject(entry) ? entry : {};
  return typeof raw.server === 'string' ? raw.server.trim().toLowerCase() : '';
}
/* 服务器不冲突：只有两边都填了非空且不同才算冲突（那时才是两个不同账号） */
function accountServerCompatible(a, b) {
  const first = accountServerKey(a);
  const second = accountServerKey(b);
  return !first || !second || first === second;
}
/* 同一个账号的判据：账号名相同【且服务器不冲突】。归并（dedupeAccountRecords）与按账号名
   增改（applyAccountsWrite 的 upsert）共用这一条，否则两条路径会得出不同结果。 */
function sameAccount(a, b) {
  const key = accountNameKey(a);
  return !!key && key === accountNameKey(b) && accountServerCompatible(a, b);
}
function accountValueEmpty(value) { return value === undefined || value === null || value === ''; }
/* 「谁的数据更全」：备注名 / 服务器 / 已存密码 里非空字段的个数 */
function accountRecordScore(entry) {
  const raw = isPlainObject(entry) ? entry : {};
  let score = 0;
  if (typeof raw.label === 'string' && raw.label.trim()) score++;
  if (typeof raw.server === 'string' && raw.server.trim()) score++;
  if (typeof raw.password === 'string' && raw.password) score++;
  return score;
}
/* 归并两条同名记录：更全的那条为准（连 id 一起用，界面上那一行不换身份），
   它缺的字段才从另一条补；lastUsedAt 取更晚的那个。调用方保证两条是同一个账号（sameAccount）。 */
function mergeAccountRecords(a, b) {
  const first = isPlainObject(a) ? a : {};
  const second = isPlainObject(b) ? b : {};
  const winner = accountRecordScore(second) >= accountRecordScore(first) ? second : first;
  const loser = winner === second ? first : second;
  const merged = Object.assign({}, loser, winner);
  Object.keys(loser).forEach(function (key) {
    if (accountValueEmpty(merged[key])) merged[key] = loser[key];
  });
  const stamps = [first.lastUsedAt, second.lastUsedAt].filter(function (value) { return typeof value === 'string' && value; }).sort();
  if (stamps.length) merged.lastUsedAt = stamps[stamps.length - 1];
  return merged;
}
/* 全表归并：同一账号只留一行（位置取第一次出现的那个，数据取更全的那份）。
   同名但服务器冲突的记录不是同一个账号 —— 各留一行。 */
function dedupeAccountRecords(list) {
  const source = Array.isArray(list) ? list : [];
  const out = [];
  const seen = new Map();
  for (let i = 0; i < source.length; i++) {
    const entry = source[i];
    if (!isPlainObject(entry)) continue;
    const key = accountNameKey(entry);
    /* 连账号名都没有的记录（不该出现）原样保留，绝不误删 */
    if (!key) { out.push(entry); continue; }
    const slots = seen.get(key);
    if (!slots) { seen.set(key, [out.length]); out.push(entry); continue; }
    /* 同名候选可能不止一个（服务器冲突的那几条各占一行）：并入第一条服务器不冲突的；
       一条记录只并入一行，全冲突就再开一行。 */
    let target = -1;
    for (let j = 0; j < slots.length; j++) {
      if (sameAccount(out[slots[j]], entry)) { target = slots[j]; break; }
    }
    if (target >= 0) { out[target] = mergeAccountRecords(out[target], entry); continue; }
    slots.push(out.length);
    out.push(entry);
  }
  return out;
}
function accountsNormalize(list) {
  const source = Array.isArray(list) ? list : [];
  const accounts = [];
  for (let i = 0; i < source.length; i++) if (isPlainObject(source[i])) accounts.push(source[i]);
  return { version: 1, updatedAt: new Date().toISOString(), accounts: dedupeAccountRecords(accounts) };
}
let accountsPermissions = null;
/* 权限收紧：Unix 0600；Windows 用 icacls 去掉继承、只留当前用户，失败如实报告。 */
function accountsHardenPermissions(file) {
  if (process.platform !== 'win32') {
    try { fs.chmodSync(file, 0o600); return { ok: true, mode: '0600', note: 'chmod 0600' }; }
    catch (e) { return { ok: false, mode: '0600', note: 'chmod failed: ' + (e && e.code ? e.code : 'error') }; }
  }
  const user = process.env.USERNAME || '';
  if (!user) return { ok: false, mode: 'acl', note: 'USERNAME unknown; 未收紧' };
  try {
    childProcess.execFileSync('icacls', [file, '/inheritance:r', '/grant:r', user + ':F'], { windowsHide: true, stdio: 'ignore' });
    return { ok: true, mode: 'acl', note: 'icacls inheritance:r + grant:r 当前用户' };
  } catch (e) {
    return { ok: false, mode: 'acl', note: 'icacls failed: ' + String(e && (e.code || e.status) ? (e.code || e.status) : 'error') };
  }
}
function vaultLoadAccounts(paths) {
  const p = paths || accountsPaths();
  if (!fs.existsSync(p.encrypted)) { const missing = new Error('no vault'); missing.code = 'ENOVAULT'; throw missing; }
  let file;
  try { file = JSON.parse(fs.readFileSync(p.encrypted, 'utf8')); }
  catch (e) { throw new VaultError('format'); }
  const value = vaultDecrypt(file);
  const accounts = value && Array.isArray(value.accounts) ? value.accounts : (Array.isArray(value) ? value : []);
  /* 读也归并：老包升级上来时库里可能已经躺着两条同名记录，读一次就该只剩一行。 */
  return accountsNormalize(accounts);
}
function vaultWriteAccounts(paths, list) {
  const p = paths || accountsPaths();
  fs.mkdirSync(p.root, { recursive: true });
  const body = Buffer.from(JSON.stringify(vaultEncrypt(accountsNormalize(list)), null, 2), 'utf8');
  const tmp = p.encrypted + '.tmp-' + process.pid + '-' + Date.now();
  try {
    fs.writeFileSync(tmp, body, { mode: 0o600 });
    /* 覆盖前留上一版密文（密文本身不可读，但同样不该丢，便于人工回滚） */
    if (fs.existsSync(p.encrypted)) { try { fs.copyFileSync(p.encrypted, p.encrypted + '.bak'); } catch (e) {} }
    fs.renameSync(tmp, p.encrypted);
  } catch (e) {
    try { fs.unlinkSync(tmp); } catch (e2) {}
    throw e;
  }
  accountsPermissions = accountsHardenPermissions(p.encrypted);
  return { file: p.encrypted, bytes: body.length, changed: true, permissions: accountsPermissions };
}
/* 旧的明文 client-accounts.json 自动迁移：加密写 → 一次性明文备份（权限收紧）→ 删原件。
   幂等：明文原件被删掉后这一支就再也不会命中；解析失败则原文件原样保留并报错。 */
function migrateLegacyAccounts(paths) {
  const p = paths || accountsPaths();
  if (!fs.existsSync(p.legacyPlain)) return { migrated: false, reason: 'no-legacy-file' };
  let legacy;
  try { legacy = JSON.parse(fs.readFileSync(p.legacyPlain, 'utf8')); }
  catch (e) {
    const bad = new Error('账号明文文件不是合法 JSON：' + path.basename(p.legacyPlain) + '（原文件未改动）');
    bad.code = 'ELEGACY';
    throw bad;
  }
  const accounts = Array.isArray(legacy) ? legacy : (isPlainObject(legacy) && Array.isArray(legacy.accounts) ? legacy.accounts : null);
  if (!accounts) {
    const bad = new Error('账号明文文件结构不对：' + path.basename(p.legacyPlain) + '（原文件未改动）');
    bad.code = 'ELEGACY';
    throw bad;
  }
  const records = [];
  for (let i = 0; i < accounts.length; i++) {
    if (!isPlainObject(accounts[i])) continue;
    const copy = Object.assign({}, accounts[i]);
    copy.id = accountStoredId(copy) || ('legacy-' + i);
    records.push(copy);
  }
  /* 老明文表里同名多条只留一行（迁移本身也不许造出重复账号） */
  const normalized = dedupeAccountRecords(records);
  const wrote = vaultWriteAccounts(p, normalized);
  fs.copyFileSync(p.legacyPlain, p.legacyBackup);
  const backupPermissions = accountsHardenPermissions(p.legacyBackup);
  fs.unlinkSync(p.legacyPlain);
  /* 旧实现的原子写会留下 client-accounts.json.bak —— 同样是明文。不删（留个后路），但权限一并收紧，
     并且静态目录已经挡住它；这里只收紧权限，绝不回显内容。 */
  const legacyBak = p.legacyPlain + '.bak';
  let legacyBakPermissions = null;
  if (fs.existsSync(legacyBak)) legacyBakPermissions = accountsHardenPermissions(legacyBak);
  log('账号库迁移：明文 ' + path.basename(p.legacyPlain) + ' → 加密 ' + path.basename(p.encrypted) + '（' + normalized.length + ' 条；一次性明文备份权限 ' + (backupPermissions.ok ? backupPermissions.mode : '未收紧') + (legacyBakPermissions ? '；旧 .bak 仍在，权限 ' + (legacyBakPermissions.ok ? legacyBakPermissions.mode : '未收紧') : '') + '）');
  return { migrated: true, count: normalized.length, backup: p.legacyBackup, removed: p.legacyPlain, bytes: wrote.bytes, permissions: wrote.permissions, backupPermissions: backupPermissions, legacyBak: legacyBakPermissions ? legacyBak : null };
}

/* ---- 登录令牌：/api/launch 发放 → /api/accounts/reveal 兑换密码（单次使用 / 30 秒过期） ---- */
const REVEAL_TOKEN_TTL_MS = Math.max(0, Number(process.env.ROE_REVEAL_TOKEN_TTL_MS || 30000));
const REVEAL_TOKEN_ERROR = '登录令牌无效或已过期';
const revealTokens = new Map();
function issueRevealToken(id, ttlMs) {
  const now = Date.now();
  revealTokens.forEach(function (value, key) { if (value.expiresAt <= now) revealTokens.delete(key); });
  const token = crypto.randomBytes(24).toString('base64url');
  revealTokens.set(token, { id: String(id == null ? '' : id), issuedAt: now, expiresAt: now + (ttlMs === undefined ? REVEAL_TOKEN_TTL_MS : Number(ttlMs)) });
  return token;
}
function consumeRevealToken(token) {
  const key = typeof token === 'string' && token ? token : '';
  const record = revealTokens.get(key);
  if (!record) return { ok: false };
  revealTokens.delete(key); /* 单次使用：不论后面校验成不成功，先烧掉 */
  if (record.expiresAt <= Date.now()) return { ok: false };
  return { ok: true, id: record.id };
}
/* 明文密码只以 Buffer 交给调用方（调用方负责 wipe），并把解析出来的 string 字段抹掉。
   注意：JSON.parse 产生的 JS 字符串无法可靠清零 —— 这是语言硬限制，不是这里偷懒。 */
function accountsPasswordBuffer(id) {
  const accounts = vaultLoadAccounts(accountsPaths()).accounts;
  let found = null;
  for (let i = 0; i < accounts.length; i++) {
    if (accountStoredId(accounts[i]) === id && typeof accounts[i].password === 'string' && accounts[i].password) { found = accounts[i]; break; }
  }
  const buffer = found ? Buffer.from(found.password, 'utf8') : null;
  for (let i = 0; i < accounts.length; i++) if (typeof accounts[i].password === 'string') accounts[i].password = '';
  return buffer;
}
/* 直接按字节拼 JSON 响应：不再额外造一个含密码的 JS 字符串，只转义 JSON 必须转义的字节。 */
const JSON_BYTE_QUOTE = String.fromCharCode(92, 34);
const JSON_BYTE_SLASH = String.fromCharCode(92, 92);
const JSON_BYTE_U = String.fromCharCode(92) + 'u';
function jsonEscapedBytes(buf) {
  const parts = [];
  let run = [];
  function flush() { if (run.length) { parts.push(Buffer.from(run)); run = []; } }
  for (let i = 0; i < buf.length; i++) {
    const b = buf[i];
    if (b === 0x22 || b === 0x5c || b < 0x20) {
      flush();
      const escape = b === 0x22 ? JSON_BYTE_QUOTE : (b === 0x5c ? JSON_BYTE_SLASH : (JSON_BYTE_U + ('000' + b.toString(16)).slice(-4)));
      parts.push(Buffer.from(escape, 'ascii'));
    } else {
      run.push(b);
    }
  }
  flush();
  return Buffer.concat(parts);
}
function sendRevealResponse(res, passwordBuffer) {
  const body = Buffer.concat([
    Buffer.from('{"ok":true,"password":"', 'utf8'),
    jsonEscapedBytes(passwordBuffer),
    Buffer.from('"}', 'utf8')
  ]);
  res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'content-length': body.length, 'cache-control': 'no-store' });
  res.end(body);
}
function handleApiAccountsReveal(req, res) {
  if (!packageStateOriginAllowed(req)) return json(res, 403, { ok: false, error: 'origin not allowed' });
  if (req.method !== 'POST') return json(res, 405, { ok: false, error: 'method not allowed' });
  readJsonBody(req, res, function (payload) {
    const id = isPlainObject(payload) && typeof payload.id === 'string' ? payload.id.trim() : '';
    const token = isPlainObject(payload) && typeof payload.token === 'string' ? payload.token : '';
    if (!id || id.length > ACCOUNT_ID_MAX) return json(res, 400, { ok: false, error: 'invalid account id' });
    const consumed = consumeRevealToken(token);
    if (!consumed.ok || consumed.id !== id) return json(res, 403, { ok: false, error: REVEAL_TOKEN_ERROR });
    let buffer = null;
    try {
      buffer = accountsPasswordBuffer(id);
    } catch (e) {
      log('账号读取失败：' + (e && e.name === 'VaultError' ? 'vault-' + e.code : 'storage-error'));
      return json(res, 500, { ok: false, error: ACCOUNTS_ERROR_TEXT });
    }
    if (!buffer) return json(res, 404, { ok: false, error: '账号不存在或没有保存密码' });
    try { sendRevealResponse(res, buffer); }
    finally { wipeBuffer(buffer); }
  });
}

/* ---- 环回本机页面判定（在线检测与页面注入共用一份判据） ----
   只认 Host 与 remoteAddress 都是环回：别的来源拿不到令牌，也不该被注入或回令牌。 */
function requestIsLoopbackLocalPage(req) {
  const host = String(req.headers.host || '').split(':')[0].toLowerCase();
  const remote = String(req.socket.remoteAddress || '');
  const remoteOk = remote === '127.0.0.1' || remote === '::1' || remote === '::ffff:127.0.0.1' || remote === '';
  return remoteOk && (host === '127.0.0.1' || host === 'localhost');
}

/* ---------------- 本机接口 /api/*（启动器契约） ----------------
   与旧接口的分工：/prefs、/accounts 保持老格式（{key,value}/{keys} 与 [{account}]）不动；
   /api/* 是启动器契约：偏好带版本号与更新时间，账号只投影出视图字段（绝不返回密码），
   并提供「应用窗口模式」开浏览器。

   安全约束（与上面一致）：
     · 只监听 127.0.0.1，且只有本机页面 / file:// 能读写（packageStateOriginAllowed）；
     · 状态文件复用上面的原子写（临时文件 + rename，覆盖前留 .bak）；
     · 任何响应 / 日志 / 错误里都不得出现密码值：账号对外只经 accountViewOf() 投影成
       {id,label,user,server,lastUsedAt,hasPassword}，password 永不进入响应。 */

/* /api/prefs 的版本号：进程内写入计数，GET 时给出，每次写入成功后 +1。 */
let apiPrefsVersion = 0;

/* 读偏好表。文件缺失按空表；损坏 / 结构不对抛错，由调用方转成 ok:false（不崩）。 */
function prefsStateRead() {
  const current = readPackageState('prefs', {});
  if (!current.data || typeof current.data !== 'object' || Array.isArray(current.data)) {
    throw new Error('state file is not a preference map: ' + path.basename(current.file));
  }
  return current;
}
function prefsUpdatedAt(file) {
  try { return fs.statSync(file).mtime.toISOString(); } catch (e) { return null; }
}
function isPlainObject(value) {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}
/* 深合并：普通对象逐键递归；数组与标量整体替换；保留段键（原型改写）直接拒绝。 */
function deepMergePrefs(target, patch) {
  Object.keys(patch).forEach(function (key) {
    if (PACKAGE_PREF_RESERVED_SEGMENTS.indexOf(key) >= 0) throw new Error('invalid pref key: ' + key);
    const value = patch[key];
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      const current = target[key];
      if (current && typeof current === 'object' && !Array.isArray(current)) deepMergePrefs(current, value);
      else target[key] = deepMergePrefs({}, value);
    } else {
      target[key] = value;
    }
  });
  return target;
}
/* ---------------- 启动器「画面与音效」→ 客户端真实偏好键 ----------------
   背景：启动器 14 个控件原来只写 Launcher.settings（客户端从不读它），所以改了不生效。
   这里把 Launcher.settings 翻译成客户端真正会读的键，和启动器自己那次 patch 在同一笔写入里落盘。

   为什么放在客户端服务而不是启动器：client-prefs.json 的写入点只有本函数（启动器 /api/prefs）与
   客户端自己（/prefs，见 Core/PackageState.js）；映射只在这里做，真实键就只有一个写入点。

   映射（键 → 引擎钩子）：
     graphics.quality      低/中/高 → Graphics.quality 50/75/100   Renderer.js resize 的分辨率倍率
     graphics.renderScale  "75%"…   → Graphics.renderScale         Renderer.js resize 的额外缩放（新键，默认 100）
     graphics.fps         30/60/90/120 → Graphics.fpslimit         Renderer.js frameLimit
     graphics.shadows     → Graphics.shadow                        Entity/EntityRender.js 人物与地面投影（新键，默认 true）
     graphics.particles   → Map.effect                             Renderer/EffectManager.js 特效渲染总闸
     graphics.weather     → Map.weather                            ScreenEffectManager.js 地图天气（新键，默认 true）
     audio.master × bgm   → Audio.BGM.volume                        Audio/BGM.js（引擎没有总音量键，主音量是乘数）
     audio.master × sfx   → Audio.Sound.volume                      Audio/SoundManager.js
     audio.muteBgm        → Audio.BGM.play = !muteBgm               Audio/BGM.js
     audio.muteSfx        → Audio.Sound.play = !muteSfx             Audio/SoundManager.js
   没有目标的项：
     graphics.vsync   —— 引擎里没有垂直同步开关（渲染循环固定 rAF），刻意不写任何键，见 round8 报告。
     graphics.uiSkin  —— 走 /ui-skin（ui-skin.json + 素材覆盖），不是偏好键。
   新键都带默认值（renderScale 100 / shadow true / weather true），所以「键缺失」= 与改动前逐字相同。 */
const LAUNCHER_QUALITY_VALUES = { 低: 50, 中: 75, 高: 100 };
/* 各偏好根的 _version 必须与客户端 Preferences.get 的版本号一致：
   不带（或带错）版本号时客户端会整根重置成默认值，写进去的键等于白写。 */
const LAUNCHER_PREF_VERSIONS = { Graphics: 1.1, Audio: 1.0, Map: 1.1 };

function launcherNumber(value, fallback) {
  const n = Number(value);
  return isFinite(n) ? n : fallback;
}
/* 画面质量：启动器给的是「低/中/高」；也接受客户端自己的 25..100 数字（同一把尺子） */
function launcherQuality(value) {
  if (typeof value === 'string' && Object.prototype.hasOwnProperty.call(LAUNCHER_QUALITY_VALUES, value)) {
    return LAUNCHER_QUALITY_VALUES[value];
  }
  const n = Number(value);
  if (!isFinite(n)) return LAUNCHER_QUALITY_VALUES['中'];
  return Math.max(25, Math.min(100, Math.round(n)));
}
function launcherRenderScale(value) {
  const n = parseInt(launcherNumber(typeof value === 'string' ? value.replace('%', '').trim() : value, 100), 10);
  if (!isFinite(n)) return 100;
  return Math.max(50, Math.min(200, Math.round(n)));
}
function launcherFpsLimit(value) {
  const n = Math.round(launcherNumber(value, 60));
  return [-1, 30, 60, 90, 120].indexOf(n) >= 0 ? n : 60;
}
/* 主音量 × 分路音量 → 0..1（引擎只有 BGM/Sound 两路音量，没有总音量键） */
function launcherVolume(masterPercent, channelPercent, fallbackChannel) {
  const master = launcherNumber(masterPercent, 80);
  const channel = launcherNumber(channelPercent, fallbackChannel);
  const value = (Math.max(0, Math.min(100, master)) / 100) * (Math.max(0, Math.min(100, channel)) / 100);
  return Math.round(Math.max(0, Math.min(1, value)) * 1000) / 1000;
}
/* 纯函数：Launcher.settings → 客户端真实键 patch。state 只用来判断「要不要带 _version」。 */
function launcherClientPrefsPatch(state, settings) {
  const s = isPlainObject(settings) ? settings : {};
  const g = isPlainObject(s.graphics) ? s.graphics : {};
  const a = isPlainObject(s.audio) ? s.audio : {};
  const existing = isPlainObject(state) ? state : {};
  /* 根对象已经存在（客户端自己维护了完整结构）时不要重复塞 _version，避免动到无关字段；
     根对象不存在时（全新包）必须自带版本号，否则客户端读回时按版本不符重置成默认值。 */
  function root(name, value) {
    return existing[name] === undefined ? { _version: LAUNCHER_PREF_VERSIONS[name], ...value } : value;
  }
  return {
    Graphics: root('Graphics', {
      quality: launcherQuality(g.quality),
      renderScale: launcherRenderScale(g.renderScale),
      fpslimit: launcherFpsLimit(g.fps),
      shadow: g.shadows !== false
    }),
    Map: root('Map', {
      effect: g.particles !== false,
      weather: g.weather !== false
    }),
    Audio: root('Audio', {
      BGM: {
        play: a.muteBgm !== true,
        volume: launcherVolume(a.master, a.bgm, 70)
      },
      Sound: {
        play: a.muteSfx !== true,
        volume: launcherVolume(a.master, a.sfx, 90)
      }
    })
  };
}

function handleApiPrefs(req, res) {
  if (!packageStateOriginAllowed(req)) return json(res, 403, { ok: false, error: 'origin not allowed' });
  if (req.method === 'GET') {
    try {
      const current = prefsStateRead();
      return json(res, 200, { ok: true, version: apiPrefsVersion, updatedAt: prefsUpdatedAt(current.file), prefs: current.data });
    } catch (e) {
      return json(res, 500, { ok: false, error: e && e.message ? e.message : String(e) });
    }
  }
  if (req.method !== 'POST') return json(res, 405, { ok: false, error: 'method not allowed' });

  readJsonBody(req, res, function (payload) {
    let current;
    try {
      current = prefsStateRead();
    } catch (e) {
      return json(res, 500, { ok: false, error: e && e.message ? e.message : String(e) });
    }
    if (!isPlainObject(payload)) {
      return json(res, 400, { ok: false, error: 'invalid payload: expected {patch} or {prefs}' });
    }
    if (Object.prototype.hasOwnProperty.call(payload, 'patch')) {
      if (!isPlainObject(payload.patch)) return json(res, 400, { ok: false, error: 'invalid payload: patch must be an object' });
      try {
        deepMergePrefs(current.data, payload.patch);
      } catch (e) {
        return json(res, 400, { ok: false, error: e && e.message ? e.message : String(e) });
      }
      /* 启动器「设置 → 画面与音效」写进 Launcher.settings 后，同一次写入里落到客户端真实键。
         真实键只有这一处写入点（见 launcherClientPrefsPatch 顶部注释）。 */
      if (isPlainObject(payload.patch.Launcher) && isPlainObject(payload.patch.Launcher.settings)) {
        deepMergePrefs(current.data, launcherClientPrefsPatch(current.data, payload.patch.Launcher.settings));
      }
    } else if (Object.prototype.hasOwnProperty.call(payload, 'prefs')) {
      if (!isPlainObject(payload.prefs)) return json(res, 400, { ok: false, error: 'invalid payload: prefs must be an object' });
      current.data = payload.prefs;
    } else {
      return json(res, 400, { ok: false, error: 'invalid payload: expected {patch} or {prefs}' });
    }
    try {
      writePackageState('prefs', current.data);
    } catch (e) {
      return json(res, 500, { ok: false, error: e && e.message ? e.message : String(e) });
    }
    apiPrefsVersion++;
    return json(res, 200, { ok: true, version: apiPrefsVersion });
  });
}

/* ---- 账号：存储读写单独抽成两个函数，加密层只换这两个 ----
   现在落盘是加密保险箱 client-accounts.enc.json（见下面「账号加密保险箱」段）；
   旧的明文 client-accounts.json 首次读取时自动迁移，迁移后不再有活的明文库。 */
const ACCOUNT_ID_MAX = 64;
const ACCOUNT_TEXT_MAX = 128;
const ACCOUNT_PASSWORD_MAX = 256;
function accountsStoreLoad() {
  const paths = accountsPaths();
  if (!fs.existsSync(paths.encrypted)) {
    /* 明文原件还在 → 迁移（幂等）；两样都没有就是空表 */
    const migration = migrateLegacyAccounts(paths);
    if (!migration.migrated) return [];
  }
  return vaultLoadAccounts(paths).accounts;
}
function accountsStoreSave(list) {
  return vaultWriteAccounts(accountsPaths(), list);
}
/* 账号类错误一律换成固定文案：绝不让盐 / 密文 / 明文 / 账号名从 HTTP 出去。 */
function accountsStoreErrorText(e) {
  if (e && e.code === 'ELEGACY') return '账号明文文件无法迁移：不是合法 JSON 或结构不对（原文件未改动，可人工处理）';
  return ACCOUNTS_ERROR_TEXT;
}
/* 存储记录的 id：新格式看 id，老格式（只有 account 账号名）兼容回退。 */
function accountStoredId(entry) {
  const raw = isPlainObject(entry) ? entry : {};
  if (typeof raw.id === 'string' && raw.id) return raw.id;
  if (typeof raw.account === 'string' && raw.account) return raw.account;
  return '';
}
/* 存储记录 → 对外视图：只读字段，不含 password，只给 hasPassword 布尔。 */
function accountViewOf(entry) {
  const raw = isPlainObject(entry) ? entry : {};
  const id = accountStoredId(raw);
  return {
    id: id,
    label: typeof raw.label === 'string' && raw.label ? raw.label : id,
    user: typeof raw.user === 'string' && raw.user ? raw.user : id,
    server: typeof raw.server === 'string' ? raw.server : '',
    lastUsedAt: typeof raw.lastUsedAt === 'string' && raw.lastUsedAt ? raw.lastUsedAt : null,
    hasPassword: typeof raw.password === 'string' && raw.password.length > 0
  };
}
function accountViews(list) {
  const out = [];
  for (let i = 0; i < list.length; i++) {
    const view = accountViewOf(list[i]);
    if (view.id) out.push(view);
  }
  return out;
}
function accountFieldText(source, key, fallback) {
  if (!Object.prototype.hasOwnProperty.call(source, key)) return { value: fallback };
  const value = source[key];
  if (value === null || value === undefined) return { value: '' };
  if (typeof value !== 'string' || value.length > ACCOUNT_TEXT_MAX) return { error: 'invalid account ' + key };
  return { value: value };
}
/* /api/accounts 写入：{upsert:{id,label,user,server}, password?} 或 {remove:{id}}。
   返回 { list }（新表）或 { error }；password 只用于写存储，绝不回显。 */
function applyApiAccountsWrite(payload, list) {
  if (!isPlainObject(payload)) return { error: 'invalid payload: expected {upsert} or {remove}' };
  if (Object.prototype.hasOwnProperty.call(payload, 'upsert')) {
    if (!isPlainObject(payload.upsert)) return { error: 'invalid payload: upsert must be an object' };
    const source = payload.upsert;
    const id = typeof source.id === 'string' ? source.id.trim() : '';
    if (!id || id.length > ACCOUNT_ID_MAX) return { error: 'invalid account id' };
    const next = list.slice();
    const index = next.findIndex(function (entry) { return accountStoredId(entry) === id; });
    const previous = index >= 0 && isPlainObject(next[index]) ? next[index] : {};
    const record = Object.assign({}, previous);
    record.id = id;
    const fields = ['label', 'user', 'server'];
    for (let i = 0; i < fields.length; i++) {
      const picked = accountFieldText(source, fields[i], typeof previous[fields[i]] === 'string' ? previous[fields[i]] : '');
      if (picked.error) return { error: picked.error };
      record[fields[i]] = picked.value;
    }
    if (Object.prototype.hasOwnProperty.call(payload, 'password')) {
      if (typeof payload.password !== 'string' || payload.password.length > ACCOUNT_PASSWORD_MAX) {
        return { error: 'invalid password' };
      }
      record.password = payload.password;
    }
    if (index >= 0) {
      next[index] = record;
    } else {
      if (next.length + 1 > PACKAGE_ACCOUNT_MAX) return { error: 'too many accounts' };
      next.push(record);
    }
    /* 按 id 增改是启动器的契约；同一个账号若还躺着另一条（老明文迁移 / 游戏客户端
       rememberAccount 造出来的 {account} 记录，服务器为空 = 不冲突），在这里并成一行，
       绝不让它变成两行；同名但服务器不同则是两条不同账号，各留一行。 */
    return { list: dedupeAccountRecords(next) };
  }
  if (Object.prototype.hasOwnProperty.call(payload, 'remove')) {
    if (!isPlainObject(payload.remove)) return { error: 'invalid payload: remove must be an object' };
    const id = typeof payload.remove.id === 'string' ? payload.remove.id.trim() : '';
    if (!id || id.length > ACCOUNT_ID_MAX) return { error: 'invalid account id' };
    return { list: dedupeAccountRecords(list.filter(function (entry) { return accountStoredId(entry) !== id; })) };
  }
  return { error: 'invalid payload: expected {upsert} or {remove}' };
}
function handleApiAccounts(req, res) {
  if (!packageStateOriginAllowed(req)) return json(res, 403, { ok: false, error: 'origin not allowed' });
  if (req.method === 'GET') {
    try {
      return json(res, 200, {
        ok: true,
        accounts: accountViews(accountsStoreLoad()),
        crypto: {
          mode: ACCOUNTS_CRYPTO_MODE,
          file: fs.existsSync(accountsPaths().encrypted) ? ACCOUNTS_ENC_FILE : null,
          permissions: accountsPermissions
        }
      });
    } catch (e) {
      return json(res, 500, { ok: false, error: accountsStoreErrorText(e) });
    }
  }
  if (req.method !== 'POST') return json(res, 405, { ok: false, error: 'method not allowed' });

  readJsonBody(req, res, function (payload) {
    let list;
    try {
      list = accountsStoreLoad();
    } catch (e) {
      return json(res, 500, { ok: false, error: accountsStoreErrorText(e) });
    }
    const applied = applyApiAccountsWrite(payload, list);
    if (applied.error) return json(res, 400, { ok: false, error: applied.error });
    let written = null;
    try {
      written = accountsStoreSave(applied.list);
    } catch (e) {
      return json(res, 500, { ok: false, error: accountsStoreErrorText(e) });
    }
    return json(res, 200, { ok: true, accounts: accountViews(applied.list), file: ACCOUNTS_ENC_FILE, bytes: written.bytes, permissions: written.permissions });
  });
}

const handleAccountTransfer = accountTransfer.createHandler({
  readPrefs: function () { return prefsStateRead().data; },
  readAccounts: function () {
    const paths = accountsPaths();
    if (fs.existsSync(paths.encrypted)) return vaultLoadAccounts(paths).accounts;
    if (fs.existsSync(paths.legacyPlain)) throw new accountTransfer.TransferError('legacy_migration_required', 409);
    return [];
  },
  commit: function (plan) {
    const entries = [{ file: packageStatePath('prefs'), bytes: Buffer.from(JSON.stringify(plan.prefs, null, 2) + '\n') }];
    if (plan.accounts) entries.push({ file: accountsPaths().encrypted, bytes: Buffer.from(JSON.stringify(vaultEncrypt(accountsNormalize(plan.accounts)), null, 2)) });
    accountTransfer.atomicCommit(entries);
    if (plan.accounts) accountsPermissions = accountsHardenPermissions(accountsPaths().encrypted);
    apiPrefsVersion++;
  }
}, packageStateOriginAllowed);

/* ---- /api/window：应用窗口模式开浏览器（无地址栏、无标签页） ----
   探测顺序：环境变量 LASTRO_BROWSER → 常见 Chrome 路径 → 常见 Edge 路径 → PATH 里的 chrome/msedge。
   打开参数固定 --app=<url> 与 --user-data-dir=<包目录内 browser-profile>；找不到就回中文错误。 */
const BROWSER_NOT_FOUND_CN = '未找到可用的浏览器：请安装 Chrome 或 Edge，或用环境变量 LASTRO_BROWSER 指定浏览器可执行文件路径';
const BROWSER_PROFILE_NAME = 'browser-profile';
function browserProfileDir() {
  return path.join(ROOT, BROWSER_PROFILE_NAME);
}
function browserFileExists(file) {
  try { return fs.statSync(file).isFile(); } catch (e) { return false; }
}
function browserCandidates(env) {
  env = env || process.env;
  const win = path.win32;
  const roots = [env.ProgramFiles, env['ProgramFiles(x86)'], env.LOCALAPPDATA, win.join('C:', 'Program Files'), win.join('C:', 'Program Files (x86)')];
  const out = [];
  for (let i = 0; i < roots.length; i++) {
    if (!roots[i]) continue;
    out.push(path.join(roots[i], 'Google', 'Chrome', 'Application', 'chrome.exe'));
  }
  for (let i = 0; i < roots.length; i++) {
    if (!roots[i]) continue;
    out.push(path.join(roots[i], 'Microsoft', 'Edge', 'Application', 'msedge.exe'));
  }
  return out;
}
function browserPathLookup(name, pathEnv) {
  const dirs = String(pathEnv || '').split(path.delimiter);
  const out = [];
  for (let i = 0; i < dirs.length; i++) if (dirs[i]) out.push(path.join(dirs[i], name));
  return out;
}
/* 纯探测函数：env / candidates / exists 都可注入，便于用假路径测失败分支（不启动浏览器）。 */
function findBrowserPath(opts) {
  opts = opts || {};
  const env = opts.env || process.env;
  const exists = opts.exists || browserFileExists;
  const candidates = opts.candidates || browserCandidates(env);
  const explicit = typeof env.LASTRO_BROWSER === 'string' ? env.LASTRO_BROWSER.trim() : '';
  if (explicit && exists(explicit)) return { path: explicit, source: 'env' };
  for (let i = 0; i < candidates.length; i++) {
    if (exists(candidates[i])) {
      return { path: candidates[i], source: /msedge(\.exe)?$/i.test(candidates[i]) ? 'edge' : 'chrome' };
    }
  }
  const names = ['chrome.exe', 'msedge.exe'];
  for (let n = 0; n < names.length; n++) {
    const dirs = browserPathLookup(names[n], env.PATH || env.Path);
    for (let i = 0; i < dirs.length; i++) if (exists(dirs[i])) return { path: dirs[i], source: 'path' };
  }
  return null;
}
/* 开窗记录：只记 URL 与时间，便于验收「/api/launch 确实复用了 /api/window 的打开路径」。 */
const browserLaunchLog = [];
function browserLaunchRecord(url) {
  browserLaunchLog.push({ at: new Date().toISOString(), url: url });
  if (browserLaunchLog.length > 50) browserLaunchLog.shift();
}
/* 起浏览器：返回 { ok, pid, browser, profile } 或 { error }。spawn 可注入，便于测试不真的开窗口。
   ROE_NO_BROWSER_SPAWN=1 或 opts.dryRun 时只解析并记账、不真的起进程（自动化测试用）。 */
function launchBrowserWindow(url, opts) {
  if (process.env.LASTRO_NATIVE_ONLY === '1') return { error: 'NATIVE_OWNED_WINDOW_REQUIRED' };
  opts = opts || {};
  browserLaunchRecord(url);
  const found = findBrowserPath(opts);
  if (!found) return { error: BROWSER_NOT_FOUND_CN };
  const profile = opts.profileDir || browserProfileDir();
  /* ROE_NO_BROWSER_SPAWN=1 只在没注入自定义 spawn 时生效：自动化测试既不真的开窗口，也能继续用假 spawn 断言参数 */
  if (opts.dryRun === true || (process.env.ROE_NO_BROWSER_SPAWN === '1' && !opts.spawn)) {
    return { ok: true, pid: null, browser: found.path, profile: profile, dryRun: true };
  }
  const args = ['--app=' + url, '--user-data-dir=' + profile];
  const spawnFn = opts.spawn || childProcess.spawn;
  try {
    const child = spawnFn(found.path, args, { detached: true, stdio: 'ignore' });
    if (child && typeof child.unref === 'function') child.unref();
    if (child && child.pid) clientSessionPids.add(child.pid);
    return { ok: true, pid: child && child.pid ? child.pid : null, browser: found.path, profile: profile };
  } catch (e) {
    return { error: '浏览器启动失败：' + (e && e.message ? e.message : String(e)) };
  }
}
/* 客户端页面地址（与 index.html 的 lineUrl 默认值一致） */
function clientPageUrl() { return 'http://127.0.0.1:' + PAGE_PORT + '/client/api.html'; }
/* POST /api/launch：发放一次性 reveal 令牌（薄别名）。
   默认「只发令牌、不抢窗口」：启动器自己用 window.open / POST /api/window 开游戏窗口，
   这里要是也开一次就会多出第二个窗口。需要客户端服务代开时显式传 {openWindow:true}，
   走的是与 /api/window 同一条 launchBrowserWindow 通道（不另写一套）。
   浏览器找不到也照发令牌 —— 拉窗失败不该让「读密码」跟着失败；窗口结果放在 window 字段里。 */
function handleApiLaunch(req, res) {
  if (!packageStateOriginAllowed(req)) return json(res, 403, { ok: false, error: 'origin not allowed' });
  if (req.method !== 'POST') return json(res, 405, { ok: false, error: 'method not allowed' });
  readJsonBody(req, res, function (payload) {
    if (process.env.LASTRO_NATIVE_ONLY === '1' && payload && payload.openWindow === true) return json(res, 409, { ok: false, error: 'NATIVE_OWNED_WINDOW_REQUIRED' });
    const raw = isPlainObject(payload)
      ? (typeof payload.id === 'string' ? payload.id : (typeof payload.accountId === 'string' ? payload.accountId : ''))
      : '';
    const id = raw.trim();
    if (id) {
      let found = false;
      try {
        const list = accountsStoreLoad();
        for (let i = 0; i < list.length; i++) if (accountStoredId(list[i]) === id) { found = true; break; }
      } catch (e) {
        return json(res, 500, { ok: false, error: accountsStoreErrorText(e) });
      }
      if (!found) return json(res, 404, { ok: false, error: '账号不存在' });
    }
    const token = issueRevealToken(id);
    const url = clientPageUrl();
    if (!(isPlainObject(payload) && payload.openWindow === true)) {
      return json(res, 200, { ok: true, token: token, pid: null, url: url, opened: false });
    }
    const opened = launchBrowserWindow(url);
    return json(res, 200, {
      ok: true,
      pid: opened.error ? null : opened.pid,
      token: token,
      url: url,
      opened: true,
      window: opened.error ? { ok: false, error: opened.error } : { ok: true, dryRun: opened.dryRun === true }
    });
  });
}
function handleApiWindow(req, res) {
  if (process.env.LASTRO_NATIVE_ONLY === '1') return json(res, 409, { ok: false, error: 'NATIVE_OWNED_WINDOW_REQUIRED' });
  if (!packageStateOriginAllowed(req)) return json(res, 403, { ok: false, error: 'origin not allowed' });
  if (req.method !== 'POST') return json(res, 405, { ok: false, error: 'method not allowed' });
  readJsonBody(req, res, function (payload) {
    const url = isPlainObject(payload) && typeof payload.url === 'string' ? payload.url.trim() : '';
    if (!url || url.length > 2048) return json(res, 400, { ok: false, error: 'url 必须是 http/https 地址' });
    let parsed = null;
    try { parsed = new URL(url); } catch (e) { parsed = null; }
    if (!parsed || (parsed.protocol !== 'http:' && parsed.protocol !== 'https:')) {
      return json(res, 400, { ok: false, error: 'url 只接受 http/https 地址' });
    }
    const opened = launchBrowserWindow(url);
    if (opened.error) return json(res, 503, { ok: false, error: opened.error });
    return json(res, 200, { ok: true, pid: opened.pid });
  });
}

const STARTED_AT = new Date().toISOString();

/* 自身（client-service.js）的 sha256 前 16 + 体积 / mtime：/health 暴露，
   启动器用它判断「磁盘上的代码已更新、但正在跑的进程还是旧的」。 */
const HELPER_FILE = __filename;
const HELPER_SHA256 = (function () {
  try { return crypto.createHash('sha256').update(fs.readFileSync(HELPER_FILE)).digest('hex'); } catch (e) { return ''; }
})();
const HELPER_SHA = HELPER_SHA256.slice(0, 16);
const HELPER_STAT = (function () {
  try { const st = fs.statSync(HELPER_FILE); return { size: st.size, mtimeMs: st.mtimeMs, mtime: new Date(st.mtimeMs).toISOString() }; } catch (e) { return { size: 0, mtimeMs: 0, mtime: '' }; }
})();

/* 物品图标：本地 TGA（item-icons-tga/item_<ID>.tga）。
   解析顺序「包内优先 → 包外兜底」：
     ① 包内  <包目录>/ro-images/item-icons-tga（下一版包把图标放进包内，解压到任何目录都自给自足）
     ② 包外  <包目录>/../ro-images/item-icons-tga（开发树 / 便携包把图标放在包外时的现状）
   两处都没有 → null：索引为空，图标请求全部回源上游。 */
const ITEM_ICON_RELATIVE = ['ro-images', 'item-icons-tga'];
function itemIconDirectories(root) {
  const base = path.resolve(root);
  return [
    path.join(base, ITEM_ICON_RELATIVE[0], ITEM_ICON_RELATIVE[1]),
    path.join(base, '..', ITEM_ICON_RELATIVE[0], ITEM_ICON_RELATIVE[1])
  ];
}
/* 按顺序取第一个真实存在的目录；都不存在返回 null。isDirectory 可注入，便于纯函数测试。 */
function pickItemIconDir(dirs, isDirectory) {
  const check = isDirectory || function (dir) {
    try { return fs.statSync(dir).isDirectory(); } catch (e) { return false; }
  };
  for (let i = 0; i < dirs.length; i++) if (check(dirs[i])) return dirs[i];
  return null;
}
const ITEM_ICON_DIRS = itemIconDirectories(ROOT);
const ITEM_ICON_DIR = pickItemIconDir(ITEM_ICON_DIRS);

/* LastRO/PR2 世界地图素材：本地直供，不回源（含 4 张底图、215 张地图小图与资料 JSON） */
const WORLD_MAP_DIR = path.join(ROOT, 'client_re', 'data', 'worldmap');
const WORLD_MAP_PATH_HEAD = '/client_re/data/worldmap/';
const WORLD_MAP_EXT = /\.(json|png|jpg|jpeg|bmp)$/i;
function worldMapLocalFile(rawPath) {
  if (String(rawPath).indexOf(WORLD_MAP_PATH_HEAD) !== 0) return null;
  let tail;
  try { tail = decodeURIComponent(String(rawPath).slice(WORLD_MAP_PATH_HEAD.length)); } catch (e) { return null; }
  if (!tail || !WORLD_MAP_EXT.test(tail)) return null;
  if (tail !== path.basename(tail) || tail.indexOf('..') >= 0) return null;
  const full = path.join(WORLD_MAP_DIR, tail);
  if (full.indexOf(WORLD_MAP_DIR + path.sep) !== 0) return null;
  try { return fs.statSync(full).isFile() ? full : null; } catch (e) { return null; }
}
const itemIconIndex = new Map();
if (ITEM_ICON_DIR) {
  try {
    for (const f of fs.readdirSync(ITEM_ICON_DIR)) {
      const m = /^item_(\d+)\.tga$/.exec(f);
      if (m) itemIconIndex.set(m[1], f);
    }
  } catch (e) {
    log('物品图标索引失败：' + (e && e.message ? e.message : e));
  }
}
/* 魔物缩略图：本地 PNG（ro-images/monster-sprites/mob_<ID>_<中文名>.png）。
   与物品图标同一套「包内优先 → 包外兜底」解析；按魔物 id 建索引，
   命中就本地直供 /mob-thumbs/<ID>.png，没命中由客户端回落到自己解码精灵。 */
const MOB_THUMB_RELATIVE = ['ro-images', 'monster-sprites'];
function mobThumbDirectories(root) {
  const base = path.resolve(root);
  return [
    path.join(base, MOB_THUMB_RELATIVE[0], MOB_THUMB_RELATIVE[1]),
    path.join(base, '..', MOB_THUMB_RELATIVE[0], MOB_THUMB_RELATIVE[1])
  ];
}
const MOB_THUMB_DIRS = mobThumbDirectories(ROOT);
/* 目录探测复用物品图标那套：pickItemIconDir 本身是通用的，只是先给图标用了 */
const MOB_THUMB_DIR = pickItemIconDir(MOB_THUMB_DIRS);
const MOB_THUMB_PATH_HEAD = '/mob-thumbs/';
const mobThumbIndex = new Map();
if (MOB_THUMB_DIR) {
  try {
    for (const f of fs.readdirSync(MOB_THUMB_DIR)) {
      const m = /^mob_(\d+)_/.exec(f);
      if (m && !mobThumbIndex.has(m[1])) mobThumbIndex.set(m[1], f);
    }
  } catch (e) {
    log('魔物缩略图索引失败：' + (e && e.message ? e.message : e));
  }
}

/* 部署配置（client/Config.local.js）里声明的游戏服地址：桥的白名单跟随它，
   换服/换域名只要改配置 + 重启服务，不需要改代码。读不到就退回部署里一直在用的地址。 */
function deployedServerAddresses() {
  try {
    const text = fs.readFileSync(path.join(ROOT, 'client', 'Config.local.js'), 'utf8');
    const found = [];
    const re = /"address"\s*:\s*"([^"]+)"/g;
    let m;
    while ((m = re.exec(text)) !== null) {
      const value = String(m[1] || '').trim();
      if (value) found.push(value);
    }
    return Array.from(new Set(found));
  } catch (e) {
    return [];
  }
}
const GAME_HOSTS = Array.from(new Set([process.env.ROE_GAME_HOST, ...deployedServerAddresses(), '45.248.10.247'].filter(Boolean).map(function (v) { return String(v).trim(); })));

/* 桥只允许 LastRO 三条线路在真实游戏服上的登录服、角色服与地图服（线路与端口见部署配置）。
   主机默认是部署配置里的地址；换服/换域名时用 ROE_GAME_HOST 覆盖（例如 game.lastro.cn），
   桥的白名单随之改变——这个常量仍是唯一的允许来源，依旧不做开放代理。 */
const GAME_HOST = String(process.env.ROE_GAME_HOST || deployedServerAddresses()[0] || '45.248.10.247').trim();
/* GAME_LOGIN_PORTS 是三条线路的登录端口：二转 26569、三转 28569、App 27569；
   GAME_AUX_PORTS 是角色服与地图服端口。桥只认这一张固定表，不做开放代理。 */
const GAME_LOGIN_PORTS = [26569, 28569, 27569];
const GAME_AUX_PORTS = [24322, 24323];
const GAME_PORTS = GAME_LOGIN_PORTS.concat(GAME_AUX_PORTS);
const ALLOW = GAME_PORTS.map(function (port) { return GAME_HOST + ':' + port; });

let officialProfiles = null;
let officialProfilesLoading = null;
function loadOfficialProfiles() {
  if (!officialProfilesLoading) {
    officialProfilesLoading = import('./client-update/official-profile-cache.mjs').then(function (module) {
      officialProfiles = module.createOfficialProfileCache({ cacheFile: path.join(CACHE_DIR, 'official-profiles.json'), log: log });
      return officialProfiles;
    });
  }
  return officialProfilesLoading;
}
function bridgeAllowed(host, port) {
  return (GAME_HOSTS.includes(String(host || '')) && GAME_PORTS.includes(Number(port))) ||
    Boolean(officialProfiles && officialProfiles.allows(String(host || ''), Number(port)));
}

/* 服务端下发的角色服/地图服地址可能是回环或内网地址，浏览器只能经本机桥访问，
   这里改写回真实游戏服 IP、端口保持不变。改写只会把「本来就会被白名单拒绝」的
   地址换成白名单主机，端口依旧要落在白名单内，因此不放大任何可达范围。
   isLoopbackOrPrivateHost 覆盖回环、私有网段（10/8、172.16/12、192.168/16）与链路本地（169.254/16）。 */
function isLoopbackOrPrivateHost(host) {
  const h = String(host || '').trim().toLowerCase();
  if (h === 'localhost' || h === '::1' || h === '0.0.0.0') return true;
  const v4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(h);
  if (!v4) return false;
  for (let i = 1; i <= 4; i++) { if (Number(v4[i]) > 255) return false; }
  const a = Number(v4[1]), b = Number(v4[2]);
  if (a === 127) return true;                        /* 回环 127.0.0.0/8 */
  if (a === 10) return true;                         /* 私有 10.0.0.0/8 */
  if (a === 172 && b >= 16 && b <= 31) return true;  /* 私有 172.16.0.0/12 */
  if (a === 192 && b === 168) return true;           /* 私有 192.168.0.0/16 */
  if (a === 169 && b === 254) return true;           /* 链路本地 169.254.0.0/16 */
  return false;
}

function mapTarget(host, port) {
  if (isLoopbackOrPrivateHost(host)) {
    const latestHost = officialProfiles ? officialProfiles.privateTarget(port, GAME_HOST) : GAME_HOST;
    return { host: latestHost || host, port: port, rewritten: Boolean(latestHost) };
  }
  return { host: host, port: port, rewritten: false };
}

/* 反代白名单前缀（防止被当开放代理） */
const PROXY_PREFIXES = ['/client_re/', '/statics/', '/ro/'];
/* CORS：三个反代前缀的响应统一带跨域头（含 OPTIONS 预检本地应答），
   原站页面 / 任意端口的宿主页都能直接读取本机镜像数据 */
const CORS_HEADERS = {
  'access-control-allow-origin': '*',
  'access-control-allow-methods': 'GET, HEAD, OPTIONS',
  'access-control-allow-headers': 'range, if-none-match, if-modified-since, content-type'
};

/* file:// 双击启动的启动器：带 content-type 的 POST 前浏览器先发 OPTIONS 预检（Origin: null）。
   只对 /api/* 契约接口本地 204 应答，给最小 CORS 头；
   预检只回头，不放宽任何读写判据 —— GET / POST 依旧走 packageStateOriginAllowed。 */
const API_PATHS = ['/api/health', '/api/prefs', '/api/accounts', '/api/accounts/reveal', '/api/launch', '/api/window', '/api/shortcut'];
const API_CORS_HEADERS = {
  'access-control-allow-origin': '*',
  'access-control-allow-methods': 'GET, POST, OPTIONS',
  'access-control-allow-headers': 'content-type'
};

/* 韩文目录名的 GBK 变体：官方数据里目录名是「CP949 字节按 GBK 解读」的结果 */
const gbkPathCache = new Map();
function gbkVariant(p) {
  let decoded;
  try { decoded = decodeURIComponent(p); } catch (e) { return null; }
  if (!/[\u0080-\u00ff]/.test(decoded)) return null;
  let decoder;
  try { decoder = new TextDecoder("gbk"); } catch (e) { return null; }
  return decoded.split("/").map(function (seg) {
    if (!/[\u0080-\u00ff]/.test(seg)) return seg;
    const bytes = Buffer.from(seg.split("").map(function (c) { return c.charCodeAt(0) & 0xff; }));
    let dec;
    try { dec = decoder.decode(bytes); } catch (e) { return seg; }
    return dec.indexOf("\ufffd") >= 0 ? seg : dec;
  }).join("/");
}

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.txt': 'text/plain; charset=utf-8',
  '.xml': 'text/xml; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.bmp': 'image/bmp', '.ico': 'image/x-icon',
  '.svg': 'image/svg+xml', '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf',
  '.otf': 'font/otf', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg',
  '.grf': 'application/octet-stream', '.zip': 'application/zip', '.gz': 'application/gzip'
};

function mimeOf(p) { return MIME[path.extname(p).toLowerCase()] || 'application/octet-stream'; }
function log() { console.log.apply(console, ['[' + new Date().toTimeString().slice(0, 8) + ']'].concat(Array.prototype.slice.call(arguments))); }
function json(res, code, obj) {
  // 允许 file:// 打开的启动器读取本机状态（只影响 /health、/requests 这两个只读接口）
  const body = Buffer.from(JSON.stringify(obj, null, 2), 'utf8');
  res.writeHead(code, { 'access-control-allow-origin': '*',  'content-type': 'application/json; charset=utf-8', 'content-length': body.length, 'cache-control': 'no-store' });
  res.end(body);
}

const bridgeStats = { connections: 0, lastTarget: null, lastAt: null, errors: 0, timeouts: 0, denied: [], live: [] };
const proxyStats = { requests: 0, bytes: 0, lastPath: null, notFound: 0, softNotFound: 0, timeouts: 0, failures: 0, down: 0 };
const reqLog = [];

/* ---------------- 连线自检（启动时跑一次；结果进日志与 /health） ----------------
   玩家报“连不上”时不用开控制台、不用复制粘贴：日志与 /health.connectivity 直接给结论。
   只做连接与 WebSocket 握手，**不发任何登录包**，也不参与游戏连接本身：
     ① 中转：部署配置里的 socketProxy（如 wss://port.lastro.cn/）+ 游戏服地址 → 客户端默认走这条；
     ② 直连：游戏服地址的 TCP（本机 5999 桥与“直连模式”走这条）。
   探测有超时、不重试、不阻塞启动。 */
let connectDiagnostics = { at: null, socketProxy: null, host: null, relay: [], direct: [] };

function deployedSocketProxy() {
  try {
    const file = path.join(ROOT, 'client', 'Config.local.js');
    const m = fs.readFileSync(file, 'utf8').match(/"socketProxy"\s*:\s*"([^"]*)"/);
    return m ? m[1] : null;
  } catch (e) {
    return null;
  }
}

function tcpDial(host, port, ms) {
  return new Promise(function (resolve) {
    const started = Date.now();
    const sock = net.connect({ host: host, port: port });
    let done = false;
    const finish = function (ok, detail) {
      if (done) return;
      done = true;
      try { sock.destroy(); } catch (e) { /* ignore */ }
      resolve({ port: port, ok: ok, ms: Date.now() - started, detail: detail });
    };
    sock.setTimeout(ms);
    sock.on('connect', function () { finish(true, 'ok'); });
    sock.on('timeout', function () { finish(false, 'timeout'); });
    sock.on('error', function (e) { finish(false, (e && e.code) || 'error'); });
  });
}

function relayHandshake(proxy, host, port, ms) {
  return new Promise(function (resolve) {
    if (typeof WebSocket !== 'function') {
      return resolve({ port: port, ok: false, ms: 0, detail: 'no-websocket' });
    }
    const url = String(proxy).replace(/\/?$/, '/') + host + ':' + port;
    const started = Date.now();
    let settled = false;
    let ws;
    const finish = function (ok, detail) {
      if (settled) return;
      settled = true;
      try { ws.close(); } catch (e) { /* ignore */ }
      resolve({ port: port, ok: ok, ms: Date.now() - started, detail: detail });
    };
    try { ws = new WebSocket(url); } catch (e) { return finish(false, 'bad-url'); }
    ws.onopen = function () {
      /* 中转接受之后再看它是否立刻把上游错误变成关闭 */
      setTimeout(function () { finish(ws.readyState === 1, ws.readyState === 1 ? 'open' : 'closed-after-open'); }, 1200);
    };
    ws.onerror = function () { finish(false, 'ws-error'); };
    ws.onclose = function (ev) { finish(false, 'closed:' + ((ev && ev.code) || 0)); };
    setTimeout(function () { finish(false, 'timeout'); }, ms);
  });
}

async function probeConnectivity() {
  const proxy = deployedSocketProxy();
  const host = GAME_HOST;
  const ports = GAME_LOGIN_PORTS.slice();
  const direct = await Promise.all(ports.map(function (port) { return tcpDial(host, port, 4000); }));
  const relay = proxy ? await Promise.all(ports.map(function (port) { return relayHandshake(proxy, host, port, 8000); })) : [];
  connectDiagnostics = { at: new Date().toISOString(), socketProxy: proxy, host: host, direct: direct, relay: relay };
  const mark = function (list) { return list.length ? list.map(function (r) { return r.port + (r.ok ? '✓' : '✗'); }).join(' ') : '未测'; };
  log('连线自检：socketProxy=' + (proxy || '未配置（客户端会自行直连）') + '｜中转 ' + mark(relay) + '｜直连 TCP ' + mark(direct));
  if (relay.length && relay.every(function (r) { return !r.ok; })) {
    log('连线自检：三条线路的中转都不通，玩家可能连不上（查网络或部署里的 socketProxy 地址）');
  } else if (relay.some(function (r) { return r.ok; }) && !direct.some(function (d) { return d.ok; })) {
    log('连线自检：中转可用、直连不通（正常现象：本机直连游戏服被拦，客户端应走中转）');
  }
  return connectDiagnostics;
}

/* /health 的响应体：/api/health 是它的薄别名（启动器契约要求同结构）。 */
/* 装过更新之后，「当前装在盘上的是哪个版本」只有一个可信来源：更新事务提交时写下的
   installed-version.json（它的 payload 由 feed 签名绑定）。没有就退回包内配置里的版本号，
   并标明来源 —— 猜一个版本号比读不出来更糟。 */
function installedVersionInfo() {
  try {
    const receipt = JSON.parse(fs.readFileSync(path.join(ROOT, '.client-update', 'installed-version.json'), 'utf8'));
    const payload = JSON.parse(Buffer.from(String((receipt.envelope && receipt.envelope.payload) || ''), 'base64').toString('utf8'));
    if (payload && typeof payload.version === 'string' && payload.version) return { version: payload.version, source: 'installed-version.json' };
  } catch (e) { /* 还没装过自动更新 */ }
  try {
    const config = JSON.parse(fs.readFileSync(CLIENT_UPDATE_CONFIG_FILE, 'utf8'));
    if (typeof config.currentVersion === 'string' && config.currentVersion) return { version: config.currentVersion, source: 'client-update.config.json' };
  } catch (e) { /* 也没配置更新通道 */ }
  return { version: null, source: null };
}

/* 这份包自己的版本标签：包内 client/api.html 的 BUILD（打包与内部化都会改写它）。
   它回答的是「现在跑着的这份包是哪个 build」，与上面「自动更新装到哪个版本」是两件事：
   installedVersion 的取值与优先级一个字都不动，这里只多给界面一个显示用的版本。
   读文件全程容错：缺失 / 读不了 / 形状不对都返回 null，调用方退回原行为，绝不抛。 */
const PACKAGE_BUILD_FILE = path.join(ROOT, 'client', 'api.html');
const PACKAGE_BUILD_RE = /\bvar\s+BUILD\s*=\s*["']([A-Za-z0-9._-]{1,64})["']/;
function packageVersionInfo() {
  try {
    const html = fs.readFileSync(PACKAGE_BUILD_FILE, 'utf8');
    const found = PACKAGE_BUILD_RE.exec(html);
    if (found && found[1] && /[0-9]/.test(found[1])) return { version: found[1], source: 'client/api.html' };
  } catch (e) { /* 包内没有版本文件：当作读不到，退回原行为 */ }
  return { version: null, source: null };
}
function healthPayload() {
  const overlay = overlaySelfCheck();
  const pkgVersion = packageVersionInfo();
  return {
    ok: true, engine: 'roBrowserLegacy', upstream: UPSTREAM,
    page: 'http://127.0.0.1:' + PAGE_PORT + '/', bridge: 'ws://127.0.0.1:' + BRIDGE_PORT + '/',
    allow: ALLOW, bridgeStats: bridgeStats, proxyStats: proxyStats, started: STARTED_AT,
    /* 中文覆盖自检：ok / 缺失或空表 / 各表 sha256 前 16 / 抽查物品名 */
    overlay: {
      ok: overlay.ok,
      missing: overlay.missing,
      empty: overlay.empty,
      errors: overlay.errors,
      leaked: overlay.leaked,
      sha: overlay.sha,
      shaMismatch: overlay.shaMismatch,
      probes: overlay.probes,
      gbkChecked: overlay.gbkChecked,
      dir: path.join('client_re', 'data')
    },
    /* 当前装着的版本号及其来源；启动自检与「起得来」证明都读这里 */
    installedVersion: installedVersionInfo().version,
    installedVersionSource: installedVersionInfo().source,
    /* 这份包自己的版本（显示用）：与上面并存，读不到就是 null */
    packageVersion: pkgVersion.version,
    packageVersionSource: pkgVersion.source,
    /* 下一次启动的轻量自检结果（版本号 + 关键文件清单） */
    selfCheck: clientSelfCheckReport,
    /* 连线自检：启动时自动探测一次，玩家报“连不上”时直接看这里，不用开控制台 */
    connectivity: connectDiagnostics,
    /* 自身代码指纹：启动器据此提示「进程是旧版本」 */
    helperSha: HELPER_SHA,
    helperFile: { sha: HELPER_SHA, sha256: HELPER_SHA256, size: HELPER_STAT.size, mtime: HELPER_STAT.mtime, mtimeMs: HELPER_STAT.mtimeMs, started: STARTED_AT },
    packageState: { dir: PACKAGE_STATE_DIR, files: PACKAGE_STATE_FILES, encryptedFile: ACCOUNTS_ENC_FILE },
    upstreamPolicy: { timeoutMs: UPSTREAM_TIMEOUT_MS, budgetMs: UPSTREAM_BUDGET_MS, retries: UPSTREAM_RETRIES, bufferMax: PROXY_BUFFER_MAX, cooldownMs: UPSTREAM_COOLDOWN_MS, downUntil: upstreamDownUntil || 0, downReason: upstreamDownReason },
    cache: cacheSummary(),
    /* 在线检测：关窗自退的现状。seen:false = 还没有页面接入过，此时不会自退。 */
    presence: {
      enabled: presence.enabled, seen: presence.seen, online: presence.online.size,
      lastHeartbeat: presence.lastHeartbeat ? new Date(presence.lastHeartbeat).toISOString() : null,
      exitAt: presence.deadline ? new Date(presence.deadline).toISOString() : null,
      exitReason: presence.reason || null,
      graceMs: PRESENCE_GRACE_MS, byeGraceMs: PRESENCE_BYE_GRACE_MS
    },
    crypto: ACCOUNTS_CRYPTO_MODE,
    inflight: Array.from(proxyInFlight.entries()).map(function (pair) { return { url: pair[0], ageMs: Date.now() - pair[1] }; }).slice(0, 20)
  };
}

/* ---------------- 桌面快捷方式（POST /api/shortcut） ----------------
   安全红线（照做，别放宽）：
     · 不收任何路径参数：落地目录固定「桌面」，目标固定本客户端服务目录下的 启动客户端.cmd，
       工作目录固定本客户端服务目录，图标固定 assets/ui/client.ico；
     · 只接受来自本客户端服务自己提供的页面：Origin（没有就看 Referer）的 host+port
       必须等于 http://127.0.0.1:<本客户端服务的端口>，否则 403 —— 公网页面、别的端口的页面、
       file:// 一律建不了；
     · 幂等：同名 .lnk 已存在就原地更新目标，不会多出一个；
     · 失败一律回中文人话原因。
   自动化测试口子：ROE_SHORTCUT_DIR 覆盖落地目录（仅测试用，必须是绝对路径）。 */
const SHORTCUT_NAME = 'LastRO 仙境传说';
const SHORTCUT_TARGET_REL = '启动客户端.cmd';
const SHORTCUT_ICON_REL = path.join('assets', 'ui', 'client.ico');
const SHORTCUT_DESC = 'LastRO 仙境传说 · 启动客户端';
const SHORTCUT_DIR_OVERRIDE = process.env.ROE_SHORTCUT_DIR ? path.resolve(process.env.ROE_SHORTCUT_DIR) : null;

/* 来源必须是本客户端服务自己的页面：host 只能是本机，端口必须等于本客户端服务的页面端口 */
function shortcutOriginAllowed(req) {
  const raw = String(req.headers.origin || req.headers.referer || '').trim();
  if (!raw || raw === 'null') return false;
  let parsed;
  try { parsed = new URL(raw); } catch (e) { return false; }
  const host = parsed.hostname.toLowerCase();
  if (host !== '127.0.0.1' && host !== 'localhost' && host !== '[::1]' && host !== '::1') return false;
  const port = parsed.port || (parsed.protocol === 'https:' ? '443' : '80');
  return Number(port) === Number(PAGE_PORT);
}

function vbsText(value) { return '"' + String(value).replace(/"/g, '""') + '"'; }

/* 用 Windows 脚本宿主（WScript.Shell）建 .lnk。脚本写成 UTF-16LE + BOM，中文名字才不串码；
   结果写进一个 UTF-16LE 状态文件（不靠管道），返回 { ok, dir, link, error }。 */
function makeShortcutFile(dir, target, work, icon) {
  const stamp = process.pid + '-' + Date.now();
  const vbsFile = path.join(os.tmpdir(), 'ro-shortcut-' + stamp + '.vbs');
  const outFile = path.join(os.tmpdir(), 'ro-shortcut-' + stamp + '.txt');
  const dirExpr = SHORTCUT_DIR_OVERRIDE ? vbsText(dir) : 'shell.SpecialFolders("Desktop")';
  const script = [
    'On Error Resume Next',
    'Dim fso, shell, sc, dir, target, work, iconPath, link, msg',
    'Set fso = CreateObject("Scripting.FileSystemObject")',
    'Set shell = CreateObject("WScript.Shell")',
    'statusFile = ' + vbsText(outFile),
    'If shell Is Nothing Then',
    '  report "5", "系统脚本宿主不可用（WScript.Shell 创建失败）", ""',
    '  WScript.Quit 0',
    'End If',
    'dir = ' + dirExpr,
    'target = ' + vbsText(target),
    'work = ' + vbsText(work),
    'iconPath = ' + vbsText(icon),
    'If Not fso.FolderExists(dir) Then',
    '  report "1", "桌面目录不存在：" & dir, ""',
    'ElseIf Not fso.FileExists(target) Then',
    '  report "2", "启动文件不存在：" & target, ""',
    'ElseIf Not fso.FileExists(iconPath) Then',
    '  report "3", "图标文件不存在：" & iconPath, ""',
    'Else',
    '  link = fso.BuildPath(dir, ' + vbsText(SHORTCUT_NAME) + ' & ".lnk")',
    '  Set sc = shell.CreateShortcut(link)',
    '  sc.TargetPath = target',
    '  sc.WorkingDirectory = work',
    '  sc.IconLocation = iconPath & ",0"',
    '  sc.Description = ' + vbsText(SHORTCUT_DESC),
    '  sc.Save',
    '  If Err.Number <> 0 Then',
    '    report "4", "写快捷方式失败（" & Err.Number & "）：" & Err.Description, ""',
    '  Else',
    '    report "0", "", link',
    '  End If',
    'End If',
    'WScript.Quit 0',
    '',
    'Sub report(code, message, linkPath)',
    '  Dim f',
    '  Set f = fso.CreateTextFile(statusFile, True, True)',
    '  f.WriteLine code',
    '  f.WriteLine message',
    '  f.WriteLine linkPath',
    '  f.Close',
    'End Sub'
  ].join('\r\n');
  try {
    fs.writeFileSync(vbsFile, '\ufeff' + script, 'utf16le');
  } catch (e) {
    return { ok: false, error: '写测试脚本失败：' + e.message };
  }
  let exitCode = null, ran = true;
  try {
    const r = childProcess.spawnSync('cscript.exe', ['//nologo', '//B', vbsFile], { stdio: 'ignore', timeout: 30000, windowsHide: true });
    exitCode = r.status;
    if (r.error) { ran = false; exitCode = null; }
  } catch (e) {
    ran = false;
  }
  let raw = '';
  try { raw = fs.readFileSync(outFile, 'utf16le'); } catch (e) { raw = ''; }
  try { fs.unlinkSync(vbsFile); } catch (e) {}
  try { fs.unlinkSync(outFile); } catch (e) {}
  raw = raw.replace(/^\ufeff/, '');
  const parts = raw.split(/\r?\n/);
  if (!parts.length || !parts[0]) {
    return { ok: false, error: ran ? '快捷方式脚本没有回报结果（退出码 ' + exitCode + '）' : '调不起 Windows 脚本宿主（cscript.exe）' };
  }
  if (parts[0] !== '0') return { ok: false, error: parts[1] || ('创建失败（代码 ' + parts[0] + '）') };
  return { ok: true, dir: dir, link: parts[2] || path.join(dir, SHORTCUT_NAME + '.lnk') };
}

function handleApiShortcut(req, res) {
  if (req.method !== 'POST') return json(res, 405, { ok: false, error: '只支持 POST' });
  if (!shortcutOriginAllowed(req)) return json(res, 403, { ok: false, error: '只能由本机这一页自己发起（来源地址不是本页面），已拒绝' });
  if (SHORTCUT_DIR_OVERRIDE && !path.isAbsolute(SHORTCUT_DIR_OVERRIDE)) return json(res, 500, { ok: false, error: 'ROE_SHORTCUT_DIR 必须是绝对路径' });
  const work = ROOT;
  const target = path.join(work, SHORTCUT_TARGET_REL);
  const icon = path.join(work, SHORTCUT_ICON_REL);
  let dir = SHORTCUT_DIR_OVERRIDE || '';
  if (dir) {
    try { fs.mkdirSync(dir, { recursive: true }); } catch (e) {
      return json(res, 500, { ok: false, error: '落地目录建不出来：' + dir });
    }
  }
  const existed = dir ? fs.existsSync(path.join(dir, SHORTCUT_NAME + '.lnk')) : null;
  const result = makeShortcutFile(dir, target, work, icon);
  if (!result.ok) return json(res, 500, { ok: false, error: result.error });
  return json(res, 200, {
    ok: true, name: SHORTCUT_NAME, file: result.link, desktop: result.dir || null,
    target: target, workingDirectory: work, iconLocation: icon, existed: existed, replaced: existed === true
  });
}

const CLIENT_UPDATE_CONFIG_FILE = process.env.ROE_CLIENT_UPDATE_CONFIG
  ? path.resolve(process.env.ROE_CLIENT_UPDATE_CONFIG)
  : path.join(ROOT, 'client-update.config.json');
const CLIENT_UPDATE_MODULE = process.env.ROE_CLIENT_UPDATE_MODULE
  ? path.resolve(process.env.ROE_CLIENT_UPDATE_MODULE)
  : path.join(ROOT, 'client-update', 'index.mjs');
const CLIENT_UPDATE_TIMEOUT_MS = Math.max(1000, Number(process.env.ROE_CLIENT_UPDATE_TIMEOUT_MS || 30000));
let clientUpdateState = {
  configured: false, status: 'unconfigured', text: '未配置更新通道',
  detail: null, version: null, available: null,
  /* 强制更新：只有签名 feed 里的 minimum 高于当前安装版本时才为 true（判据在更新内核里算）。 */
  minimum: null, mandatory: false, checkedAt: null
};
/* 启动自检报告：与「更新通道状态」分开存，因为每次检测都会整体替换 clientUpdateState。 */
let clientSelfCheckReport = null;
function clientUpdateStatus() { return Object.assign({}, clientUpdateState, { selfCheck: clientSelfCheckReport }); }
function clientUpdateNote(detail) {
  log('更新通道：' + clientUpdateState.text + (detail ? '（' + detail + '）' : ''));
}
async function clientUpdateCheck() {
  const at = function () { return new Date().toISOString(); };
  let raw = null;
  try { raw = fs.readFileSync(CLIENT_UPDATE_CONFIG_FILE, 'utf8'); }
  catch (e) {
    clientUpdateState = {
      configured: true, status: 'config-unreadable', text: '更新配置读不了',
      detail: (e && e.code) || 'read-error', version: null, available: null, checkedAt: at()
    };
    clientUpdateNote(clientUpdateState.detail);
    return clientUpdateState;
  }
  let config = null;
  try { config = JSON.parse(raw); } catch (e) { config = null; }
  if (!config || typeof config !== 'object' || !config.feedUrl || !config.publicKey) {
    clientUpdateState = {
      configured: true, status: 'config-incomplete', text: '更新配置不完整（缺 feedUrl / 公钥）',
      detail: 'incomplete-config', version: null, available: null, checkedAt: at()
    };
    clientUpdateNote(clientUpdateState.detail);
    return clientUpdateState;
  }
  if (!clientUpdates || typeof clientUpdates.statusBody !== 'function' || typeof clientUpdates.refreshed !== 'function') {
    clientUpdateState = {
      configured: true, status: 'host-missing', text: '已配置更新通道，但本机服务没有提供更新宿主',
      detail: 'host-missing', version: null, available: null, minimum: null, mandatory: false, checkedAt: at()
    };
    clientUpdateNote(clientUpdateState.detail);
    return clientUpdateState;
  }
  try {
    /* 与更新面板、游戏页门禁共用宿主里同一个 manager：检查只做一次，三处结论必然一致。
       这里只等一个有界的时间，超时不影响启动（门禁那边会退回磁盘上已核实的门槛）。 */
    await Promise.race([
      clientUpdates.refreshed().catch(function () { return null; }),
      new Promise(function (resolve) { const t = setTimeout(resolve, CLIENT_UPDATE_TIMEOUT_MS); if (t.unref) t.unref(); })
    ]);
    const body = await clientUpdates.statusBody();
    if (body && body.enabled === false) {
      clientUpdateState = {
        configured: true, status: 'disabled', text: body.message || '更新通道未启用',
        detail: body.reason || null, version: null, available: null,
        minimum: null, mandatory: false, checkedAt: at()
      };
    } else {
      const hasNew = !!(body && body.available);
      const seen = (body && body.version) || '未知';
      clientUpdateState = {
        configured: true, status: hasNew ? 'available' : 'latest',
        text: hasNew ? ('有新版本 ' + seen) : ('已是最新（' + seen + '）'),
        detail: null, version: (body && body.version) || null, available: hasNew,
        minimum: (body && body.minimum) || null,
        mandatory: !!(body && body.mandatory),
        checkedAt: at()
      };
    }
  } catch (e) {
    clientUpdateState = {
      configured: true, status: 'check-failed', text: '更新通道检测失败（不影响游戏）',
      detail: (e && e.code) || (e && e.message) || 'error', version: null, available: null,
      minimum: null, mandatory: false, checkedAt: at()
    };
  }
  clientUpdateNote(clientUpdateState.detail);
  return clientUpdateState;
}
/* ---- 强制更新门禁：唯一判据（启动器面板与直接开 URL 都走这里） ----
   判据来自更新宿主的同一个 manager —— 更新面板读的也是它，所以不可能出现「面板说必须更新、游戏页却放行」。
   先按磁盘上已核实的门槛判定（请求失败也保留，不抹掉已验证的要求），再给一次有界的联网核对：
   拿到结果按结果，超时或失败按磁盘门槛 —— 网络不通既不会凭空制造强制要求，也不会丢掉已核实的要求。
   逃生口由更新宿主管理：只有更新确实失败过（且还没恢复）时才放行，更新一恢复就自动收回。 */
const CLIENT_UPDATE_GATE_WAIT_MS = 6000;
/* 游戏宿主页路径（查询串/锚点不算）。门禁在对外包里也必须存在，所以用本地判据，
   不依赖只有内部包才有的客户端服务注入白名单函数。 */
const CLIENT_UPDATE_GATE_PAGE = '/client/api.html';
function clientUpdateGatePathAllowed(urlPath) {
  const raw = String(urlPath == null ? '' : urlPath);
  const cut = raw.search(/[?#]/);
  return (cut < 0 ? raw : raw.slice(0, cut)) === CLIENT_UPDATE_GATE_PAGE;
}
function clientUpdateGateView() {
  if (!clientUpdates || typeof clientUpdates.gateView !== 'function') return Promise.resolve(null);
  const pending = typeof clientUpdates.refreshed === 'function' ? clientUpdates.refreshed() : null;
  const wait = new Promise(function (resolve) {
    const timer = setTimeout(resolve, CLIENT_UPDATE_GATE_WAIT_MS);
    if (timer.unref) timer.unref();
  });
  return Promise.race([Promise.resolve(pending).catch(function () { return null; }), wait])
    .then(function () { return clientUpdates.gateView(); })
    .catch(function () { return null; });
}
function clientUpdateGateBlocks() {
  return clientUpdateGateView().then(function (view) {
    if (!view) return false;   /* 读不到判据就不拦：宁可不拦，也不冤枉玩家 */
    return view.blocked === true;
  });
}
function clientUpdateGatePage() {
  return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>需要先更新</title>'
    + '<style>body{margin:0;background:#0d1319;color:#e8eef6;font:14px/1.9 "Microsoft YaHei",sans-serif;display:flex;align-items:center;justify-content:center;height:100vh}'
    + '.card{max-width:560px;padding:28px 32px;border:1px solid #2a3a4d;border-radius:10px;background:#131c26}'
    + 'h1{font-size:18px;margin:0 0 12px;color:#f0c674}p{margin:0 0 10px}.k{color:#9fb3c8}</style></head><body><div class="card">'
    + '<h1>这一版必须更新后才能进入游戏</h1>'
    + '<p>请回到启动器，打开「客户端更新」，点「下载并准备更新」，装好之后再点开始游戏。</p>'
    + '<p class="k">如果更新一直失败，可以在更新面板里选择进入诊断模式，先上线再处理。</p>'
    + '</div></body></html>';
}
function clientUpdateAutoStart() {
  if (!fs.existsSync(CLIENT_UPDATE_CONFIG_FILE)) {
    /* 需求原文：不存在就整块静默、日志记一行 */
    log('更新通道：未配置更新通道（包内没有 client-update.config.json，整块静默、跳过检查）');
    return Promise.resolve(clientUpdateState);
  }
  return clientUpdateCheck().catch(function (e) {
    log('更新通道：检测异常 ' + ((e && e.message) || e) + '（按设计静默，不阻塞启动）');
    return clientUpdateState;
  });
}

/* 下一次启动的轻量自检：核对版本号与关键文件清单 —— 「换上那一刻是对的」不等于「后来没坏」。
   只读、只记一行日志，不阻塞启动、不影响游戏；没有更新记录就跳过。 */
let clientSelfCheckPromise = null;
function clientSelfCheckStartup() {
  if (clientSelfCheckPromise) return clientSelfCheckPromise;
  clientSelfCheckPromise = (async function () {
    try {
      const mod = await import(pathToFileURL(path.join(ROOT, 'client-update', 'selfcheck.mjs')).href);
      if (!mod || typeof mod.runSelfCheck !== 'function') return null;
      let preserve = [];
      try {
        const config = JSON.parse(fs.readFileSync(CLIENT_UPDATE_CONFIG_FILE, 'utf8'));
        if (Array.isArray(config.preservePaths)) preserve = config.preservePaths;
      } catch (e) { /* 没配置更新通道 */ }
      const report = await mod.runSelfCheck(ROOT, { preservePaths: preserve, write: true });
      clientSelfCheckReport = { status: report.status, ok: report.ok, version: report.version, checked: report.checked, mismatches: report.mismatches, at: report.at, mode: report.mode };
      if (report.status === 'no-receipt') log('更新自检：本安装没有自动更新记录，跳过');
      else if (report.ok) log('更新自检：通过（版本 ' + (report.version || '未知') + '，核对 ' + report.checked + ' 个关键文件）');
      else log('更新自检：发现不一致（版本 ' + (report.version || '未知') + '）：' + JSON.stringify(report.mismatches).slice(0, 400));
      return report;
    } catch (e) {
      log('更新自检：异常 ' + ((e && e.message) || e) + '（按设计静默，不阻塞启动）');
      return null;
    }
  })();
  return clientSelfCheckPromise;
}
/* ---------------- HTTP：静态 + 反代 + 状态 ---------------- */
const server = http.createServer(async function (req, res) {
  if (await clientUpdates.handle(req, res)) return;
  let pathname;
  try { pathname = decodeURIComponent(new URL(req.url, 'http://127.0.0.1').pathname); }
  catch (e) { pathname = String(req.url).split('?')[0]; }

  /* 在线检测：页面心跳与卸载上报（只认本进程注入的令牌，公网页面猜不到） */
  if (pathname === '/api/presence/ping' || pathname === '/api/presence/bye') return presenceHandleBeacon(req, res, pathname);

  if (pathname === '/api/account-transfer/export' || pathname === '/api/account-transfer/import') return handleAccountTransfer(req, res, pathname.endsWith('/export') ? 'export' : 'import');
  if (pathname === '/requests') return json(res, 200, reqLog);
  if (pathname === '/proxy-log') return json(res, 200, { stats: proxyStats, cache: cacheSummary(), upstream: { timeoutMs: UPSTREAM_TIMEOUT_MS, budgetMs: UPSTREAM_BUDGET_MS, retries: UPSTREAM_RETRIES }, entries: proxyLogRing.slice(-200) });
  if (pathname === '/ui-skin') {
    if (req.method === 'GET') return json(res, 200, { skin: currentUiSkin, variants: UI_SKIN_VARIANTS });
    if (req.method === 'POST') {
      let body = '';
      req.on('data', chunk => { body += chunk; if (body.length > 2048) req.destroy(); });
      req.on('end', () => {
        try {
          const requested = JSON.parse(body).skin;
          const directory = uiSkinDirectory(requested);
          if (!directory || !fs.existsSync(directory) || !fs.statSync(directory).isDirectory()) return json(res, 400, { ok: false, error: 'unknown skin' });
          const state = JSON.stringify({ skin: requested }, null, 2) + '\n';
          fs.writeFileSync(UI_SKIN_STATE_FILE, state, 'utf8');
          return json(res, 200, { ok: true, skin: requested, restartRequired: true });
        } catch (e) { return json(res, 400, { ok: false, error: 'invalid request' }); }
      });
      return;
    }
    return json(res, 405, { ok: false, error: 'method not allowed' });
  }
  /* file:// 启动器（Origin: null）的 CORS 预检：本地 204 应答，不碰读写逻辑 */
  if (req.method === 'OPTIONS' && API_PATHS.indexOf(pathname) >= 0) {
    res.writeHead(204, API_CORS_HEADERS);
    return res.end();
  }
  /* 启动器契约接口 /api/*（见本文件「本机接口 /api/*」段） */
  if (pathname === '/api/prefs') return handleApiPrefs(req, res);
  if (pathname === '/api/accounts') return handleApiAccounts(req, res);
  if (pathname === '/api/accounts/reveal') return handleApiAccountsReveal(req, res);
  if (pathname === '/api/launch') return handleApiLaunch(req, res);
  if (pathname === '/api/window') return handleApiWindow(req, res);
  /* 一键生成桌面快捷方式：无任何路径参数，只认本机这一页自己发起 */
  if (pathname === '/api/shortcut') return handleApiShortcut(req, res);
  /* Fixed official metadata source; no URL/body from the caller is followed. */
  if (pathname === '/api/official-profiles') {
    if (req.method !== 'GET') return json(res, 405, { ok: false, error: 'method not allowed' });
    try {
      const profiles = await loadOfficialProfiles();
      return json(res, 200, await profiles.refresh());
    } catch (error) {
      return json(res, 200, { snapshot: null, lastError: error.message });
    }
  }
  if (pathname === '/prefs' || pathname === '/accounts') {
    return handlePackageState(req, res, pathname === '/prefs' ? 'prefs' : 'accounts');
  }
  if (pathname === '/health' || pathname === '/api/health') return json(res, 200, healthPayload());

  const rawUrl = String(req.url);
  const rawPath = rawUrl.split('?')[0];
  const rawQuery = rawUrl.indexOf('?') >= 0 ? rawUrl.slice(rawUrl.indexOf('?')) : '';

  // CORS 预检：/client_re/、/statics/、/ro/ 一律本地 204 应答，不转发上游
  if (req.method === 'OPTIONS' && PROXY_PREFIXES.some(function (p) { return rawPath.indexOf(p) === 0; })) {
    res.writeHead(204, CORS_HEADERS);
    return res.end();
  }

  /* ---------------- 本地中文覆盖：数据表 ----------------
     白名单命中 → 直供包内中文表（cache-control: no-store）；本地缺失 / 为空 → 502
     LOCAL_OVERLAY_MISSING 硬失败，绝不静默代理上游（上游那份是韩文 = 乱码）。 */
  const overlayTail = overlayTailOf(rawPath);
  if (overlayTail) return serveOverlayText(req, res, overlayTail, rawPath);

  // LastRO 世界地图素材：本地直供（JSON + 图片），完全不联网
  const wmFile = worldMapLocalFile(rawPath);
  if (wmFile) {
    const wmStat = fs.statSync(wmFile);
    res.writeHead(200, { 'content-type': mimeOf(wmFile), 'content-length': wmStat.size, 'cache-control': 'no-cache', 'x-local-worldmap': '1', 'access-control-allow-origin': '*' });
    if (req.method === 'HEAD') return res.end();
    return fs.createReadStream(wmFile).pipe(res);
  }

  /* ---------------- 本地 UI 位图兜底 ----------------
     查找顺序：包内中文覆盖根 ui-zh → 皮肤目录 → 两者都没有才回落上游。
     归一化 / 解码 / 越界防护与覆盖表同一套；parts[0] 是韩文接口目录，
     贴图相对路径就是它之后的尾部（与 <根>/client_re/data/texture-ui-fallback/<tail> 对应）。 */
  const TEXTURE_PREFIX = '/client_re/data/texture/';
  const normalizedClientRe = normalizeClientRePath(rawPath);
  if (normalizedClientRe === null && rawPath.indexOf(TEXTURE_PREFIX) === 0) {
    /* 编码坏掉：本地 404，绝不回源（沿用原有防护） */
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
    return res.end('404 ' + rawPath);
  }
  if (normalizedClientRe !== null && normalizedClientRe.indexOf(TEXTURE_PREFIX) === 0) {
    const parts = normalizedClientRe.slice(TEXTURE_PREFIX.length).split('/');
    const relative = parts.length >= 3 ? parts.slice(1).join('/') : null;
    /* 解码后越界（.. / %2e%2e%2f / 反斜杠穿越）：本地 404，绝不读到覆盖根之外 */
    if (relative !== null && textureRelativeEscapes(relative)) {
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
      return res.end('404 ' + rawPath);
    }
    if (relative !== null && /\.(bmp)$/i.test(parts[parts.length - 1])) {
      const zhHit = uiZhLocalFile(relative);
      if (zhHit) return serveLocalBmp(req, res, zhHit.file, 'ui-zh');
      const skinHit = resolveUnderRoot(UI_FALLBACK_DIR, relative);
      if (skinHit) return serveLocalBmp(req, res, skinHit, currentUiSkin);
    }
  }

  // 物品图标：按 item id 提供本地 TGA 数据（resname 已重写为 item_<ID>）
  if (rawPath.indexOf('/client_re/') === 0) {
    const m = /\/item\/item_(\d+)\.(?:tga|png|bmp)$/.exec(rawPath);
    if (m && itemIconIndex.has(m[1])) {
      const iconFile = path.join(ITEM_ICON_DIR, itemIconIndex.get(m[1]));
      try {
        const st = fs.statSync(iconFile);
        // FileManager intentionally consumes TGA as an ArrayBuffer and decodes it client-side.
        res.writeHead(200, { 'content-type': 'application/octet-stream', 'content-length': st.size, 'cache-control': 'no-store', 'access-control-allow-origin': '*' });
        if (req.method === 'HEAD') return res.end();
        return fs.createReadStream(iconFile).pipe(res);
      } catch (e) {}
    }
  }

  // 魔物缩略图：按魔物 id 提供本地 PNG（图不在包里时索引为空，请求落回上游，客户端自己解码兜底）
  if (rawPath.indexOf(MOB_THUMB_PATH_HEAD) === 0) {
    const m = /^\/mob-thumbs\/(\d{1,10})\.png$/.exec(rawPath);
    if (m && mobThumbIndex.has(m[1])) {
      const thumbFile = path.join(MOB_THUMB_DIR, mobThumbIndex.get(m[1]));
      try {
        const st = fs.statSync(thumbFile);
        res.writeHead(200, {
          'content-type': 'image/png',
          'content-length': st.size,
          'cache-control': 'no-store',
          'access-control-allow-origin': '*'
        });
        if (req.method === 'HEAD') return res.end();
        return fs.createReadStream(thumbFile).pipe(res);
      } catch (e) {}
    }
  }

  let proxyPath = null;
  for (let mi = 0; mi < PREFIX_MAP.length; mi++) {
    if (rawPath.indexOf(PREFIX_MAP[mi][0]) === 0) { proxyPath = PREFIX_MAP[mi][1] + rawPath.slice(PREFIX_MAP[mi][0].length); break; }
  }
  if (proxyPath) {
    /* 覆盖白名单的表理论上到不了这里（请求侧已拦截）；万一到了，按韩文泄漏处理（no-store + 告警）。 */
    const leakTail = overlayTailOf(proxyPath);
    /* 上游超时 / 重试 / 磁盘缓存 / 日志都在 handleProxy 里（见文件顶部「反代健壮性」段）。 */
    return handleProxy(req, res, proxyPath, rawQuery, false, leakTail ? { overlayTail: leakTail } : null);
  }

  const rel = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const full = path.join(ROOT, rel);
  if (/^(?:\.client-update(?:[\\/]|$)|client-update\.config\.json$)/i.test(rel)) {
    res.writeHead(404); return res.end();
  }
  if (rel === '.ro-cache' || rel.indexOf('.ro-cache/') === 0 || rel.indexOf('.ro-cache\\') === 0 ||
      isPackageStateArtifact(rel) || full.indexOf(ROOT) !== 0 || !fs.existsSync(full) || !fs.statSync(full).isFile()) {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
    return res.end('404 ' + pathname);
  }
  const st = fs.statSync(full);
  const staticType = mimeOf(full);
  if ((pathname === '/' || pathname === '/index.html') && req.headers.host === new URL(UPDATE_ORIGIN).host &&
      (req.socket.remoteAddress === '127.0.0.1' || req.socket.remoteAddress === '::ffff:127.0.0.1')) {
    const script = '<script>Object.defineProperty(window,"__LASTRO_UPDATE_SESSION",{value:' + JSON.stringify(UPDATE_SESSION) + '});</script><script src="/launcher/update-ui.js"></script>'
      + presenceInjectionTag();
    const html = presenceInjectionHtml(fs.readFileSync(full, 'utf8').replace(/<\/body>/i, script + '</body>'));
    const headers = {'content-type':staticType,'cache-control':'no-store','content-length':Buffer.byteLength(html)};
    if (presence.enabled) headers['x-roe-presence'] = 'injected';
    res.writeHead(200, headers);
    return res.end(req.method === 'HEAD' ? undefined : html);
  }
  /* 强制更新门禁：只拦游戏宿主页；判据与启动器按钮共用 clientUpdateGateBlocks()。 */
  if (clientUpdateGatePathAllowed(pathname) && await clientUpdateGateBlocks()) {
    const page = clientUpdateGatePage();
    res.writeHead(409, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', 'x-roe-update-gate': 'mandatory', 'content-length': Buffer.byteLength(page) });
    return res.end(req.method === 'HEAD' ? undefined : page);
  }
  if (presenceServeHtml(req, res, full, st.size, staticType)) return;
  res.writeHead(200, { 'content-type': staticType, 'content-length': st.size, 'cache-control': 'no-cache' });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(full).pipe(res);
});

/* ---------------- WS→TCP 桥 ---------------- */
function endConn(conn, reason, force) {
  if (force || !conn.closedBy) conn.closedBy = reason;
  if (!conn.endedAt) conn.endedAt = new Date().toISOString();
}

function frame(op, payload) {
  const l = payload.length;
  let hdr;
  if (l < 126) { hdr = Buffer.alloc(2); hdr[1] = l; }
  else if (l < 65536) { hdr = Buffer.alloc(4); hdr[1] = 126; hdr.writeUInt16BE(l, 2); }
  else { hdr = Buffer.alloc(10); hdr[1] = 127; hdr.writeBigUInt64BE(BigInt(l), 2); }
  hdr[0] = 0x80 | op;
  return Buffer.concat([hdr, payload]);
}

const server2 = http.createServer(function (req, res) {
  res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' });
  res.end('client-service bridge: ws://127.0.0.1:' + BRIDGE_PORT + '/<host>:<port>\n');
});

server2.on('upgrade', function (req, socket) {
  const key = req.headers['sec-websocket-key'];
  if (!key) return socket.destroy();
  /* 在线检测的保留通道：本机页面与本服务之间的一条长连接，不走桥、不进白名单。 */
  if (presenceStreamToken(req.url)) return presenceAcceptStream(req, socket);
  const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  const target = decodeURIComponent(String(req.url || '/').slice(1).split('?')[0]);
  const m = /^([^:\/]+):(\d+)$/.exec(target);
  if (!m) {
    log('桥拒绝目标（格式不对）：' + target);
    socket.write('HTTP/1.1 403 Forbidden\r\nSec-WebSocket-Version: 13\r\n\r\n');
    return socket.destroy();
  }
  const mapped = mapTarget(m[1], Number(m[2]));
  if (!bridgeAllowed(mapped.host, mapped.port)) {
    bridgeStats.denied.push({ target: target, at: new Date().toISOString() });
    bridgeStats.denied = bridgeStats.denied.slice(-12);
    log('桥拒绝目标：' + target);
    socket.write('HTTP/1.1 403 Forbidden\r\nSec-WebSocket-Version: 13\r\n\r\n');
    return socket.destroy();
  }
  const host = mapped.host, port = mapped.port;
  if (mapped.rewritten) { log('桥改写回环目标：' + target + ' -> ' + host + ':' + port); }
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  const officialTarget = officialProfiles && officialProfiles.allows(host, port);
  const tcp = net.connect({ host: host, port: port, ...(officialTarget ? { lookup: officialProfiles.lookup } : {}) });
  tcp.setNoDelay(true);
  const conn = { target: host + ':' + port, orig: target, openedAt: new Date().toISOString(), endedAt: null, sent: 0, recv: 0, closedBy: null };
  bridgeStats.live.push(conn);
  bridgeStats.live = bridgeStats.live.slice(-8);
  /* 拨号超时：到点主动断开并记账，页面拿到明确的关闭信号，而不是一直挂在「连接中」。 */
  const dialTimer = setTimeout(function () {
    if (conn.connectedAt) return;
    conn.error = 'ETIMEDOUT';
    endConn(conn, 'tcp-dial-timeout', true);
    bridgeStats.errors++; bridgeStats.timeouts++;
    log('TCP-TIMEOUT ' + host + ':' + port + ' (' + BRIDGE_DIAL_TIMEOUT_MS + 'ms)');
    try { socket.destroy(); } catch (e) {}
    try { tcp.destroy(); } catch (e) {}
  }, BRIDGE_DIAL_TIMEOUT_MS);
  const clearDial = function () { clearTimeout(dialTimer); };
  tcp.on('connect', function () {
    clearDial();
    bridgeStats.connections++; bridgeStats.lastTarget = host + ':' + port; bridgeStats.lastAt = new Date().toISOString();
    conn.connectedAt = new Date().toISOString();
    log('TCP-OK ' + host + ':' + port);
  });
  tcp.on('end', function () { endConn(conn, 'server-fin'); });
  tcp.on('error', function (e) { clearDial(); conn.error = e.code; endConn(conn, 'tcp-error', true); bridgeStats.errors++; log('TCP-ERR ' + host + ':' + port + ' ' + e.code); socket.destroy(); });
  tcp.on('close', function (hadError) { clearDial(); endConn(conn, hadError ? 'tcp-error' : 'tcp-close'); try { socket.destroy(); } catch (e) {} });
  tcp.on('data', function (d) { conn.recv += d.length; socket.write(frame(0x2, d)); });

  let buf = Buffer.alloc(0);
  socket.on('data', function (d) {
    buf = Buffer.concat([buf, d]);
    for (;;) {
      if (buf.length < 2) return;
      const b0 = buf[0], b1 = buf[1], op = b0 & 0x0f;
      let len = b1 & 0x7f, off = 2;
      if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); off = 10; }
      let payload;
      if (b1 & 0x80) {
        if (buf.length < off + 4 + len) return;
        const mask = buf.slice(off, off + 4);
        payload = Buffer.from(buf.slice(off + 4, off + 4 + len));
        for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i % 4];
        buf = buf.slice(off + 4 + len);
      } else {
        if (buf.length < off + len) return;
        payload = buf.slice(off, off + len);
        buf = buf.slice(off + len);
      }
      if (op === 0x8) { endConn(conn, 'ws-frame-close'); socket.destroy(); tcp.destroy(); return; }
      if (op === 0x9) { socket.write(frame(0xa, payload)); continue; }
      if (op === 0x1 || op === 0x2) { conn.sent += payload.length; tcp.write(payload); }
    }
  });
  socket.on('error', function () { endConn(conn, 'ws-error', true); tcp.destroy(); });
  socket.on('close', function () { endConn(conn, 'ws-close'); tcp.destroy(); });
});

/* ---------------- 窗口关闭即释放端口：在线检测 + 宽限期自退 ----------------
   需求：关掉登录器 / 客户端窗口（点叉、任务栏关闭、浏览器被强杀）之后，本机服务不能
   一直占着页面端口与桥端口，必须自己退出、把 8971 与 5999 放出来。

   三条证据，任何一条成立就算「页面还在」：
     ① 页面长连接 ws://127.0.0.1:<桥端口>/__presence/<令牌>：正常关窗、刷新、浏览器被
        强杀，内核都会立刻断开这条 TCP，本服务当场就知道 —— 这是主证据；
     ② POST /api/presence/ping 心跳：长连接用不了时的兜底证据；
     ③ POST /api/presence/bye（页面用 navigator.sendBeacon 上报）：关窗瞬间的明确
        「我走了」，但它比长连接先到、刷新也会走到这里，所以只给短宽限期。
   只有「曾经有页面接入过」（seen）才启用自退：没人打开过的服务照旧不动。

   为什么主证据是长连接而不是心跳：浏览器会把后台页面的定时器节流（隐藏 5 分钟后
   可到 1 分钟一次），心跳断一次就退服务会误杀「窗口最小化挂机」的用户；长连接不受
   节流影响，且连接一断就是真的断了。
   为什么长连接挂在桥端口而不是页面端口：浏览器对同一个 host:port 只有 6 条 HTTP/1.1
   连接，页面端口要留给客户端成百上千个资源请求，长连接挂上去会挤掉并发位。

   退出动作：先关两个监听（内核立刻回收端口），再 process.exit —— 只结束本进程，
   绝不 taskkill、不碰任何别的 node。释放后可以马上重新启动。
   可配置（环境变量，都有默认值）：
     ROE_PRESENCE_EXIT=0        显式关掉自退（排障 / 自动化用）
     ROE_PRESENCE_GRACE_MS      没有任何在线证据时的兜底超时，默认 45000
     ROE_PRESENCE_BYE_GRACE_MS  明确「页面走了」之后的宽限期，默认 5000
     ROE_PRESENCE_SWEEP_MS      巡检周期，默认 2000 */
function presenceMs(envValue, def, min, max) {
  const n = Number(envValue);
  if (!isFinite(n) || n <= 0) return def;
  return Math.min(max, Math.max(min, Math.floor(n)));
}
const PRESENCE_ENABLED = process.env.ROE_PRESENCE_EXIT !== '0';
/* 明确信号（长连接断开 / 卸载上报）之后的宽限期：刷新、长连接自动重连都在这段里
   完成，完成即取消退出 —— 用户只是刷新一下不会断线。 */
const PRESENCE_BYE_GRACE_MS = presenceMs(process.env.ROE_PRESENCE_BYE_GRACE_MS, 5000, 1000, 60000);
/* 一条在线证据都没有时的兜底超时（30–60 秒量级，默认 45 秒）。 */
const PRESENCE_GRACE_MS = presenceMs(process.env.ROE_PRESENCE_GRACE_MS, 45000, 10000, 1800000);
const PRESENCE_SWEEP_MS = presenceMs(process.env.ROE_PRESENCE_SWEEP_MS, 2000, 500, 30000);
/* 整页读入改写只对小于这个体积的 HTML 做（与注入闸门同一口径）。 */
const PRESENCE_PAGE_MAX_BYTES = 2 * 1024 * 1024;
/* 每次启动新发的令牌：只有本进程注入到页面里的脚本知道它，别的页面猜不到。 */
const PRESENCE_TOKEN = crypto.randomBytes(16).toString('hex');
const presence = {
  enabled: PRESENCE_ENABLED, token: PRESENCE_TOKEN,
  seen: false, online: new Set(), lastHeartbeat: 0,
  deadline: 0, reason: '', exiting: false, timer: null
};
/* 有在线证据：登记 + 取消已经排上的退出（重连 / 刷新走的就是这条）。 */
function presenceAlive() {
  presence.lastHeartbeat = Date.now();
  if (presence.deadline) { presence.deadline = 0; presence.reason = ''; }
  presenceSweepStart();
}
/* 一条明确「页面走了」的信号；还有在线长连接就不排退出。 */
function presenceGone(reason, graceMs) {
  if (!presence.enabled || !presence.seen || presence.exiting) return;
  if (presence.online.size > 0) return;
  const at = Date.now() + graceMs;
  if (at > presence.deadline) { presence.deadline = at; presence.reason = reason; }
  presenceSweepStart();
}
function presenceSweepStart() {
  if (presence.timer || !presence.enabled) return;
  presence.timer = setInterval(presenceSweep, PRESENCE_SWEEP_MS);
  if (presence.timer.unref) presence.timer.unref();
}
function presenceSweep() {
  if (!presence.enabled || presence.exiting || !presence.seen) return;
  if (presence.online.size > 0) { presence.deadline = 0; presence.reason = ''; return; }
  const now = Date.now();
  if (presence.deadline) {
    if (now >= presence.deadline) presenceSelfExit(presence.reason || '页面已关闭');
    return;
  }
  if (presence.lastHeartbeat && now - presence.lastHeartbeat >= PRESENCE_GRACE_MS) {
    presenceSelfExit('长时间没有任何在线证据');
  }
}
/* 自退：先关两个监听（端口由内核立刻回收，不留监听的 TIME_WAIT），再退出进程。
   正常关窗是静默的；只有这一条「等宽限期等出来的收尾」留一行日志。 */
function presenceSelfExit(reason) {
  if (presence.exiting) return;
  presence.exiting = true;
  log('在线检测：' + reason + '，本机服务自行退出并释放端口 ' + PAGE_PORT + ' / ' + BRIDGE_PORT);
  if (presence.timer) { clearInterval(presence.timer); presence.timer = null; }
  try { server.close(); } catch (e) { /* 监听可能还没起来 */ }
  try { server2.close(); } catch (e) { /* 同上 */ }
  try { if (server.closeAllConnections) server.closeAllConnections(); } catch (e) { /* ignore */ }
  try { if (server2.closeAllConnections) server2.closeAllConnections(); } catch (e) { /* ignore */ }
  try { presence.online.forEach(function (socket) { try { socket.destroy(); } catch (e) { /* ignore */ } }); } catch (e) { /* ignore */ }
  presence.online.clear();
  setTimeout(function () { try { process.exit(0); } catch (e) { /* ignore */ } }, 100);
}
/* 长连接路径上的令牌校验：路径形如 /__presence/<32 位十六进制>。 */
function presenceStreamToken(reqUrl) {
  let target;
  try { target = decodeURIComponent(String(reqUrl || '/').slice(1).split('?')[0]); }
  catch (e) { return null; }
  const m = /^__presence\/([0-9a-f]{32})$/.exec(target);
  return m && m[1] === presence.token ? m[1] : null;
}
/* 接受一条页面长连接：不进桥的白名单、不进桥的统计，也不转发任何数据。 */
function presenceAcceptStream(req, socket) {
  const key = String(req.headers['sec-websocket-key'] || '');
  const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  socket.setNoDelay(true);
  presence.seen = true;
  presence.online.add(socket);
  presenceAlive();
  let done = false;
  function drop() {
    if (done) return;
    done = true;
    presence.online.delete(socket);
    try { socket.destroy(); } catch (e) { /* ignore */ }
    presenceGone('页面长连接断开', PRESENCE_BYE_GRACE_MS);
  }
  socket.on('close', drop);
  socket.on('error', drop);
  socket.on('end', drop);
  /* 页面从不主动发业务帧：只认关闭帧，其余原样丢掉（不缓冲，内存不长大）。 */
  socket.on('data', function (d) { if (d && d.length && (d[0] & 0x0f) === 0x8) drop(); });
}
/* 心跳 / 卸载上报的令牌：query 里的 t 必须等于本进程的令牌。 */
function presenceRequestToken(req) {
  const raw = String(req.url || '');
  const at = raw.indexOf('?');
  if (at < 0) return null;
  let params;
  try { params = new URLSearchParams(raw.slice(at + 1)); } catch (e) { return null; }
  return params.get('t') === presence.token ? presence.token : null;
}
/* POST /api/presence/ping（心跳）与 /api/presence/bye（页面卸载上报）。
   令牌不对一律 204 —— 不告诉外面到底是哪一步不对。 */
function presenceHandleBeacon(req, res, pathname) {
  req.resume();
  const ok = req.method === 'POST' && !!presenceRequestToken(req);
  if (ok) {
    presence.seen = true;
    if (pathname === '/api/presence/ping') presenceAlive();
    else presenceGone('页面卸载上报', PRESENCE_BYE_GRACE_MS);
  }
  res.writeHead(204, { 'cache-control': 'no-store' });
  return res.end();
}
/* 注入到本机页面里的在线检测脚本（全程不写任何页面文件，只改服务出去的响应）。
   卸载上报用 sendBeacon：普通 fetch 在页面卸载时会被浏览器取消，sendBeacon 不会。 */
function presenceClientScript() {
  return '(function(){'
    + 'var W=window;if(W.__ROE_PRESENCE)return;W.__ROE_PRESENCE=1;'
    + 'var T=' + JSON.stringify(presence.token) + ',B=' + Number(BRIDGE_PORT) + ',ws=null,stopped=false,retry=0,timer=null;'
    + 'function ping(){try{fetch("/api/presence/ping?t="+T,{method:"POST",cache:"no-store",keepalive:true}).catch(function(){});}catch(e){}}'
    + 'function bye(){try{if(W.navigator&&W.navigator.sendBeacon){W.navigator.sendBeacon("/api/presence/bye?t="+T,"");return;}}catch(e){}'
    + 'try{fetch("/api/presence/bye?t="+T,{method:"POST",cache:"no-store",keepalive:true}).catch(function(){});}catch(e){}}'
    + 'function open(){if(stopped)return;try{ws=new WebSocket("ws://127.0.0.1:"+B+"/__presence/"+T);}catch(e){ws=null;return;}'
    + 'ws.onopen=function(){retry=0;ping();};'
    + 'ws.onclose=function(){ws=null;if(stopped)return;retry=retry+1;setTimeout(open,Math.min(500*retry,4000));};'
    + 'ws.onerror=function(){try{ws&&ws.close();}catch(e){}};}'
    + 'open();ping();timer=setInterval(ping,15000);'
    + 'W.addEventListener("pagehide",function(){stopped=true;try{ws&&ws.close();}catch(e){}try{clearInterval(timer);}catch(e){}bye();},false);'
    + 'W.addEventListener("pageshow",function(){if(!stopped)return;stopped=false;retry=0;open();},false);'
    + '})();';
}
function presenceInjectionTag() {
  if (!presence.enabled) return '';
  return String.fromCharCode(10) + '<script data-roe-presence="1">' + presenceClientScript() + '</script>';
}
function presenceInjectionHtml(html) {
  const text = String(html);
  if (!presence.enabled || text.indexOf('data-roe-presence') >= 0) return text;
  const tag = presenceInjectionTag();
  return /<\/body>/i.test(text) ? text.replace(/<\/body>/i, tag + '</body>') : text + tag;
}
/* 静态页服务：命中注入条件就整页读入改写并直接应答，返回 true；否则返回 false 让调用方照常 stream。
   只有本机页面（Host 是 127.0.0.1/localhost）才注入 —— 别的来源拿不到令牌，也就不该拿到。 */
function presenceServeHtml(req, res, file, size, contentType) {
  if (!presence.enabled) return false;
  if (!contentTypeIsHtml(contentType)) return false;
  if (req.method === 'HEAD') return false;
  if (size >= PRESENCE_PAGE_MAX_BYTES) return false;
  if (!requestIsLoopbackLocalPage(req)) return false;
  let html;
  try { html = fs.readFileSync(file, 'utf8'); } catch (e) { return false; }
  const body = Buffer.from(presenceInjectionHtml(html), 'utf8');
  res.writeHead(200, {
    'content-type': contentType, 'content-length': body.length,
    'cache-control': 'no-store', 'x-roe-presence': 'injected'
  });
  res.end(body);
  return true;
}

/* ---------------- 启动 ---------------- */
/* 上一次替换被打断（断电 / 被杀）时磁盘上会留下 journal.json，这是可识别的中间状态。
   本次启动把它交给独立执行体：按同一套证明流程回滚到替换前的版本，然后把服务重新拉起来。
   证明不成立（游戏还开着、文件还被占用等）就不动它，等下次启动；全程不关窗口、不杀进程。 */
function clientUpdateRecoverIfNeeded() {
  const journalFile = path.join(ROOT, '.client-update', 'journal.json');
  let journal = null;
  try {
    if (!fs.existsSync(journalFile)) return false;
    journal = JSON.parse(fs.readFileSync(journalFile, 'utf8'));
  } catch (e) { log('更新恢复：读不到中间状态记录（' + ((e && e.message) || e) + '），保持不动'); return false; }
  if (!journal || typeof journal.stageId !== 'string' || !journal.stageId) { log('更新恢复：中间状态记录不可用，保持不动（不会替换文件）'); return false; }
  if (!updateLifecycle || typeof updateLifecycle.applyIndependent !== 'function') { log('更新恢复：存在未完成的更新，但本机没有可信生命周期，保持不动（不会关闭窗口、不会替换文件）'); return false; }
  if (!fs.existsSync(path.join(ROOT, 'client-update-apply.mjs'))) { log('更新恢复：缺少独立执行体，保持不动'); return false; }
  log('更新恢复：检测到上一次更新没有做完，交给独立进程回滚并重新拉起本服务');
  Promise.resolve(updateLifecycle.applyIndependent({ root: ROOT, staged: journal.stageId }, { recover: true, relaunch: true })).catch(function (e) {
    log('更新恢复：交接失败 ' + ((e && e.message) || e) + '，本次照常启动（下次启动再试）');
  });
  return true;
}
/* 正常启动：自动检测 + 起两个监听 + 运维统计。抽出来是为了让「更新恢复交接」也能兜底调用它。 */
function startServers() {
  loadOfficialProfiles().then(function (profiles) { return profiles.refresh(); }).catch(function (error) { log('官方线路初始化失败：' + error.message); });
  clientUpdateAutoStart();
  clientSelfCheckStartup();
  server.listen(PAGE_PORT, '127.0.0.1', function () {});
  server2.listen(BRIDGE_PORT, '127.0.0.1', function () {
    log('WS→TCP 桥：   ws://127.0.0.1:' + BRIDGE_PORT + '/<host>:<port>');
    log('桥白名单：    ' + JSON.stringify(ALLOW));
    log('按 Ctrl+C 退出');
    /* 连线自检：只连接与握手，不发登录包；结果进日志与 /health.connectivity */
    probeConnectivity().catch(function (e) { log('连线自检：探测异常 ' + ((e && e.message) || e)); });
  });
  /* 运维：定期把「超时 / 缓存命中 / 负缓存 / 熔断」计数写进日志，便于事后定位 */
  const statsIntervalMs = Number(process.env.ROE_STATS_INTERVAL_MS === undefined ? 300000 : process.env.ROE_STATS_INTERVAL_MS);
  if (statsIntervalMs > 0) {
    let lastCalls = 0;
    const statsTimer = setInterval(function () {
      if (cacheStats.calls === lastCalls) return;
      lastCalls = cacheStats.calls;
      const c = cacheSummary();
      log('缓存统计：反代请求 ' + proxyStats.requests + '（缓存命中 ' + c.hits + ' / 过期回退 ' + c.stale + ' / 负缓存命中 ' + c.negHits + ' / 上游超时 ' + proxyStats.timeouts + ' / 熔断拒绝 ' + proxyStats.down + ' / 失败 ' + proxyStats.failures + ' / 软404 ' + proxyStats.softNotFound + ' / 拒绝缓存 ' + c.rejects + ' / 分片未缓存 ' + c.rangeSkips + '），缓存 ' + c.files + ' 文件 / ' + (c.bytes / 1048576).toFixed(1) + ' MB，负缓存 ' + c.negatives + ' 条（软 404 ' + c.softNegatives + '），假条目已清 ' + c.fakePurged + '，孤儿 ' + c.orphans);
    }, statsIntervalMs);
    if (statsTimer.unref) statsTimer.unref();
  }
}
function logStartupBanner() {
  const restored = cacheInit();
  const summary = cacheSummary();
  log('本机页面服务： http://127.0.0.1:' + PAGE_PORT + '/');
  log('官方数据反代： ' + UPSTREAM + '  /client_re/* -> /ro/client_re/*');
  log('上游策略：     单次超时 ' + UPSTREAM_TIMEOUT_MS + 'ms / 整请求预算 ' + UPSTREAM_BUDGET_MS + 'ms / 重试 ' + UPSTREAM_RETRIES + ' 次');
  log('本地缓存：     ' + CACHE_DIR + '（' + summary.files + ' 个文件 / ' + (summary.bytes / 1048576).toFixed(1) + ' MB / 上限 ' + (CACHE_MAX_BYTES / 1048576) + ' MB / TTL ' + (CACHE_TTL_MS / 3600000) + 'h，其中负缓存 ' + summary.negatives + ' 条 TTL ' + (CACHE_NEG_TTL_MS / 60000) + 'min，启动恢复 ' + restored + ' 条）');
  log('缓存自检：     负缓存 ' + summary.negatives + ' 条（软 404 ' + summary.softNegatives + '）/ 本次清理假条目 ' + summary.fakePurged + ' 条 / 孤儿文件 ' + summary.orphans + ' 个');
  log('缓存预热：     node client-service.js --prewarm [--refresh]（清单 prewarm.json）；自检清理：node client-service.js --purge-fake');
  /* 中文覆盖启动自检：直供本地中文表，任何回源韩文都会打 [OVERLAY-KR-LEAK] */
  const overlay = overlaySelfCheck();
  log('中文覆盖自检： ' + (overlay.ok ? '8/8 张表就绪' : '未通过') + '（本地中文直供；缺失即 502，绝不回源上游韩文）'
    + '；抽查 4040 -> ' + overlay.probes.got['4040'] + ' / 501 -> ' + overlay.probes.got['501']);
  if (!overlay.ok) {
    console.error('[OVERLAY] 中文覆盖自检未通过：缺失/为空 ' + JSON.stringify(overlay.missing) + '；不可 GBK 解码 ' + JSON.stringify(overlay.errors) + '；疑似韩文泄漏 ' + JSON.stringify(overlay.leaked));
  }
  log('自身代码指纹： sha256 ' + HELPER_SHA + ' / ' + HELPER_STAT.size + 'B / mtime ' + HELPER_STAT.mtime
    + '（/health.helperSha；与磁盘不一致说明进程是旧版本）');
}
if (require.main === module && argv.indexOf('--purge-fake') >= 0) {
  const restored = cacheInit();
  const summary = cacheSummary();
  console.log('缓存自检：目录 ' + CACHE_DIR);
  console.log('  恢复索引 ' + restored + ' 条；本次清理假条目 ' + summary.fakePurged + ' 条');
  console.log('  当前 ' + summary.files + ' 个文件 / ' + (summary.bytes / 1048576).toFixed(1) + ' MB；负缓存 ' + summary.negatives + ' 条（其中软 404 ' + summary.softNegatives + ' 条）；孤儿文件 ' + summary.orphans + ' 个');
  process.exit(0);
}
if (require.main === module) {
  const prewarmIndex = argv.indexOf('--prewarm');
  if (prewarmIndex >= 0) {
    const candidate = argv[prewarmIndex + 1];
    const listFile = candidate && candidate.charAt(0) !== '-' ? candidate : null;
    cacheInit();
    prewarm({ refresh: argv.indexOf('--refresh') >= 0, listFile: listFile }).then(function (summary) {
      console.log('预热结果：共 ' + summary.total + ' 条，抓取到 ' + summary.ok + '，负缓存 ' + summary.negatives + '，已在缓存 ' + summary.skipped + '（其中中文覆盖白名单跳过 ' + summary.overlaySkipped + '），清理覆盖韩文缓存 ' + summary.overlayPurged + ' 条，失败 ' + summary.failed + '，共 ' + (summary.bytes / 1048576).toFixed(1) + ' MB，' + summary.ms + 'ms');
      summary.rows.forEach(function (row) {
        console.log('  ' + String(row.result).padEnd(13) + String(row.bytes === undefined ? '' : row.bytes + 'B').padStart(10) + '  ' + (row.path || ''));
      });
      console.log('缓存目录：' + summary.cache.dir + '（' + summary.cache.files + ' 文件 / ' + (summary.cache.bytes / 1048576).toFixed(1) + ' MB）');
      process.exit(summary.failed ? 2 : 0);
    }).catch(function (e) {
      console.error('预热失败：' + (e && e.message ? e.message : e));
      process.exit(3);
    });
  } else {
    /* 契约：ROE_BOOT_CHECK=1 时这是「换上之后能不能起来」的一次探活，不发任何自动网络请求，
       也不开窗口。由更新事务在切换之后用新版本起一次本服务来验证。 */
    const BOOT_CHECK = process.env.ROE_BOOT_CHECK === '1';
    logStartupBanner();
    if (BOOT_CHECK) {
      log('启动探活：ROE_BOOT_CHECK=1，跳过自动联网检测');
      clientSelfCheckStartup();
      startServers();
    } else if (clientUpdateRecoverIfNeeded()) {
      /* 交接成功：本进程马上让位退出，由独立执行体回滚到完整可用的旧版本并把本服务重新拉起。
         spawn 万一没起来，兜底照常启动，绝不让玩家启动到一个没有服务的状态。 */
      setTimeout(function () {
        log('更新恢复：交接未在预期时间内生效，本次照常启动（下次启动再试）');
        startServers();
      }, 5000);
    } else {
      startServers();
    }
  }
}

module.exports = {
  ALLOW, GAME_HOST, GAME_PORTS, GAME_LOGIN_PORTS, GAME_AUX_PORTS, BRIDGE_DIAL_TIMEOUT_MS, isLoopbackOrPrivateHost,
  UPSTREAM, STARTED_AT, UI_SKIN_VARIANTS, uiSkinDirectory, currentUiSkin, UI_FALLBACK_DIR,
  UI_SKIN_STATE_FILE, bridgeAllowed, mapTarget,
  endConn, worldMapLocalFile, WORLD_MAP_DIR, server, bridgeServer: server2,
  UPSTREAM_TIMEOUT_MS, UPSTREAM_BUDGET_MS, UPSTREAM_RETRIES, PROXY_BUFFER_MAX, CACHE_DIR, CACHE_MAX_BYTES, CACHE_FILE_MAX, CACHE_TTL_MS,
  CACHE_EXT, cacheableProxyPath, cacheKeyOf, cacheExtOf, cacheInit, cacheSummary, cacheLookup, cacheStore, cacheStats, proxyLogRing, proxyStats,
  CACHE_FORMAT_VERSION, CACHE_FORMAT_FILE, cacheFormatRead, cacheEnsureFormat, cacheWipeForFormat,
  upstreamIsPartial, parseRangeHeader,
  CACHE_NEG_TTL_MS, CACHE_NEG_MAX_BYTES, cacheEntryFresh, serveCached,
  UPSTREAM_COOLDOWN_MS, upstreamIsDown, upstreamMarkDown, upstreamMarkUp,
  fetchUpstreamOnce, fetchUpstreamWithPolicy, handleProxy, toUpstreamPath, prewarmPaths, prewarm, PREWARM_FILE,
  PACKAGE_STATE_DIR, PACKAGE_STATE_FILES, PACKAGE_SKIN_ROOT, PACKAGE_SKIN_DIR, ENV_SKIN_ROOT, SKIN_ROOT_FILE,
  uiSkinRoots, userSkinRoot, packageFileInDir, packageStatePath, isPackageStateArtifact,
  ITEM_TXT_OVERRIDES, ITEM_TXT_OVERRIDE_MAP, OVERLAY_REQUEST_PREFIX, OVERLAY_LOCAL_DIR,
  normalizeClientRePath, overlayTailOf, overlayLocalPath, serveOverlayText,
  scanOverlayTables, overlaySelfCheck, purgeOverlayCacheEntries,
  OVERLAY_KR_SHA_PREFIX, OVERLAY_REFERENCE_SHA_PREFIX, OVERLAY_PROBES,
  UI_ZH_RELATIVE_DIR, ENV_UI_ZH_DIR, PACKAGE_UI_ZH_DIR, uiZhRoots, uiZhLocalFile, resolveUnderRoot,
  textureRelativeEscapes, serveLocalBmp,
  HELPER_FILE, HELPER_SHA, HELPER_SHA256, HELPER_STAT,
  ITEM_ICON_DIR, ITEM_ICON_DIRS, itemIconDirectories, pickItemIconDir, itemIconIndex,
  MOB_THUMB_DIR, MOB_THUMB_DIRS, mobThumbDirectories, mobThumbIndex,
  API_PATHS, API_CORS_HEADERS,
  readPackageState, writePackageState, applyPrefsWrite, applyAccountsWrite, prefKeyAllowed,
  isPlainObject, prefsStateRead, deepMergePrefs, handleApiPrefs,
  launcherClientPrefsPatch, launcherQuality, launcherRenderScale, launcherFpsLimit, launcherVolume,
  LAUNCHER_QUALITY_VALUES, LAUNCHER_PREF_VERSIONS,
  accountStoredId, accountViewOf, accountViews, accountsStoreLoad, accountsStoreSave, applyApiAccountsWrite, handleApiAccounts,
  ACCOUNTS_CRYPTO_MODE, ACCOUNTS_ENC_FILE, ACCOUNTS_PLAIN_BACKUP_FILE, ACCOUNTS_ERROR_TEXT,
  accountsPaths, vaultEncrypt, vaultDecrypt, VaultError, vaultLoadAccounts, vaultWriteAccounts, migrateLegacyAccounts, accountsStoreErrorText,
  revealTokens, issueRevealToken, consumeRevealToken, REVEAL_TOKEN_TTL_MS, handleApiAccountsReveal,
  handleApiLaunch, clientPageUrl, browserLaunchLog, healthPayload,
  BROWSER_NOT_FOUND_CN, browserProfileDir, browserCandidates, browserPathLookup, findBrowserPath, launchBrowserWindow, handleApiWindow,
  sniffHtmlBody, contentTypeIsHtml, upstreamSaysMissing, cachePurgeFake, cacheOrphanCount, readHeadBytes, SOFT_HTML_MAX_BYTES,
  clientUpdateAutoStart, clientUpdateCheck, clientUpdateStatus, CLIENT_UPDATE_CONFIG_FILE, CLIENT_UPDATE_MODULE,
  presence, PRESENCE_TOKEN, PRESENCE_ENABLED, PRESENCE_GRACE_MS, PRESENCE_BYE_GRACE_MS, PRESENCE_SWEEP_MS,
  presenceInjectionTag, presenceInjectionHtml, presenceServeHtml, presenceClientScript, presenceStreamToken
};

'use strict';
const fs = require('fs');
const path = require('path');
const {pathToFileURL} = require('url');
const INSTALL_BLOCKED = '游戏进程生命周期尚未可信接入，退出安装已禁用；不会关闭系统浏览器或替换文件。';
/* 给玩家看的话：说清缺哪一项、下一步做什么，不出现任何内部术语，也不用表情符号。
   真正的文案表在 client-update/status-text.mjs，一处维护，宿主与页面共用。 */
function createUpdateHost({root, token, origin, loadManager, lifecycle, configFile}) {
  /* 更新配置的唯一来源：调用方给了就用它（本地服务支持 ROE_CLIENT_UPDATE_CONFIG 覆盖），
     否则才退回包内默认路径。存在性检查与实际检查必须读同一个文件。
     允许传函数：服务里这个常量声明在宿主创建之后，取值必须延后到真正用的时候。 */
  const configPath = () => (typeof configFile === 'function' ? path.resolve(configFile())
    : (configFile ? path.resolve(configFile) : path.join(root, 'client-update.config.json')));
  let managerPromise;
  let busy = false;
  /* 逃生口：更新确实失败过一次后，允许玩家选择诊断模式先上线；只在本进程内有效。
     失败台账只记事实，不在读取前清空——否则「失败过没有」永远问不出答案。 */
  let gateEscaped = false;
  let escapeAt = null;
  const failures = [];
  let preparePromise = null;
  let refreshPromise = null;
  let error = '';
  let progress = {received:0,total:0};
  let deferred = false;
  let confirmed = false;
  let appliedState;
  let lastProof = null;
  let selfCheck = null;
  let statusPromise = null, proofPromise = null, checkPromise = null;
  const trustedLifecycle = lifecycle && typeof lifecycle.isBusy === 'function' && typeof lifecycle.applyIndependent === 'function';
  function moduleOf(name) { return import(pathToFileURL(path.join(root, 'client-update', name)).href).catch(() => null); }
  const statusTextModule = () => { if (!statusPromise) statusPromise = moduleOf('status-text.mjs'); return statusPromise; };
  const proofModule = () => { if (!proofPromise) proofPromise = moduleOf('lifecycle-proof.mjs'); return proofPromise; };
  const selfCheckModule = () => { if (!checkPromise) checkPromise = moduleOf('selfcheck.mjs'); return checkPromise; };
  function configPreservePaths() {
    try {
      const config = JSON.parse(fs.readFileSync(configPath(), 'utf8'));
      return Array.isArray(config.preservePaths) ? config.preservePaths : [];
    } catch { return []; }
  }
  /* 下一次启动的轻量自检：版本号 + 关键文件清单，一次读取、失败不抛。 */
  function startSelfCheck() {
    if (!selfCheck) selfCheck = (async () => {
      const mod = await selfCheckModule();
      if (!mod || typeof mod.runSelfCheck !== 'function') return null;
      try { return await mod.runSelfCheck(root, {preservePaths: configPreservePaths()}); }
      catch (e) { return {ok:false, status:'selfcheck-error', note:(e && e.code) || (e && e.message) || null}; }
    })();
    return selfCheck;
  }
  function manager() {
    /* 用 Promise.resolve().then 延后执行：宿主是在模块顶部创建的，而更新配置常量声明在下面，
       同步取配置会撞上 TDZ。延后到微任务就不会。 */
    if (!managerPromise) managerPromise = Promise.resolve().then(async () => {
      if (!fs.existsSync(configPath())) return null;
      if (fs.lstatSync(configPath()).isSymbolicLink()) throw new Error('SYMLINK_CONFIG');
      const config = JSON.parse(fs.readFileSync(configPath(), 'utf8'));
      if (!config.feedUrl || !config.publicKey) return null;
      // Only this local file selects trust and feed. No request body enters the manager.
      const mod = loadManager ? await loadManager() : await import(pathToFileURL(path.join(root, 'client-update', 'index.mjs')).href);
      if (typeof config.currentVersion !== 'string' || !/^\d+(\.\d+)*$/.test(config.currentVersion)) throw new Error('INVALID_CURRENT_VERSION');
      return mod.createUpdateManager({feedUrl:config.feedUrl,publicKey:config.publicKey,currentVersion:config.currentVersion,endpoint:(typeof config.endpoint==='string'?config.endpoint:undefined),product:(typeof config.product==='string'?config.product:undefined),root,channel:config.channel || 'stable',allowedPaths:config.allowedPaths || ['www','service','client-update','NewEngineLocal.exe'],limits:config.limits,packageRoot:config.packageRoot,preservePaths:config.preservePaths,deltaApply:config.deltaApply===true,tokenFile:config.tokenFile,authHeader:config.authHeader,authScheme:config.authScheme,packageOrigins:config.packageOrigins,packageTokenFile:config.packageTokenFile,packageAuthHeader:config.packageAuthHeader,packageAuthScheme:config.packageAuthScheme,isBusy:()=>trustedLifecycle ? lifecycle.isBusy() : true,independentUpdater:false,onProgress:p=>{progress=p;},testOnlyAllowHttp:config.testOnlyAllowHttp===true && process.env.NATIVE_UPDATE_FIXTURE==='1'});
    });
    return managerPromise;
  }
  function json(res, status, body) {
    res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
    res.end(JSON.stringify(body));
  }
  /* 待替换文件集合：切换按顶层条目整体改名，条目里每一个现存文件都必须是可独占打开的。 */
  async function replaceSet(state) {
    const mod = await proofModule();
    if (mod && typeof mod.collectReplaceSet === 'function') {
      try {
        const tree = path.join(root, '.client-update', 'stages', String(state.staged || ''), 'tree');
        const collected = await mod.collectReplaceSet(root, tree, {skipTop: ['.client-update']});
        if (collected && Array.isArray(collected.files)) return collected.files.map(rel => path.join(root, rel));
      } catch { /* older stage: fall back to the file list the manager recorded */ }
    }
    const files = Array.isArray(state.files) ? state.files : [];
    return files.map(name => path.join(root, name)).filter(p => { try { return fs.lstatSync(p).isFile(); } catch { return false; } });
  }
  async function prove(state) {
    if (typeof lifecycle.proof !== 'function') {
      // A lifecycle that cannot prove the three facts is not trusted to say "safe": the host keeps
      // the old refusal instead of guessing.
      return {safeToApply:false, activeSessions:1, processesReleased:false, missing:['windows','files','sessions'], detail:'lifecycle-proof-unavailable', items:{}};
    }
    try { return await lifecycle.proof({files: await replaceSet(state)}); }
    catch (e) { return {safeToApply:false, activeSessions:1, processesReleased:false, missing:['windows','files','sessions'], detail:(e && e.message) || 'proof-error', items:{}}; }
  }
  async function notReadyText(proof) {
    const mod = await proofModule();
    if (mod && typeof mod.lifecycleMissingText === 'function') {
      const text = mod.lifecycleMissingText(proof);
      if (text) return text;
    }
    return '还有游戏或启动器没退出，现在不能安装。';
  }
  async function playerFields(state, extra) {
    const mod = await statusTextModule();
    if (!mod || typeof mod.playerStatus !== 'function') return {};
    const seen = mod.playerStatus(state, extra || {});
    return {playerState: seen.code, playerText: seen.text, playerHint: seen.hint || ''};
  }
  function recordFailure(e) {
    const code = (e && (e.code || e.message)) || 'error';
    /* 并发检查是调用时序问题，不是「更新一直失败」的证据，不能拿来解锁逃生口。 */
    if (code === 'UPDATE_IN_PROGRESS') return;
    failures.push({at: new Date().toISOString(), code});
    while (failures.length > 20) failures.shift();
  }
  /* 更新真的通了，就不再算「一直失败」：台账清空，逃生口也收回（下次新启动仍要求更新）。 */
  function recordSuccess() { failures.length = 0; escapeAt = null; gateEscaped = false; }
  /* 本地就绪：只读磁盘（已核实门槛就在里面），不碰网络。门禁先用它，超时也不至于无判据。 */
  function prepared() {
    if (!preparePromise) {
      preparePromise = (async () => {
        const m = await manager();
        if (!m) return null;
        try { await m.init(); } catch (e) { recordFailure(e); }
        return m;
      })().catch(e => { recordFailure(e); preparePromise = null; return null; });
    }
    return preparePromise;
  }
  /* 联网核对：与面板、门禁共用同一个 manager，因此三方看到的永远是同一份结论。
     失败只记账、不抛出：离线时要靠磁盘上已核实的门槛继续判定。 */
  const REFRESH_TTL_MS = 30 * 60 * 1000;
  let refreshedAt = 0;
  /* force=true 供诊断面板的「重新检查」使用；TTL 之内复用同一份结论，避免反复打服务器。 */
  function refreshed(options) {
    if (!refreshPromise || (options && options.force) || Date.now() - refreshedAt >= REFRESH_TTL_MS) {
      refreshedAt = Date.now();
      refreshPromise = (async () => {
      const m = await prepared();
      if (!m) return null;
      try { await m.check(); recordSuccess(); } catch (e) { recordFailure(e); }
      return m;
      })();
    }
    return refreshPromise;
  }
  async function gateView() {
    const m = await prepared();
    const st = m ? m.status() : null;
    const mandatory = !!(st && st.mandatory === true);
    return {
      configured: !!m,
      mandatory,
      blocked: mandatory && !gateEscaped,
      escaped: gateEscaped,
      escapeAt,
      minimum: (st && st.minimum) ?? null,
      version: (st && st.version) ?? null,
      policyVerifiedAt: (st && st.policyVerifiedAt) ?? null,
      failureCount: failures.length,
      lastFailure: failures.length ? failures[failures.length - 1] : null,
      busy
    };
  }
  /* 状态体的唯一组装处：HTTP 面板与客户端服务的启动检查都读它，两边不可能给出不同结论。 */
  async function statusBody() {
    const selfCheckReport = await startSelfCheck();
    const m = await manager();
    if (!m) {
      const base = {enabled:false,phase:'disabled',message:'自动更新已禁用：本机未配置 feedUrl / 公钥，无备用更新源。',canApply:false,installBlocked:INSTALL_BLOCKED,selfCheck:selfCheckReport,minimum:null,mandatory:false,escaped:gateEscaped};
      return {...base, ...(await playerFields({enabled:false,phase:'disabled'}))};
    }
    const state = appliedState || m.status();
    const lifecycleBusy = trustedLifecycle ? await lifecycle.isBusy() : true;
    const canApply = !!(trustedLifecycle && confirmed && !deferred && state.phase==='staged' && !lifecycleBusy);
    const missing = state.notReady && Array.isArray(state.notReady.missing) ? state.notReady.missing : (lastProof && Array.isArray(lastProof.missing) && lastProof.safeToApply !== true ? lastProof.missing : []);
    const body = {enabled:true,...state,busy,error,progress,deferred,confirmed,prepared:state.phase==='staged',canApply,installBlocked:trustedLifecycle ? '' : INSTALL_BLOCKED,missing,lifecycle:lastProof || state.notReady || null,selfCheck:selfCheckReport,escaped:gateEscaped,escapeAt,failureCount:failures.length,lastFailure:failures.length?failures[failures.length-1]:null};
    return {...body, ...(await playerFields(body, {missing, rolledBack: !!(state.rollbackHealthUnhealthy)}))};
  }
  async function handle(req, res) {
    const url = new URL(req.url, origin);
    if (!url.pathname.startsWith('/api/client-update')) return false;
    const peer = req.socket.remoteAddress;
    if ((peer !== '127.0.0.1' && peer !== '::ffff:127.0.0.1') || req.headers.host !== new URL(origin).host || req.headers.origin !== origin || !token || req.headers['x-update-session'] !== token) {
      json(res, 403, {error:'本地更新会话鉴权失败'}); return true;
    }
    const operation = url.pathname.slice('/api/client-update/'.length);
    if (!['status','check','confirm','download','stage','later','cancel','apply','escape'].includes(operation) || url.search) {json(res,404,{error:'未知更新操作'});return true;}
    if (req.method !== 'POST') {json(res,405,{error:'请求方法不允许'});return true;}
    // Zero-input API: even a correctly authenticated page cannot choose a URL, key, PID or path.
    if (req.headers['transfer-encoding'] || (req.headers['content-length'] && req.headers['content-length'] !== '0')) {json(res,400,{error:'更新操作不接受参数'});return true;}
    if (operation === 'apply' && !trustedLifecycle) {json(res,409,{error:INSTALL_BLOCKED,canApply:false});return true;}
    try {
      const selfCheckReport = await startSelfCheck();
      const m = await manager();
      if (!m) {
        const base = {enabled:false,phase:'disabled',message:'自动更新已禁用：本机未配置 feedUrl / publicKey，无备用更新源。',canApply:false,installBlocked:INSTALL_BLOCKED,selfCheck:selfCheckReport};
        json(res,200,{...base, ...(await playerFields({enabled:false,phase:'disabled'}))});
        return true;
      }
      if (operation !== 'status') {
        if (busy) {json(res,409,{error:'更新操作进行中'});return true;}
        busy = true;
        /* 上一次失败的事实必须在这次请求清空 error 之前取好，否则逃生口永远问不出「失败过没有」。 */
        const hadFailure = failures.length > 0;
        error = '';
        try {
          if(operation==='later' || operation==='cancel') {deferred=true;confirmed=false;}
          else if(operation==='escape') {
            /* 只有在更新确实失败过之后才放行：这是「别把人锁在门外」的逃生口，不是绕过强制的开关。 */
            if(!hadFailure) {json(res,409,{error:'更新还没有失败过，暂时不能进入诊断模式'});return true;}
            gateEscaped=true; escapeAt=new Date().toISOString();
          }
          else if(operation==='confirm') {
            if(!m.status().available) {json(res,409,{error:'没有已检查的更新'});return true;}
            deferred=false;confirmed=true;
          } else if(operation==='apply') {
            const state=m.status();
            if(!confirmed || deferred || state.phase!=='staged' || await lifecycle.isBusy()) {json(res,409,{error:'更新未确认、未准备或游戏仍忙',canApply:false});return true;}
            // 宿主自己去核实三件事，缺哪一项就说哪一项；不关窗、不杀进程。
            const proof = await prove(state);
            lastProof = proof;
            if (!proof || proof.safeToApply !== true || proof.activeSessions !== 0 || proof.processesReleased !== true) {
              const missing = Array.isArray(proof && proof.missing) ? proof.missing : [];
              json(res,409,{error: await notReadyText(proof),canApply:false,missing,notReady:(proof && proof.items) || null,detail:(proof && proof.detail) || null,phase:'staged'});
              return true;
            }
            // Adapter must freeze launches, prove owned session/process release, launch an independent worker and restart now.
            appliedState=await lifecycle.applyIndependent({root,staged:state.staged});
            confirmed=false;
          } else {
            if((operation==='download' || operation==='stage') && (!confirmed || deferred)) {json(res,409,{error:'请先明确确认更新'});return true;}
            deferred=false;
            if(operation==='check') {confirmed=false;appliedState=undefined;progress={received:0,total:0};}
            await m[operation]();if(operation==='download') await m.stage();
            if(operation==='check') recordSuccess();
          }
        } finally {busy = false;}
      }
      json(res,200,await statusBody());
    } catch (e) {recordFailure(e);error = e.message;json(res,503,{enabled:false,error,code:e.code||null,missing:(e&&e.missing)||null,rollbackError:e.rollbackError||null,rollbackErrors:e.rollbackErrors||null,rollbackHealth:(e&&e.rollbackHealth)||null,canApply:false,installBlocked:INSTALL_BLOCKED});}
    return true;
  }
  startSelfCheck();
  refreshed();
  /* 客户端服务在静态下发处读取管给出的结论：与更新面板共用同一个 manager，判据只有一处。 */
  return {handle, gateEscaped: () => gateEscaped, gateView, prepared, refreshed, statusBody};
}
module.exports = {createUpdateHost, INSTALL_BLOCKED};

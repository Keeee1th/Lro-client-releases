/** Passive Online.js metadata extraction, adapted from parkerjj/LROBrowser iwa-21
 * (81536bc..4e5bbea). Never evaluate or import downloaded JavaScript.
 * Shared by the engine and portable service; packaging copies this module verbatim. */
export const MAX_SCRIPT_BYTES = 4 * 1024 * 1024;
export const MAX_AGE_MS = 90 * 24 * 60 * 60 * 1000;
export const OFFICIAL_SOURCE = 'https://game.lastro.cn/ro/Online.js';
const numeric = (value, max) => Number.isSafeInteger(value) && value >= 0 && value <= max;
const validKeys = value => Array.isArray(value) && value.length === 3 && value.every(key => numeric(key, 0xffffffff));

export function trustedRelay(value) {
	try {
		const url = new URL(value);
		return url.protocol === 'wss:' && (url.hostname === 'lastro.cn' || url.hostname.endsWith('.lastro.cn')) &&
			(!url.port || url.port === '443') && url.pathname === '/' && !url.search && !url.hash &&
			!url.username && !url.password ? url.href : null;
	} catch { return null; }
}

// Remote metadata must not make the loopback bridge a private-network proxy.
export function publicGameHost(value) {
	if (typeof value !== 'string' || value.length > 253) { return false; }
	if (/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)*lastro\.cn$/i.test(value)) { return true; }
	if (!/^\d{1,3}(?:\.\d{1,3}){3}$/.test(value)) { return false; }
	const parts = value.split('.').map(Number);
	const [a, b] = parts;
	return parts.every(n => n <= 255) && a > 0 && a < 224 && a !== 10 && a !== 127 &&
		!(a === 100 && b >= 64 && b <= 127) && !(a === 169 && b === 254) &&
		!(a === 172 && b >= 16 && b <= 31) && !(a === 192 && (b === 168 || b === 0)) &&
		!(a === 198 && (b === 18 || b === 19));
}

function validEntry(entry) {
	return entry && typeof entry === 'object' && publicGameHost(entry.address) &&
		numeric(entry.port, 65535) && entry.port > 0 && numeric(entry.version, 65535) && numeric(entry.langtype, 255);
}

export function validateSnapshot(raw, now = Date.now()) {
	if (!raw || raw.schema !== 1 || !numeric(raw.fetchedAt, Number.MAX_SAFE_INTEGER) ||
		raw.fetchedAt > now + 60000 || now - raw.fetchedAt > MAX_AGE_MS ||
		!raw.servers || typeof raw.servers !== 'object' || Array.isArray(raw.servers)) { return null; }
	const entries = Object.entries(raw.servers);
	if (!entries.length || entries.length > 32 || entries.some(([id, entry]) =>
		!/^[356]$/.test(id) || !validEntry(entry))) { return null; }
	if (raw.clientVer3Keys !== undefined && !validKeys(raw.clientVer3Keys)) { return null; }
	if (raw.otherClientVerKeys !== undefined && !validKeys(raw.otherClientVerKeys)) { return null; }
	return raw;
}

function decodeLiteral(value) {
	try {
		const quoted = value.startsWith('"') ? value : '"' + value.slice(1, -1).replace(/\\'/g, "'").replace(/"/g, '\\"') + '"';
		return JSON.parse(quoted.replace(/\\x([0-9a-f]{2})/gi, '\\u00$1'));
	} catch { return null; }
}
function parseKeys(value) {
	if (!/^\[\s*(?:0x[0-9a-f]+|\d+)\s*,\s*(?:0x[0-9a-f]+|\d+)\s*,\s*(?:0x[0-9a-f]+|\d+)\s*\]$/i.test(value)) { return undefined; }
	const keys = value.slice(1, -1).split(',').map(part => Number(part.trim()));
	return validKeys(keys) ? keys : undefined;
}

export function parseOfficialOnlineJs(source, fetchedAt = Date.now()) {
	if (typeof source !== 'string' || new TextEncoder().encode(source).byteLength > MAX_SCRIPT_BYTES) {
		throw new Error('Official Online.js exceeds safety limit');
	}
	const servers = Object.create(null);
	const fieldsPattern = /(?:^|[,{])\s*(["']?)([a-zA-Z_$][\w$]*)\1\s*:\s*("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|0x[0-9a-f]+|\d+)/gi;
	for (const match of source.matchAll(/\bcase\s+(\d{1,4})\s*:\s*([\s\S]*?)(?=\bcase\s+\d{1,4}\s*:|\bdefault\s*:|\bswitch\s*\(|$)/g)) {
		if (!/^[356]$/.test(match[1])) { continue; }
		const object = /=\s*\[\s*\{([\s\S]*?)\}\s*\]/.exec(match[2].slice(0, 2400))?.[1];
		if (!object) { continue; }
		const fields = Object.create(null);
		fieldsPattern.lastIndex = 0;
		for (const part of object.matchAll(fieldsPattern)) {
			const raw = part[3];
			const value = raw[0] === '"' || raw[0] === "'" ? decodeLiteral(raw) : Number(raw);
			if (value !== null) { fields[part[2]] = value; }
		}
		const entry = { address: fields.address, port: fields.port, version: fields.version, langtype: fields.langtype };
		const relay = trustedRelay(fields.socketProxy);
		if (relay) { entry.relayEndpoint = relay; }
		if (validEntry(entry)) { servers[match[1]] = entry; }
	}
	if (!Object.keys(servers).length) { throw new Error('No official LastRO server entries found'); }
	const cryptIndex = source.indexOf('Network/PacketCrypt');
	const nextModule = source.indexOf('define(', cryptIndex + 'Network/PacketCrypt'.length);
	const crypt = cryptIndex < 0 ? '' : source.slice(cryptIndex, nextModule < 0 ? cryptIndex + 64000 : nextModule);
	const ternary = /3\s*={2,3}\s*[a-zA-Z_$][\w$]*\.get\(\s*["']ClientVer["']\s*\)\s*\?\s*(\[[^\]]+\])\s*:\s*(\[[^\]]+\])/i.exec(crypt);
	const snapshot = { schema: 1, fetchedAt, servers };
	if (ternary) {
		const three = parseKeys(ternary[1]);
		const other = parseKeys(ternary[2]);
		if (three) { snapshot.clientVer3Keys = three; }
		if (other) { snapshot.otherClientVerKeys = other; }
	}
	if (!validateSnapshot(snapshot)) { throw new Error('Invalid official snapshot'); }
	return snapshot;
}

export function resolveOfficialServer(server, snapshot) {
	// Explicit opt-out preserves pinned/manual server profiles.
	if (!server || server.officialProfileRefresh === false || !validateSnapshot(snapshot)) { return server; }
	const latest = snapshot.servers[String(server.lastroNid)];
	if (!latest) { return server; }
	const out = { ...server, address: latest.address, port: latest.port, version: latest.version, langtype: latest.langtype };
	const localBridge = /^ws:\/\/(?:127\.0\.0\.1|localhost):\d+\/$/.test(server.socketProxy || '');
	const relay = trustedRelay(latest.relayEndpoint);
	// Never switch a player-selected local bridge/custom proxy to official WSS.
	if (!localBridge && trustedRelay(server.socketProxy) && relay) { out.socketProxy = relay; }
	const keys = Number(server.ClientVer ?? server.clientVer) === 3 ? snapshot.clientVer3Keys : snapshot.otherClientVerKeys;
	if (validKeys(keys)) { out.packetKeys = keys.slice(); }
	return out;
}

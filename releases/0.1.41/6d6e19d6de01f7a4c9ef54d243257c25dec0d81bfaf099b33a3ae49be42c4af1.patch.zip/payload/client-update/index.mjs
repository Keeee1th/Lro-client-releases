import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash, createPublicKey, verify, randomUUID } from 'node:crypto';
import { inflateRawSync } from 'node:zlib';
import AdmZip from 'adm-zip';
import { fail, safeName, isPreservedPath, isAllowedPath, isAllowedDirectoryAncestor } from './install-paths.mjs';
import { CONTRACT_LIMITS, PATCH_FORMAT, manifestSha256, parseManifestBytes, parsePatchBytes, readPatchZip } from './patch-contract.mjs';
import { buildOwnedManifest, verifyInstalledTree, writeBaseline } from './baseline.mjs';
import { snapshotPreserved, verifyPreserved } from './preserve-proof.mjs';

const sha = b => createHash('sha256').update(b).digest('hex');
const version = v => typeof v === 'string' && /^\d+(\.\d+)*$/.test(v) && v.length <= 128;
export function compareVersions(a, b) {
  if (!version(a) || !version(b)) fail('INVALID_VERSION');
  const x = a.split('.').map(BigInt), y = b.split('.').map(BigInt);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    if ((x[i] ?? 0n) > (y[i] ?? 0n)) return 1;
    if ((x[i] ?? 0n) < (y[i] ?? 0n)) return -1;
  }
  return 0;
}
// Choosing a delivery is a decision, never a failure: a patch we cannot PROVE applicable must not
// stop an update the full package can still deliver. Only tamper is fatal, and that is refused
// while the feed signature and artifact hashes are verified, long before this runs.
export function selectPackage(check, { effectiveVersion = '0.0.0', installedManifestSha256 = null, receiptManifestSha256 = null, deltaEnabled = false } = {}) {
  const full = reason => ({ mode: 'full', reason });
  if (deltaEnabled !== true) return full('delta-disabled');
  if (!check || !check.delta) return full('no-delta-published');
  if (!check.manifest) return full('no-target-manifest');
  if (!HEX64.test(installedManifestSha256 ?? '')) return full('no-installed-manifest');
  // A baseline that the installed-version receipt does not name is unattributable, so it cannot
  // serve as proof of anything.
  if (receiptManifestSha256 !== installedManifestSha256) return full('installed-manifest-unbound');
  if (check.delta.from.manifestSha256 !== installedManifestSha256) return full('base-manifest-mismatch');
  if (compareVersions(check.delta.from.version, effectiveVersion) !== 0) return full('base-version-mismatch');
  return { mode: 'delta', reason: 'applicable', manifest: check.manifest, delta: check.delta };
}
const b64 = s => {
  if (typeof s !== 'string' || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(s)) fail('INVALID_ENVELOPE');
  return Buffer.from(s, 'base64');
};
const RECEIPT_FILE = 'installed-version.json';
// 已核实的「最低可用版本」策略：唯一来源，离线时也保留，只有显式撤销才会清除。
const POLICY_FILE = 'update-policy.json';
// The manifest of the tree this installation actually has. Written at commit time, so a patch can
// be proven to belong to THIS installation instead of merely claiming to.
const BASELINE_FILE = 'installed-manifest.json';
const HEX64 = /^[a-f0-9]{64}$/;
// A stage id is a randomUUID(). Only a name shaped exactly like one may ever be reclaimed by the
// bounded-retention pass, so a stray file or a legacy name is left alone rather than deleted.
const STAGE_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
// Operator limits are ceilings, not suggestions: Number.MAX_SAFE_INTEGER is not a limit.
const LIMIT_CAPS = { files: 100000, download: 1 << 30, unpacked: 1 << 30, ratio: 1000 };
const DEFAULT_LIMITS = { download: 256 * 1024 * 1024, unpacked: 512 * 1024 * 1024, files: 10000, ratio: 200 };
function resolveLimits(input) {
  const limits = { ...DEFAULT_LIMITS, ...input };
  if (Object.entries(limits).some(([key, value]) => !Object.hasOwn(LIMIT_CAPS, key) || !Number.isSafeInteger(value) || value <= 0 || value > LIMIT_CAPS[key])) fail('INVALID_LIMITS');
  return limits;
}
// Normalises the operator path configuration once, for the manager and the publisher alike.
export function normalizePaths({ preservePaths = [], allowedPaths = [], packageRoot } = {}) {
  const normalizedRoot = packageRoot === undefined || packageRoot === null ? null : safeName(packageRoot);
  if (normalizedRoot?.includes('/')) fail('INVALID_PACKAGE_ROOT');
  return {
    packageRoot: normalizedRoot,
    preserved: preservePaths.map(entry => safeName(entry, true).toLowerCase()),
    allowed: allowedPaths.map(entry => safeName(entry.replace(/\/$/, '')))
  };
}
// Validates one package archive and returns the files this client would install.
// Exported on purpose: a publisher that built its manifest under different rules would
// describe a tree the updater never writes, so patch baselines must come from here.
export function unpackPackage(bytes, { limits, preservePaths, allowedPaths, packageRoot } = {}) {
  const gate = resolveLimits(limits);
  const { packageRoot: normalizedRoot, preserved, allowed } = normalizePaths({ preservePaths, allowedPaths, packageRoot });
  const zip = new AdmZip(bytes); const entries = zip.getEntries();
  if (!entries.length || entries.length > gate.files) fail('UNPACK_LIMIT');
  let total = 0; const names = new Set(), files = [];
  // Case-folded claims over every path prefix, including implied parents: one spelling per
  // directory, and no path may be both a file and a directory.
  const dirNames = new Map(), fileNames = new Map();
  const claimDir = d => {
    const key = d.toLowerCase(), held = dirNames.get(key);
    if (held !== undefined) { if (held !== d) fail('PATH_CASE_CONFLICT', d); return; }
    if (fileNames.has(key)) fail('PATH_TYPE_CONFLICT', d);
    dirNames.set(key, d);
  };
  const claimFile = f => {
    const key = f.toLowerCase();
    if (dirNames.has(key)) fail('PATH_TYPE_CONFLICT', f);
    fileNames.set(key, f);
  };
  for (const e of entries) {
    const original = safeName(e.entryName, true);
    if (normalizedRoot && original !== normalizedRoot && !original.startsWith(normalizedRoot + '/')) fail('PACKAGE_ROOT_MISMATCH', '更新包与本机客户端的目录结构不一致（本机更新目录 ' + normalizedRoot + '，包里是 ' + original + '）。这台电脑这次没法原地更新，请用最新的 LastROSetup 一键安装包重新安装一次完成迁移。');
    if (normalizedRoot && original === normalizedRoot && !e.isDirectory) fail('PACKAGE_ROOT_MISMATCH', '更新包与本机客户端的目录结构不一致（本机更新目录 ' + normalizedRoot + '，包里 ' + original + ' 不是目录）。这台电脑这次没法原地更新，请用最新的 LastROSetup 一键安装包重新安装一次完成迁移。');
    const name = normalizedRoot ? original.slice(normalizedRoot.length + 1) : original; const lower = name.toLowerCase();
    if (names.has(lower)) fail('DUPLICATE_PATH'); names.add(lower);
    if (!name) continue;
    const parts = name.split('/');
    for (let i = 1; i < parts.length; i++) claimDir(parts.slice(0, i).join('/'));
    if (e.isDirectory) claimDir(name); else claimFile(name);
    const mode = (e.header.attr >>> 16) & 0xffff;
    if ((mode & 0xf000) === 0xa000 || ((mode & 0xf000) && ![0x8000, 0x4000].includes(mode & 0xf000))) fail('ZIP_SYMLINK');
    total += e.header.size; if (total > gate.unpacked || e.header.size > gate.unpacked || e.header.size > Math.max(1, e.header.compressedSize) * gate.ratio) fail('UNPACK_LIMIT');
    if (isPreservedPath(name, preserved)) continue;
    safeName(name);
    if (!isAllowedPath(name, allowed) && !(e.isDirectory && isAllowedDirectoryAncestor(name, allowed))) fail('NOT_ALLOWLISTED', name);
    if (e.isDirectory) continue;
    // Inflate with a hard output ceiling, not AdmZip's unbounded getData().
    const compressed = e.getCompressedData();
    const data = e.header.method === 0 ? compressed : e.header.method === 8 ? inflateRawSync(compressed, { maxOutputLength: Math.max(1, e.header.size) }) : fail('UNSUPPORTED_COMPRESSION');
    if (data.length !== e.header.size) fail('ZIP_SIZE_MISMATCH');
    files.push({ name, data });
  }
  if (!files.length) fail('EMPTY_PACKAGE'); return files;
}
// The itemized list a package carries for itself: pack-client always writes executable-assets.json
// into the archive, so a real release can be checked file by file instead of only as one blob.
// Present -> every unpacked entry must match it exactly (name, size, hash). Absent -> the signed
// whole-archive sha256 still binds every byte, and the fact that no itemized list was available is
// reported instead of hidden; a caller that wants the itemized proof to be mandatory sets
// requireItemizedManifest.
export const PACKAGE_MANIFEST_NAME = 'executable-assets.json';
export function verifyPackageManifest(files, options = {}) {
  const found = files.find(f => String(f.name).toLowerCase() === PACKAGE_MANIFEST_NAME);
  if (!found) {
    if (options.requireItemizedManifest === true) fail('PACKAGE_MANIFEST_REQUIRED', 'the package carries no ' + PACKAGE_MANIFEST_NAME + ' to check the unpacked files against');
    return { source: null, checked: false, reason: 'absent', entries: 0 };
  }
  let manifest;
  try { manifest = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(found.data)); } catch { fail('PACKAGE_MANIFEST_MALFORMED', PACKAGE_MANIFEST_NAME + ' is not valid UTF-8 JSON'); }
  if (!manifest || typeof manifest !== 'object' || manifest.schema !== 1 || !Array.isArray(manifest.files)) fail('PACKAGE_MANIFEST_MALFORMED', PACKAGE_MANIFEST_NAME + ' requires {schema:1,files:[]}');
  const prefix = options.packageRoot ? String(options.packageRoot) + '/' : '';
  const strip = p => (prefix && p.startsWith(prefix) ? p.slice(prefix.length) : p);
  const declared = new Map();
  for (const entry of manifest.files) {
    if (!entry || typeof entry !== 'object' || typeof entry.path !== 'string' || !Number.isSafeInteger(entry.bytes) || !HEX64.test(String(entry.sha256 ?? '').toLowerCase())) fail('PACKAGE_MANIFEST_MALFORMED', PACKAGE_MANIFEST_NAME + ' has a malformed file entry');
    const name = strip(entry.path).toLowerCase();
    if (declared.has(name)) fail('PACKAGE_MANIFEST_MALFORMED', PACKAGE_MANIFEST_NAME + ' names a file twice: ' + entry.path);
    declared.set(name, { path: strip(entry.path), bytes: entry.bytes, sha256: String(entry.sha256).toLowerCase() });
  }
  const actual = new Map();
  for (const file of files) {
    if (String(file.name).toLowerCase() === PACKAGE_MANIFEST_NAME) continue;
    actual.set(String(file.name).toLowerCase(), file);
  }
  const problems = [];
  for (const [key, entry] of declared) {
    const file = actual.get(key);
    if (!file) { problems.push('missing:' + entry.path); continue; }
    if (file.data.length !== entry.bytes) { problems.push('size:' + entry.path); continue; }
    if (sha(file.data) !== entry.sha256) problems.push('hash:' + entry.path);
  }
  for (const [key, file] of actual) if (!declared.has(key)) problems.push('undeclared:' + file.name);
  if (problems.length) fail('PACKAGE_MANIFEST_MISMATCH', 'the unpacked files do not match the package manifest item by item: ' + problems.slice(0, 5).join(', ') + (problems.length > 5 ? ' (+' + (problems.length - 5) + ' more)' : ''));
  return { source: PACKAGE_MANIFEST_NAME, checked: true, reason: 'matched', entries: declared.size };
}
async function noLinks(root, relative = '') {
  let at = root;
  for (const part of ['', ...relative.split('/').filter(Boolean)]) {
    if (part) at = path.join(at, part);
    try { const st = await fs.lstat(at); if (st.isSymbolicLink()) fail('SYMLINK_PATH'); }
    catch (e) { if (e.code !== 'ENOENT') throw e; }
  }
}
export function createUpdateManager(options) {
  const { feedUrl, publicKey, isBusy, onProgress, independentUpdater = false, verifyQuiescence, tokenFile, authHeader = 'authorization', authScheme = 'Bearer ' } = options;
  /* 私有包来源（可选）：只有显式列进 packageOrigins 的 origin 才会拿到钥匙。
     绝不按域名后缀/通配放行，也不接受 http（本地夹具除外，由 urlCheck 统一管）。 */
  const packageTokenFile = options.packageTokenFile ?? tokenFile;
  const packageAuthHeader = options.packageAuthHeader ?? authHeader;
  const packageAuthScheme = options.packageAuthScheme ?? authScheme;
  const packageOriginSet = new Set(
    (Array.isArray(options.packageOrigins) ? options.packageOrigins : [])
      .map(value => {
        try {
          const at = urlCheck(value);
          if (at.protocol !== 'https:' && options.testOnlyAllowHttp !== true) fail('UNSAFE_URL', 'packageOrigins must be https: ' + value);
          return at.origin;
        } catch {
          fail('INVALID_URL', 'packageOrigins entry is not a URL: ' + value);
        }
      })
      .filter(Boolean)
  );
  const root = path.resolve(options.root);
  const home = path.join(root, '.client-update');
  const channel = options.channel ?? 'stable';
  const currentVersion = options.currentVersion ?? '0.0.0';
  const limits = resolveLimits(options.limits);
  // How much forensic debris a failed-rollback history may keep (see reclaim): the newest N failure
  // records survive together with the stage they came from, everything older is reclaimed. 5 is a
  // sane default for a post-mortem; 0 keeps nothing. A malformed value is refused here, at
  // construction, instead of silently corrected in the middle of an update.
  const retention = options.failedRetention ?? 5;
  const orphanGraceMs = options.orphanStageGraceMs ?? 15 * 60 * 1000;
  if (!Number.isSafeInteger(retention) || retention < 0 || retention > 1000) fail('INVALID_RETENTION', 'failedRetention must be an integer between 0 and 1000');
  if (!Number.isSafeInteger(orphanGraceMs) || orphanGraceMs < 0) fail('INVALID_RETENTION', 'orphanStageGraceMs must be a non-negative integer');
  if (!version(currentVersion)) fail('INVALID_VERSION');
  const { packageRoot, preserved, allowed } = normalizePaths(options);
  let state = { phase: 'idle', disabled: !feedUrl || !publicKey, reason: !feedUrl || !publicKey ? 'Updates disabled: feedUrl/publicKey not configured' : null, version: currentVersion, available: false, recoveryRequired: false, error: null, minimum: null, minimumSource: null, policyVerifiedAt: null, mandatory: false };
  let checked, envelope, downloaded, downloadedManifest, selection, stageId;
  let running = false;
  // The installed-version receipt is bound to this feed/channel/pinned key/package root. A receipt
  // carrying any other identity is not ours and must fail closed, never silently fall back.
  let feedId = null; try { feedId = urlCheck(feedUrl).href; } catch { feedId = null; }
  let spkiHash = null; try { spkiHash = publicKey ? sha(createPublicKey(publicKey).export({ type: 'spki', format: 'der' })) : null; } catch { spkiHash = null; }
  // Optional bearer token for a private feed host. The token comes from an operator-controlled
  // file, never from a web page, and is attached ONLY to requests for the feed URL's origin,
  // so a signed package URL served from another origin never receives it.
  let feedOrigin = null;
  try { feedOrigin = new URL(feedUrl).origin; } catch { feedOrigin = null; }
  let token;
  let packageToken;
  async function readToken(file) {
    let value = null;
    try { value = (await fs.readFile(path.resolve(file), 'utf8')).trim() || null; } catch { value = null; }
    if (value === null) fail('TOKEN_FILE_UNREADABLE', 'configured tokenFile is missing, unreadable or empty');
    return value;
  }
  async function authHeaders(target) {
    let at; try { at = new URL(target); } catch { return undefined; }
    if (tokenFile && feedOrigin && at.origin === feedOrigin) {
      if (token === undefined) token = await readToken(tokenFile);
      return { [authHeader]: authScheme + token };
    }
    if (packageOriginSet.has(at.origin)) {
      if (!packageTokenFile) fail('PACKAGE_TOKEN_FILE_MISSING', 'packageOrigins is configured but no token file is available');
      if (packageToken === undefined) packageToken = await readToken(packageTokenFile);
      return { [packageAuthHeader]: packageAuthScheme + packageToken };
    }
    return undefined;
  }
  function urlCheck(input) {
    let u; try { u = new URL(input); } catch { fail('INVALID_URL'); }
    const fixture = options.testOnlyAllowHttp === true && u.protocol === 'http:' && ['127.0.0.1', 'localhost', '[::1]'].includes(u.hostname);
    if ((u.protocol !== 'https:' && !fixture) || u.username || u.password || u.hash) fail('UNSAFE_URL');
    return u;
  }
  // A signed descriptor names an artifact; its shape is part of the contract, so a malformed one
  // is refused outright rather than silently downgraded to a full download.
  function descriptor(node, label, enforceLimits) {
    if (node === undefined || node === null) return null;
    if (typeof node !== 'object' || Array.isArray(node)) fail('INVALID_PACKAGE', label + ' descriptor is not an object');
    if (!HEX64.test(node.sha256 ?? '')) fail('INVALID_PACKAGE', label + ' descriptor records no sha256');
    if (!Number.isSafeInteger(node.size) || node.size <= 0 || (enforceLimits && node.size > limits.download)) fail('INVALID_PACKAGE', label + ' descriptor size is out of range');
    urlCheck(node.url);
    return { url: node.url, sha256: node.sha256.toLowerCase(), size: node.size };
  }
  function deltaDescriptor(node, targetVersion, enforceLimits) {
    if (node === undefined || node === null) return null;
    const base = descriptor(node, 'delta', enforceLimits);
    if (node.format !== PATCH_FORMAT) fail('INVALID_PACKAGE', 'unsupported delta format: ' + String(node.format));
    const from = node.from;
    if (!from || typeof from !== 'object' || Array.isArray(from)) fail('INVALID_PACKAGE', 'delta.from is missing');
    if (!version(from.version) || !HEX64.test(from.manifestSha256 ?? '')) fail('INVALID_PACKAGE', 'delta.from is malformed');
    if (compareVersions(from.version, targetVersion) >= 0) fail('INVALID_PACKAGE', 'a delta must start from an older version than it produces');
    return { ...base, format: PATCH_FORMAT, from: { version: from.version, manifestSha256: from.manifestSha256.toLowerCase() } };
  }
  // The stored manifest of the installed tree. A missing file is not an error (an installation
  // written by an older build has none), but a symlink or an oversized file is an anomaly.
  async function readInstalledManifest() {
    await noLinks(root, '.client-update/' + BASELINE_FILE);
    const file = path.join(home, BASELINE_FILE);
    let st; try { st = await fs.lstat(file); } catch (e) { if (e.code === 'ENOENT') return null; fail('BASELINE_UNREADABLE', 'installed manifest cannot be inspected: ' + (e.code ?? e.message)); }
    if (st.isSymbolicLink() || !st.isFile()) fail('BASELINE_UNREADABLE', 'installed manifest is not a regular file');
    if (st.size > CONTRACT_LIMITS.manifestBytes) fail('BASELINE_UNREADABLE', 'installed manifest is unreasonably large');
    let bytes; try { bytes = await fs.readFile(file); } catch (e) { fail('BASELINE_UNREADABLE', 'installed manifest cannot be read: ' + (e.code ?? e.message)); }
    return { bytes, sha256: sha(bytes) };
  }
  function authenticate(env, enforceLimits = true) {
    const bytes = b64(env?.payload), sig = b64(env?.signature);
    const key = createPublicKey(publicKey);
    if (key.asymmetricKeyType !== 'ed25519' || sig.length !== 64 || !verify(null, bytes, key, sig)) fail('BAD_SIGNATURE');
    let p; try { p = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); } catch { fail('INVALID_PAYLOAD'); }
    if (p.schema !== 1 || !version(p.version) || p.channel !== channel || channel !== 'stable') fail('INVALID_PAYLOAD');
    if (!p.announcement || !version(p.announcement.version) || typeof p.announcement.text !== 'string' || p.announcement.text.length > 100000) fail('INVALID_ANNOUNCEMENT');
  /* 可选、且必须签名的「最低可用版本」。低于它的安装要先更新才能进游戏（启动器侧的门禁读它）。
     只允许不高于本次发布的版本：要求一个还没发布的版本没有意义，直接拒绝而不是带着走。 */
  /* 三态，不能归一化：缺省(undefined)=本次发布没表态，沿用已核实的门槛；
     null=显式撤销门槛（降低要求必须明说）；字符串=声明门槛。 */
  if (p.minimum !== undefined && p.minimum !== null) {
    if (!version(p.minimum)) fail('INVALID_PAYLOAD', 'minimum is not a version');
    if (compareVersions(p.minimum, p.version) > 0) fail('INVALID_PAYLOAD', 'minimum is newer than the published version');
  }
    if (!p.package || !/^[a-fA-F0-9]{64}$/.test(p.package.sha256) || !Number.isSafeInteger(p.package.size) || p.package.size <= 0 || (enforceLimits && p.package.size > limits.download)) fail('INVALID_PACKAGE');
    urlCheck(p.package.url);
    p.manifest = descriptor(p.package.manifest, 'manifest', enforceLimits);
    p.delta = deltaDescriptor(p.package.delta, p.version, enforceLimits);
    return p;
  }
  async function request(url, timeoutMs = 30000) {
    for (let hops = 0; hops <= 5; hops++) {
      const checkedUrl = urlCheck(url);
      const headers = await authHeaders(checkedUrl.href);
      const response = await fetch(checkedUrl, { redirect: 'manual', signal: AbortSignal.timeout(timeoutMs), ...(headers ? { headers } : {}) });
      if ([301, 302, 303, 307, 308].includes(response.status)) {
        const location = response.headers.get('location'); await response.body?.cancel();
        if (!location) fail('BAD_REDIRECT');
        url = urlCheck(new URL(location, url).href).href; continue;
      }
      if (!response.ok) { await response.body?.cancel(); fail('HTTP_ERROR', 'HTTP ' + response.status); }
      return response;
    }
    fail('TOO_MANY_REDIRECTS');
  }
  async function ensureHome() { await noLinks(root); await noLinks(root, '.client-update'); await fs.mkdir(home, { recursive: true }); }
  async function journalPending() {
    await noLinks(root, '.client-update/journal.json');
    try { await fs.lstat(path.join(home, 'journal.json')); return true; } catch (e) { if (e.code === 'ENOENT') return false; throw e; }
  }
  async function readReceiptBytes() {
    const file = path.join(home, RECEIPT_FILE);
    await noLinks(root, '.client-update/' + RECEIPT_FILE);
    let st; try { st = await fs.lstat(file); } catch (e) { if (e.code === 'ENOENT') return null; fail('RECEIPT_UNREADABLE', 'installed-version receipt cannot be inspected: ' + (e.code ?? e.message)); }
    if (st.isSymbolicLink() || !st.isFile()) fail('RECEIPT_UNREADABLE', 'installed-version receipt is not a regular file');
    if (st.size > 65536) fail('RECEIPT_MALFORMED', 'installed-version receipt is unreasonably large');
    let raw; try { raw = await fs.readFile(file); } catch (error) { fail('RECEIPT_UNREADABLE', 'installed-version receipt cannot be read: ' + (error.code ?? error.message)); }
    return raw;
  }
  async function readReceipt() {
    if (!feedId || !spkiHash) return null;
    const raw = await readReceiptBytes(); if (raw === null) return null;
    let rec; try { rec = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(raw)); } catch { fail('RECEIPT_MALFORMED', 'installed-version receipt is not valid UTF-8 JSON'); }
    if (!rec || typeof rec !== 'object' || rec.schema !== 1) fail('RECEIPT_MALFORMED', 'installed-version receipt has an unsupported schema');
    if (rec.feedUrl !== feedId || rec.channel !== channel || rec.spkiHash !== spkiHash || (rec.packageRoot ?? null) !== packageRoot) fail('RECEIPT_FOREIGN', 'installed-version receipt belongs to a different feed, channel, pinned key or package root');
    if (!/^[a-f0-9]{64}$/.test(rec.zipSha256 ?? '')) fail('RECEIPT_MALFORMED', 'installed-version receipt records no verified package hash');
    if (rec.installedManifestSha256 !== undefined && !HEX64.test(rec.installedManifestSha256)) fail('RECEIPT_MALFORMED', 'installed-version receipt records a malformed installed manifest hash');
    const payload = authenticate(rec.envelope, false);
    if (payload.package.sha256.toLowerCase() !== rec.zipSha256) fail('RECEIPT_HASH_MISMATCH', 'installed-version receipt package hash does not match its signed envelope');
    return { receipt: rec, version: payload.version };
  }
  // effective = max(trusted numeric baseline, authenticated installed-version receipt).
  async function readEffective() {
    const found = await readReceipt();
    const effective = found && compareVersions(found.version, currentVersion) > 0 ? found.version : currentVersion;
    return { effective, receipt: found?.receipt ?? null };
  }
  /* ---- 已核实的「最低可用版本」（强制更新门槛）----
     只认绑定本 feed/频道/公钥的记录；文件损坏或不属于本 feed 一律当作没有，绝不拿它把玩家锁在门外。
     门槛只升不降：普通发布不带 minimum 就沿用已存门槛，要降低要求必须显式发布 "minimum": null。 */
  async function readPolicy() {
    if (!feedId || !spkiHash) return null;
    const file = path.join(home, POLICY_FILE);
    await noLinks(root, '.client-update/' + POLICY_FILE);
    let raw; try { raw = await fs.readFile(file); } catch (e) { if (e.code === 'ENOENT') return null; fail('POLICY_UNREADABLE', 'update policy cannot be read: ' + (e.code ?? e.message)); }
    let rec; try { rec = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(raw)); } catch { return null; }
    if (!rec || typeof rec !== 'object' || rec.schema !== 1) return null;
    if (rec.feedUrl !== feedId || rec.channel !== channel || rec.spkiHash !== spkiHash) return null;
    if (rec.minimum !== null && !version(rec.minimum)) return null;
    if (typeof rec.verifiedAt !== 'string') return null;
    return rec;
  }
  async function writePolicy(rec) { await ensureHome(); await atomicJson(path.join(home, POLICY_FILE), rec); }
  // 门槛照实写进状态：请求失败时它仍是「已核实的要求」，不会被一次网络故障抹掉。
  async function applyPolicyFloor(effective) {
    const rec = await readPolicy();
    const floor = rec?.minimum ?? null;
    state = { ...state, minimum: floor, minimumSource: rec ? 'stored' : null, policyVerifiedAt: rec?.verifiedAt ?? null, mandatory: floor !== null && compareVersions(floor, effective) > 0 };
    return floor;
  }
  async function writeReceiptBytes(bytes) {
    const file = path.join(home, RECEIPT_FILE); const tmp = file + '.tmp-' + randomUUID();
    try {
      const handle = await fs.open(tmp, 'wx');
      try { await handle.writeFile(bytes); await handle.sync(); } finally { await handle.close(); }
      await fs.rename(tmp, file);
    } catch (error) { await fs.rm(tmp, { force: true }).catch(() => {}); throw error; }
  }
  async function refreshStatus() {
    if (state.disabled) return { ...state };
    const recoveryRequired = await journalPending();
    const { effective } = await readEffective();
    state = { ...state, version: effective, recoveryRequired };
    await applyPolicyFloor(effective);
    if (recoveryRequired) { state.available = false; state.error = 'RECOVERY_REQUIRED'; }
    else if (state.error === 'RECOVERY_REQUIRED') state.error = null;
    return { ...state };
  }
  // Startup is a safe point for the same bounded reclamation: a pending journal protects its own
  // stage, and a stage younger than the grace period is left alone for a staging that is still in
  // flight in another process. Cleanup never blocks or fails a start.
  async function init() { await ensureHome(); await reclaim({ keepStageId: stageId ?? null }); return refreshStatus(); }
  async function atomicJson(file, data) { const tmp = file + '.tmp'; await noLinks(root, path.relative(root, tmp).split(path.sep).join('/')); const h = await fs.open(tmp, 'w'); try { await h.writeFile(JSON.stringify(data)); await h.sync(); } finally { await h.close(); } await fs.rename(tmp, file); }
  async function exclusive(fn) {
    if (running) fail('UPDATE_IN_PROGRESS'); running = true;
    try { return await fn(); } catch (e) { state = { ...state, phase: 'error', error: e.code ?? e.message }; throw e; } finally { running = false; }
  }
  async function check() { return exclusive(async () => {
    if (state.disabled) return { ...state };
    // An unsettled journal is never reported as "available": recovery is not a check side effect.
    if (await journalPending()) {
      state = { ...state, phase: 'recovery-required', recoveryRequired: true, available: false, error: 'RECOVERY_REQUIRED' };
      return { ...state };
    }
    checked = envelope = downloaded = downloadedManifest = stageId = undefined;
    selection = undefined;
    const prior = await readEffective();
    state = { ...state, available: false, recoveryRequired: false, error: null, version: prior.effective };
    const response = await request(feedUrl); let bytes = 0; const chunks = [];
    for await (const chunk of response.body) { bytes += chunk.length; if (bytes > 1024 * 1024) { await response.body.cancel().catch(() => {}); fail('FEED_TOO_LARGE'); } chunks.push(Buffer.from(chunk)); }
    envelope = JSON.parse(Buffer.concat(chunks).toString('utf8')); checked = authenticate(envelope);
    // The baseline is read only when a patch is actually on offer AND enabled: an installation
    // that never uses deltas must not pay for, or depend on, a manifest it never writes.
    const wantsDelta = options.deltaApply === true && checked.delta !== null && checked.manifest !== null;
    const baseline = wantsDelta ? await readInstalledManifest() : null;
    selection = selectPackage(checked, {
      effectiveVersion: prior.effective,
      installedManifestSha256: baseline?.sha256 ?? null,
      receiptManifestSha256: prior.receipt?.installedManifestSha256 ?? null,
      deltaEnabled: wantsDelta
    });
    /* 强制更新的判据只在这里算一次：门槛高于当前安装的版本 ⇒ 必须先更新。
       签名的 minimum 三分支：缺省沿用已核实门槛、null 显式撤销、字符串则与已存门槛取较高者（只升不降）。
       后续阶段都用 { ...state } 展开，所以这些字段会一直挂在状态上，供启动器门禁读取。 */
    const signed = checked.minimum;
    const stored = (await readPolicy())?.minimum ?? null;
    const stated = typeof signed === 'string' ? signed : null;
    const floor = signed === null ? null : (stated && stored ? (compareVersions(stated, stored) > 0 ? stated : stored) : (stated ?? stored));
    const policyVerifiedAt = new Date().toISOString();
    await writePolicy({ schema: 1, feedUrl: feedId, channel, spkiHash, minimum: floor, version: checked.version, verifiedAt: policyVerifiedAt });
    const mandatory = floor !== null && compareVersions(floor, prior.effective) > 0;
    state = { phase: 'checked', disabled: false, version: checked.version, announcement: checked.announcement, minimum: floor, minimumSource: signed === null ? null : (stated ? 'signed' : 'stored'), policyVerifiedAt, mandatory, available: compareVersions(checked.version, prior.effective) > 0, recoveryRequired: false, error: null, delivery: { mode: selection.mode, reason: selection.reason } };
    return { ...state };
  }); }
  async function fetchArtifact(descriptor, extension) {
    const file = path.join(home, randomUUID() + '.part'); const handle = await fs.open(file, 'wx');
    let size = 0; const hash = createHash('sha256');
    try {
      const response = await request(descriptor.url, 300000);
      for await (const chunk of response.body) {
        size += chunk.length; if (size > descriptor.size) fail('SIZE_MISMATCH');
        hash.update(chunk); await handle.writeFile(chunk); onProgress?.({ received: size, total: descriptor.size, artifact: extension });
      }
      if (size !== descriptor.size) fail('SIZE_MISMATCH');
      if (hash.digest('hex') !== descriptor.sha256) fail('HASH_MISMATCH');
      await handle.close(); const done = file.replace(/\.part$/, extension); await fs.rename(file, done);
      return done;
    } catch (e) { await handle.close().catch(() => {}); await fs.rm(file, { force: true }); throw e; }
  }
  async function download() { return exclusive(async () => {
    if (!checked || !state.available) fail('NO_UPDATE'); await ensureHome();
    const delta = selection?.mode === 'delta';
    // A patch is meaningless without the manifest it must produce, so the two are fetched and
    // verified as one unit: a missing or altered manifest aborts before anything is staged.
    const primary = delta ? selection.delta : checked.package;
    downloaded = await fetchArtifact(primary, delta ? '.patch' : '.zip');
    downloadedManifest = delta ? await fetchArtifact(selection.manifest, '.manifest.json') : null;
    state = { ...state, phase: 'downloaded', received: primary.size, delivery: { mode: delta ? 'delta' : 'full', reason: selection?.reason ?? 'full-only', size: primary.size } };
    return { ...state };
  }); }
  // The unpacker is shared with the publisher (see unpackPackage) so the target manifest
  // describes exactly the tree apply() writes; options are passed through unchanged.
  const unpack = bytes => unpackPackage(bytes, {
    limits,
    preservePaths: options.preservePaths,
    allowedPaths: options.allowedPaths,
    packageRoot: options.packageRoot
  });
  async function stage() { return exclusive(async () => {
    if (!downloaded || !checked) fail('NOT_DOWNLOADED'); await ensureHome();
    const bytes = await fs.readFile(downloaded);
    stageId = randomUUID(); const dir = path.join(home, 'stages', stageId); await noLinks(root, '.client-update/stages'); await fs.mkdir(dir, { recursive: true });
    if (selection?.mode !== 'delta') {
      if (bytes.length !== checked.package.size || sha(bytes) !== checked.package.sha256.toLowerCase()) fail('HASH_MISMATCH');
      const files = unpack(bytes);
      // Pre-switch verification, while not a single installed file has been touched: the unpacked
      // entries must agree with the package's own itemized list, and the fully verified tree is
      // materialised inside the same-volume stage so the switch is pure renames.
      const itemized = verifyPackageManifest(files, { packageRoot: options.packageRoot, requireItemizedManifest: options.requireItemizedManifest === true });
      await writeStageTree(dir, files);
      await fs.copyFile(downloaded, path.join(dir, 'package.zip')); await atomicJson(path.join(dir, 'envelope.json'), envelope);
      state = { ...state, phase: 'staged', staged: stageId, files: files.map(f => f.name), itemizedManifest: itemized }; return { ...state };
    }
    if (bytes.length !== selection.delta.size || sha(bytes) !== selection.delta.sha256) fail('HASH_MISMATCH');
    // A patch is only usable if it starts from the tree this installation actually has. The
    // baseline is re-read here rather than trusted from check(), because the update may have been
    // selected minutes before it was staged, and because staging is the last cheap moment to stop.
    const base = await readInstalledManifest();
    if (!base) fail('BASELINE_MISSING', 'no installed manifest to apply a patch against');
    if (base.sha256 !== selection.delta.from.manifestSha256) fail('BASE_MANIFEST_MISMATCH', 'the installed manifest is not the one this patch starts from');
    const baseManifest = parseManifestBytes(base.bytes, { preservePaths: options.preservePaths });
    const targetBytes = await fs.readFile(downloadedManifest);
    if (targetBytes.length !== selection.manifest.size || sha(targetBytes) !== selection.manifest.sha256) fail('HASH_MISMATCH');
    const target = parseManifestBytes(targetBytes, { preservePaths: options.preservePaths });
    validateDeltaTarget(checked, target);
    // Both manifests are proven, so the descriptor's operation list can finally be checked against
    // the plan those two manifests imply: a signed patch that lies about its own ops is refused.
    const { descriptor } = readPatchZip(bytes);
    const patch = parsePatchBytes(descriptor, { base: baseManifest, target });
    for (const entry of [...patch.ops.put, ...patch.ops.deleted]) if (!isAllowedPath(entry.path, allowed)) fail('NOT_ALLOWLISTED', entry.path);
    await fs.copyFile(downloaded, path.join(dir, 'patch.zip'));
    await fs.copyFile(downloadedManifest, path.join(dir, 'manifest.json'));
    await atomicJson(path.join(dir, 'envelope.json'), envelope);
    await atomicJson(path.join(dir, 'plan.json'), {
      schema: 1, mode: 'delta', version: patch.to.version,
      baseManifestSha256: base.sha256, targetManifestSha256: manifestSha256(target),
      puts: patch.ops.put, deletes: patch.ops.deleted
    });
    state = { ...state, phase: 'staged', staged: stageId, files: patch.ops.put.map(entry => entry.path), deletes: patch.ops.deleted.map(entry => entry.path) };
    return { ...state };
  }); }
  async function gate() {
    if (!independentUpdater) fail('INDEPENDENT_UPDATER_REQUIRED');
    if (typeof isBusy !== 'function' || await isBusy()) fail('CLIENT_BUSY');
    if (typeof verifyQuiescence !== 'function') fail('QUIESCENCE_REQUIRED');
    const proof = await verifyQuiescence();
    if (proof?.safeToApply !== true || proof.activeSessions !== 0 || proof.processesReleased !== true) {
      // "Still busy" without saying what is still open is not actionable, so the refused items and
      // the evidence that refused them travel with the error.
      const missing = Array.isArray(proof?.missing) && proof.missing.length ? [...proof.missing] : [];
      if (!missing.length && proof && proof.safeToApply !== true) missing.push('unknown');
      const error = Object.assign(new Error('the installation is not ready to be replaced' + (missing.length ? ' (still open: ' + missing.join(', ') + ')' : '') + (proof?.detail ? ': ' + proof.detail : '')), { code: 'CLIENT_BUSY', missing, proof: proof ?? null });
      state = { ...state, notReady: { missing, detail: proof?.detail ?? null, at: new Date().toISOString(), evidence: proof?.items ?? null } };
      throw error;
    }
    if (state.notReady) state = { ...state, notReady: null };
  }
  async function restoreReceipt(journal, record) {
    const item = { name: RECEIPT_FILE };
    try {
      await noLinks(root, '.client-update/' + RECEIPT_FILE);
      const file = path.join(home, RECEIPT_FILE);
      let raw = null; try { raw = await fs.readFile(file); } catch (e) { if (e.code !== 'ENOENT') throw e; }
      if (!journal.priorReceipt.present) {
        if (raw === null) return;
        // Only a receipt this transaction demonstrably wrote may be removed; anything else is unknown.
        let owned = false;
        try { const rec = JSON.parse(raw.toString('utf8')); owned = rec?.schema === 1 && rec?.envelope?.payload === journal.envelope.payload && rec?.envelope?.signature === journal.envelope.signature; } catch { owned = false; }
        if (!owned) fail('UNOWNED_RECEIPT', 'an installed-version receipt this transaction did not write is retained');
        await gate(); await fs.rm(file, { force: true }); return;
      }
      const bytes = Buffer.from(journal.priorReceipt.bytes, 'base64');
      if (sha(bytes) !== journal.priorReceipt.sha256) fail('RECEIPT_BACKUP_CORRUPT', 'prior installed-version receipt snapshot is corrupt');
      if (raw !== null && raw.equals(bytes)) return;
      await gate(); await writeReceiptBytes(bytes);
    } catch (e) { record(item, e); }
  }
  // A journal snapshot is either provably absent or a provable copy: a schema-3 journal may
  // never degrade into a lossy rollback.
  function validateSnapshot(snapshot) {
    if (!snapshot || typeof snapshot !== 'object' || typeof snapshot.present !== 'boolean') fail('INVALID_JOURNAL');
    if (snapshot.present) {
      if (!/^[a-f0-9]{64}$/.test(snapshot.sha256 ?? '') || typeof snapshot.bytes !== 'string') fail('INVALID_JOURNAL');
      try { b64(snapshot.bytes); } catch { fail('INVALID_JOURNAL'); }
    } else if (snapshot.sha256 != null || snapshot.bytes != null) fail('INVALID_JOURNAL');
  }
  function managedName(name) {
    const safe = safeName(name);
    if (!allowed.some(prefix => safe.toLowerCase() === prefix.toLowerCase() || safe.toLowerCase().startsWith(prefix.toLowerCase() + '/'))) fail('INVALID_JOURNAL');
    return safe;
  }
  // The baseline is undone with the same proof as the receipt: only a file this transaction can be
  // shown to have written may be removed, and only a snapshot that hashes correctly may be restored.
  async function restoreBaseline(journal, record) {
    const item = { name: '.client-update/' + BASELINE_FILE };
    try {
      await noLinks(root, '.client-update/' + BASELINE_FILE);
      const file = path.join(home, BASELINE_FILE);
      let raw = null; try { raw = await fs.readFile(file); } catch (e) { if (e.code !== 'ENOENT') throw e; }
      if (!journal.priorBaseline.present) {
        if (raw === null) return;
        if (sha(raw) !== journal.installedManifestSha256) fail('UNOWNED_BASELINE', 'an installed manifest this transaction did not write is retained');
        await gate(); await fs.rm(file, { force: true }); return;
      }
      const bytes = Buffer.from(journal.priorBaseline.bytes, 'base64');
      if (sha(bytes) !== journal.priorBaseline.sha256) fail('BASELINE_BACKUP_CORRUPT', 'prior installed manifest snapshot is corrupt');
      if (raw !== null && raw.equals(bytes)) return;
      await gate(); await writeBaseline(root, bytes);
    } catch (e) { record(item, e); }
  }
  async function restore(journal) {
    const schema3 = journal?.schema === 3;
    let puts, deletes;
    if (schema3) {
      if (!version(journal.version) || !journal.envelope || typeof journal.envelope.payload !== 'string' || typeof journal.envelope.signature !== 'string') fail('INVALID_JOURNAL');
      if (!/^[0-9a-f-]{36}$/.test(journal.stageId ?? '')) fail('INVALID_JOURNAL');
      validateSnapshot(journal.priorReceipt); validateSnapshot(journal.priorBaseline);
      if (!/^[a-f0-9]{64}$/.test(journal.installedManifestSha256 ?? '')) fail('INVALID_JOURNAL');
      if (!Array.isArray(journal.puts) || !Array.isArray(journal.deletes)) fail('INVALID_JOURNAL');
      if (journal.puts.length + journal.deletes.length > limits.files) fail('INVALID_JOURNAL');
      const claimed = new Set();
      const claim = name => { const key = name.toLowerCase(); if (claimed.has(key)) fail('INVALID_JOURNAL'); claimed.add(key); };
      for (const item of journal.puts) {
        if (!item || typeof item !== 'object') fail('INVALID_JOURNAL');
        claim(managedName(item.name));
        if (typeof item.existed !== 'boolean' || !/^[a-f0-9]{64}$/.test(item.installedHash ?? '')) fail('INVALID_JOURNAL');
        if (item.existed) { if (!/^[a-f0-9]{64}$/.test(item.backupHash ?? '')) fail('INVALID_JOURNAL'); }
        else if (item.backupHash != null) fail('INVALID_JOURNAL');
      }
      for (const item of journal.deletes) {
        if (!item || typeof item !== 'object') fail('INVALID_JOURNAL');
        claim(managedName(item.name));
        if (!/^[a-f0-9]{64}$/.test(item.installedHash ?? '') || !/^[a-f0-9]{64}$/.test(item.backupHash ?? '')) fail('INVALID_JOURNAL');
      }
      // The directory-level switch is described by top-level entry names. They are validated with the
      // same rule every other path goes through: a journal is a file on disk, and a journal that
      // names "../outside" must be refused before a single rename happens, not after.
      if (journal.swaps !== undefined && !Array.isArray(journal.swaps)) fail('INVALID_JOURNAL');
      if (Array.isArray(journal.swaps) && journal.swaps.length > limits.files) fail('INVALID_JOURNAL');
      for (const swap of journal.swaps || []) {
        if (!swap || typeof swap !== 'object' || typeof swap.entry !== 'string' || !swap.entry || swap.entry.includes('/')) fail('INVALID_JOURNAL');
        if (safeName(swap.entry) !== swap.entry) fail('INVALID_JOURNAL');
        if (typeof swap.existed !== 'boolean') fail('INVALID_JOURNAL');
        if (swap.existed ? swap.old !== '.client-update/old/' + swap.entry : swap.old !== null) fail('INVALID_JOURNAL');
      }
      journal.swaps = journal.swaps || [];
      puts = journal.puts; deletes = journal.deletes;
    } else {
      if (!Array.isArray(journal.files) || journal.files.length > limits.files || !/^[0-9a-f-]{36}$/.test(journal.stageId ?? '')) fail('INVALID_JOURNAL');
      const schema2 = journal.schema !== undefined;
      if (schema2) {
        // A schema-2 journal may never degrade into the legacy path: its snapshot is what makes the
        // receipt rollback provable, so a missing snapshot is a hard refusal.
        if (journal.schema !== 2 || !version(journal.version) || !journal.envelope || typeof journal.envelope.payload !== 'string' || typeof journal.envelope.signature !== 'string') fail('INVALID_JOURNAL');
        validateSnapshot(journal.priorReceipt);
      } else if (await readReceiptBytes() !== null) fail('INVALID_JOURNAL', 'legacy journal cannot be reconciled while an installed-version receipt exists');
      for (const item of journal.files) {
        const name = safeName(item.name);
        if (!allowed.some(prefix => name.toLowerCase() === prefix.toLowerCase() || name.toLowerCase().startsWith(prefix.toLowerCase() + '/')) || typeof item.existed !== 'boolean') fail('INVALID_JOURNAL');
        if (item.installedHash !== undefined && !/^[a-f0-9]{64}$/.test(item.installedHash)) fail('INVALID_JOURNAL');
      }
      puts = journal.files; deletes = [];
      journal.swaps = [];
    }
    const errors = [];
    const record = (item, e) => errors.push({ name: item.name, code: e.code ?? e.message, message: e.message });
    // Directory-level switch, undone first: the original top-level entries are renamed back into
    // place so the per-file pass below still validates (and repairs) every byte it recorded, and
    // so bytes that belonged to the entry but were not part of the package travel back with it.
    // Nothing is deleted: the half-landed entry is parked under .client-update/failed/<stage>.
    const swaps = Array.isArray(journal.swaps) ? [...journal.swaps].reverse() : [];
    for (const swap of swaps) {
      const item = { name: String(swap?.entry ?? '?') };
      try {
        if (!swap || typeof swap.entry !== 'string' || !swap.entry || !swap.old) continue;
        await noLinks(root, swap.entry); await noLinks(root, '.client-update/old/' + swap.entry);
        const live = path.join(root, swap.entry);
        const old = path.join(home, 'old', swap.entry);
        let oldExists = true; try { await fs.lstat(old); } catch (e) { if (e.code === 'ENOENT') oldExists = false; else throw e; }
        if (!oldExists) continue;
        let liveExists = true; try { await fs.lstat(live); } catch (e) { if (e.code === 'ENOENT') liveExists = false; else throw e; }
        if (liveExists) {
          const parked = path.join(home, 'failed', journal.stageId, swap.entry);
          await fs.rm(parked, { recursive: true, force: true });
          await fs.mkdir(path.dirname(parked), { recursive: true });
          await fs.rename(live, parked);
        }
        await fs.rename(old, live);
      } catch (e) { record(item, e); }
    }
    // Backup bytes are written through a private temp path, so a half-prepared restore never
    // becomes the installed file.
    async function restoreFromBackup(item, bytes) {
      const target = path.join(root, item.name);
      await fs.mkdir(path.dirname(target), { recursive: true });
      const restoreTemp = target + '.restore-' + randomUUID();
      const handle = await fs.open(restoreTemp, 'wx');
      const identity = await handle.stat();
      try {
        await handle.writeFile(bytes); await handle.close();
        const st = await fs.lstat(restoreTemp);
        if (!st.isFile() || st.dev !== identity.dev || st.ino !== identity.ino) fail('TEMP_PATH_OCCUPIED');
        await fs.rename(restoreTemp, target);
      }
      finally {
        await handle.close();
        try { const st = await fs.lstat(restoreTemp); if (st.isFile() && st.dev === identity.dev && st.ino === identity.ino) await fs.rm(restoreTemp); else fail('TEMP_PATH_OCCUPIED'); }
        catch (e) { if (e.code !== 'ENOENT') record(item, e); }
      }
    }
    for (const item of [...puts].reverse()) {
      const target = path.join(root, item.name);
      try {
        // Never delete a temp path we did not create (including crash leftovers).
        const temp = target + '.update-' + journal.stageId;
        try { await fs.lstat(temp); record(item, Object.assign(new Error('Unowned update temporary path retained'), { code: 'TEMP_PATH_OCCUPIED' })); }
        catch (e) { if (e.code !== 'ENOENT') throw e; }
        await gate(); await noLinks(root, item.name); await noLinks(root, '.client-update/backup/' + item.name);
        if (item.existed) {
          const bytes = await fs.readFile(path.join(home, 'backup', item.name));
          if (sha(bytes) !== item.backupHash) fail('BACKUP_CORRUPT');
          await restoreFromBackup(item, bytes);
        } else {
          try {
            const st = await fs.lstat(target);
            if (!st.isFile() || !item.installedHash || sha(await fs.readFile(target)) !== item.installedHash) fail('UNOWNED_TARGET');
            await fs.rm(target);
          } catch (e) { if (e.code !== 'ENOENT') throw e; }
        }
      } catch (e) { record(item, e); }
    }
    for (const item of [...deletes].reverse()) {
      const target = path.join(root, item.name);
      try {
        const temp = target + '.update-' + journal.stageId;
        try { await fs.lstat(temp); record(item, Object.assign(new Error('Unowned update temporary path retained'), { code: 'TEMP_PATH_OCCUPIED' })); }
        catch (e) { if (e.code !== 'ENOENT') throw e; }
        await gate(); await noLinks(root, item.name); await noLinks(root, '.client-update/backup/' + item.name);
        const bytes = await fs.readFile(path.join(home, 'backup', item.name));
        if (sha(bytes) !== item.backupHash) fail('BACKUP_CORRUPT');
        await restoreFromBackup(item, bytes);
      } catch (e) { record(item, e); }
    }
    for (const swap of swaps) {
      if (!swap || swap.old || typeof swap.entry !== 'string' || !swap.entry) continue;
      const item = { name: String(swap.entry) };
      try {
        const live = path.join(root, swap.entry);
        try { await fs.lstat(live); } catch (e) { if (e.code === 'ENOENT') continue; throw e; }
        const parked = path.join(home, 'failed', journal.stageId, swap.entry);
        await fs.rm(parked, { recursive: true, force: true });
        await fs.mkdir(path.dirname(parked), { recursive: true });
        await fs.rename(live, parked);
      } catch (e) { record(item, e); }
    }
    if (schema3 || journal.schema === 2) await restoreReceipt(journal, record);
    if (schema3) await restoreBaseline(journal, record);
    if (!errors.length) {
      try { options.testOnlyStep?.('rollback-unlink'); await fs.rm(path.join(home, 'journal.json'), { force: true }); }
      catch (e) { errors.push({ name: '.client-update/journal.json', code: e.code ?? e.message, message: e.message }); }
    }
    if (errors.length) {
      journal.rollbackErrors = [...(journal.rollbackErrors ?? []), ...errors];
      try { await atomicJson(path.join(home, 'journal.json'), journal); } catch (e) { record({ name: '.client-update/journal.json' }, e); journal.rollbackErrors.push(errors[errors.length - 1]); }
      throw Object.assign(new AggregateError(errors.map(e => Object.assign(new Error(e.message), { code: e.code, name: e.name })), 'Rollback incomplete'), { code: errors[0].code, rollbackErrors: journal.rollbackErrors });
    }
  }
  async function acquireLock(lock) {
    await noLinks(root, '.client-update/apply.lock');
    try { const h = await fs.open(lock, 'wx'); await h.writeFile(JSON.stringify({ pid: process.pid })); await h.sync(); await h.close(); }
    catch (e) {
      if (e.code !== 'EEXIST') throw e;
      const owner = JSON.parse(await fs.readFile(lock, 'utf8'));
      if (!Number.isSafeInteger(owner.pid) || owner.pid <= 0) fail('APPLY_LOCKED');
      try { process.kill(owner.pid, 0); fail('APPLY_LOCKED'); } catch (error) { if (error.code !== 'ESRCH') throw error; }
      await fs.rm(lock); return acquireLock(lock);
    }
  }
  // The identity a rebuilt baseline must carry. The signed payload is authenticated, so its
  // fields win; trusted manager options come second; the publisher defaults last.
  function baselineIdentity(p) {
    const product = typeof p.product === 'string' && p.product ? p.product : options.product;
    const endpoint = typeof p.endpoint === 'string' && p.endpoint ? p.endpoint : options.endpoint;
    return { product: product || 'LastROClient', endpoint: endpoint || 'external' };
  }
  async function receiptSnapshot() {
    const bytes = await readReceiptBytes();
    return { present: bytes !== null, sha256: bytes ? sha(bytes) : null, bytes: bytes ? bytes.toString('base64') : null };
  }
  async function baselineSnapshot() {
    const found = await readInstalledManifest();
    return { present: found !== null, sha256: found?.sha256 ?? null, bytes: found ? found.bytes.toString('base64') : null };
  }
  // The receipt names the baseline this transaction published, so the NEXT check can prove a patch
  // belongs to this installation instead of merely claiming to.
  async function publishReceipt(stagedEnvelope, p, installedManifestSha256) {
    const receipt = { schema: 1, envelope: stagedEnvelope, zipSha256: p.package.sha256.toLowerCase(), feedUrl: feedId, channel, spkiHash, packageRoot, installedManifestSha256 };
    await writeReceiptBytes(Buffer.from(JSON.stringify(receipt), 'utf8'));
  }
  // verifyInstalledTree reports a leftover managed file as 'unexpected' too. That is a fact worth
  // reporting but not grounds to refuse an update: a full package cannot remove a file it does not
  // contain, and a patch only ever touches the paths its plan names. Refusing on 'unexpected' would
  // leave an installation with one stale file permanently unable to update. Everything the manifest
  // itself claims, however, must be exactly right.
  async function verifyTreeOrFail(manifest, label, { tolerateUnexpected = true } = {}) {
    const { mismatches } = await verifyInstalledTree(root, manifest, { allowedPaths: allowed, preservePaths: preserved });
    const problems = tolerateUnexpected ? mismatches.filter(m => m.reason !== 'unexpected') : mismatches;
    if (problems.length) fail('INSTALLED_TREE_MISMATCH', label + ': ' + problems.slice(0, 5).map(m => m.path + ' (' + m.reason + ')').join(', '));
    return mismatches;
  }
  // A staged artifact is only usable when it is exactly the file the signed descriptor names.
  async function stagedBytes(file, descriptor, label) {
    await noLinks(root, path.relative(root, file).split(path.sep).join('/'));
    const st = await fs.lstat(file);
    if (st.isSymbolicLink()) fail('SYMLINK_PATH');
    if (!st.isFile()) fail('NON_FILE_TARGET', label + ' is not a regular file');
    if (st.size !== descriptor.size) fail('SIZE_MISMATCH', label + ' size does not match the signed descriptor');
    const bytes = await fs.readFile(file);
    if (bytes.length !== descriptor.size || sha(bytes) !== String(descriptor.sha256).toLowerCase()) fail('HASH_MISMATCH', label + ' is not the artifact the signature names');
    return bytes;
  }
  // Land one file through a private temp path so a partially written replacement never becomes
  // the installed bytes.
  async function replaceFile(name, data, stageIdValue) {
    await gate(); await noLinks(root, name);
    const target = path.join(root, name); await fs.mkdir(path.dirname(target), { recursive: true });
    const temp = target + '.update-' + stageIdValue; await noLinks(root, name + '.update-' + stageIdValue);
    const handle = await fs.open(temp, 'wx'); const identity = await handle.stat();
    try {
      await handle.writeFile(data); await handle.close();
      const st = await fs.lstat(temp);
      if (!st.isFile() || st.dev !== identity.dev || st.ino !== identity.ino) fail('TEMP_PATH_OCCUPIED');
      await fs.rename(temp, target);
    } catch (e) {
      try {
        await handle.close(); const st = await fs.lstat(temp);
        if (!st.isFile() || st.dev !== identity.dev || st.ino !== identity.ino) fail('TEMP_PATH_OCCUPIED');
        await fs.rm(temp);
      } catch (cleanupError) { if (cleanupError.code !== 'ENOENT') e.cleanupError = cleanupError.code ?? cleanupError.message; }
      throw e;
    }
  }
  function samePlan(left, right) {
    if (left.length !== right.length) return false;
    for (let i = 0; i < left.length; i++) {
      if (left[i].path !== right[i].path || left[i].size !== right[i].size || left[i].sha256 !== right[i].sha256) return false;
    }
    return true;
  }
  // Same-volume staging tree. It is written only after the archive, its hash and its itemized
  // manifest all verified, so the switch that follows is a rename and nothing else.
  async function writeStageTree(dir, files) {
    const tree = path.join(dir, 'tree');
    await noLinks(root, path.relative(root, tree).split(path.sep).join('/'));
    await fs.rm(tree, { recursive: true, force: true });
    for (const file of files) {
      const target = path.join(tree, file.name);
      await fs.mkdir(path.dirname(target), { recursive: true });
      const handle = await fs.open(target, 'wx');
      try { await handle.writeFile(file.data); await handle.sync(); } finally { await handle.close(); }
    }
    return tree;
  }
  // The staged payload is tens of megabytes and is dead weight once the transaction has committed.
  // Best effort: a cleanup failure must never turn a committed update into an uncommitted one.
  async function cleanupStage(dir) {
    try { await fs.rm(dir, { recursive: true, force: true }); } catch { /* left for the next attempt */ }
  }
  // The swap directory holds the top-level entries that were moved aside. After a committed switch
  // or a finished rollback every entry has been moved back out, so the directory is empty and can
  // go; a rollback that could not finish leaves it alone, because it still holds the only copy.
  async function pruneOld() {
    try { await fs.rmdir(path.join(home, 'old')); } catch { /* not empty, or already gone */ }
  }
  // After a committed switch the previous entries under .client-update/old are dead weight: the
  // journal is unlinked (the commit point), the receipt and the baseline name the new tree, and the
  // new tree has just been verified in place. A rollback that could not finish never comes here.
  async function discardOld() {
    try { await fs.rm(path.join(home, 'old'), { recursive: true, force: true }); } catch { /* left behind */ }
  }
  // Bounded reclamation of what a failed rollback leaves behind.
  //
  // restore() parks every live entry it had to undo under .client-update/failed/<stageId>, and the
  // stage those entries were staged in stays on disk as well. Nothing reads either one back: a
  // rollback is driven by the journal, .client-update/backup and .client-update/old alone, and
  // recover() reads only the journal. An instrumented crash-then-recover run shows the rollback
  // touching failed/ with the two parking writes and NO read at all, leave a decoy in there and it
  // survives untouched, and delete the whole directory and check/download/stage/apply still
  // succeed. They are forensics, so the newest `retention` of them are kept — with
  // their stage, so that same update can still be retried — and everything older is removed here.
  //
  // This runs only where a transaction has already settled (a committed apply, a finished recovery,
  // startup), and it is best effort by construction: the update has happened, so a cleanup failure
  // is a logged note, never an error the caller or the service start ever sees.
  async function stageDirs(at) {
    let entries;
    try { entries = await fs.readdir(at, { withFileTypes: true }); }
    catch (e) { if (e.code === 'ENOENT' || e.code === 'ENOTDIR') return []; throw e; }
    const found = [];
    for (const entry of entries) {
      // Only a directory named exactly like a stage id is a candidate; anything else someone put
      // there (a personal file, a name an older build used) is not ours to delete.
      if (!entry.isDirectory() || entry.isSymbolicLink() || !STAGE_ID.test(entry.name)) continue;
      try { found.push({ name: entry.name, mtimeMs: (await fs.lstat(path.join(at, entry.name))).mtimeMs }); }
      catch { /* vanished under us: nothing left to reclaim */ }
    }
    return found;
  }
  // The stage a pending journal still needs. "No journal" and "a journal that cannot be read" are
  // different answers: an unreadable one means the live stage cannot be named, so prune nothing.
  async function journalStageId() {
    try {
      await noLinks(root, '.client-update/journal.json');
      const journal = JSON.parse(await fs.readFile(path.join(home, 'journal.json'), 'utf8'));
      return { known: true, id: typeof journal?.stageId === 'string' ? journal.stageId : null };
    } catch (e) {
      if (e.code === 'ENOENT') return { known: true, id: null };
      return { known: false, id: null };
    }
  }
  async function reclaim({ keepStageId = null } = {}) {
    const problems = [];
    const note = (what, error) => {
      const entry = { what, code: error?.code ?? error?.message ?? String(error) };
      problems.push(entry);
      // A log hook must never be the reason a settled update fails.
      try { options.onCleanupProblem?.(entry); } catch { /* ignored on purpose */ }
      try { process.emitWarning('client-update cleanup: ' + what + ' (' + entry.code + ')', { code: 'CLIENT_UPDATE_CLEANUP' }); }
      catch { /* stderr gone: the state record below still carries it */ }
    };
    try {
      // (1) the newest failure records keep their evidence; older ones go, with their stage.
      const records = (await stageDirs(path.join(home, 'failed')))
        .sort((a, b) => b.mtimeMs - a.mtimeMs || (a.name < b.name ? 1 : -1));
      const keep = new Set(records.slice(0, retention).map(record => record.name));
      for (const record of records.slice(retention)) {
        try { await fs.rm(path.join(home, 'failed', record.name), { recursive: true, force: true }); }
        catch (e) { note('failed/' + record.name, e); continue; } // keep the stage while its record is still there
        try { await fs.rm(path.join(home, 'stages', record.name), { recursive: true, force: true }); }
        catch (e) { note('stages/' + record.name, e); }
      }
      // (2) orphan stages: no live transaction names one, no journal refers to one, no retained
      // failure record came from one — and it is old enough that a staging this process cannot see
      // (the client stages its own update in its own process) has finished or been abandoned.
      const pending = await journalStageId();
      if (!pending.known) return problems;
      const referenced = new Set(keep);
      if (pending.id) referenced.add(pending.id);
      if (keepStageId) referenced.add(keepStageId);
      const cutoff = Date.now() - orphanGraceMs;
      for (const entry of await stageDirs(path.join(home, 'stages'))) {
        if (referenced.has(entry.name) || entry.mtimeMs > cutoff) continue;
        try { await fs.rm(path.join(home, 'stages', entry.name), { recursive: true, force: true }); }
        catch (e) { note('stages/' + entry.name, e); }
      }
    } catch (e) { note('reclaim', e); }
    if (problems.length) state = { ...state, cleanup: { at: new Date().toISOString(), problems } };
    return problems;
  }
  // The journal write is what makes the transaction recoverable; the unlink is the single commit
  // point, so every failure before it rolls the whole transaction back.
  async function commit(journalFile, journal, land) {
    await atomicJson(journalFile, journal);
    try {
      await land();
      options.testOnlyStep?.('commit-unlink');
      await fs.rm(journalFile);
    } catch (e) {
      let rolledBack = false;
      try { await restore(journal); rolledBack = true; await pruneOld(); } catch (rollbackError) { e.rollbackError = rollbackError.code ?? rollbackError.message; e.rollbackErrors = rollbackError.rollbackErrors ?? [{ code: e.rollbackError, message: rollbackError.message }]; }
      // Rolling the files back is not the same as having a working client again. When the caller
      // supplied a health probe, it runs once more against the restored (old) tree and its verdict
      // travels with the failure, so a half-restored installation is never reported as a plain
      // "update failed".
      if (rolledBack) state = { ...state, rolledBack: true, failedVersion: journal.version, failedCode: e.code ?? e.message };
      if (rolledBack && typeof options.healthCheck === 'function') {
        try {
          const back = await options.healthCheck({ root, version: null, stageId: journal.stageId, phase: 'rollback' });
          e.rollbackHealth = back ?? null;
          if (!back || (back.ok !== true && !(back.skipped === true && options.requireHealthCheck !== true))) { e.rollbackHealthUnhealthy = true; state = { ...state, rollbackHealth: back ?? null, rollbackHealthUnhealthy: true }; }
        } catch (healthError) { e.rollbackHealth = { ok: false, reason: healthError.code ?? healthError.message }; e.rollbackHealthUnhealthy = true; }
      }
      throw e;
    }
  }
  function appliedState(p, id) {
    // The applied state carries the proofs this transaction made, so the caller can report what was
    // checked instead of only that it finished.
    return { phase: 'applied', disabled: false, version: p.version, staged: id, available: false, recoveryRequired: false, error: null, preserve: state.preserve ?? null, health: state.health ?? null, rolledBack: false };
  }
  // The switch itself. Every managed top-level entry is moved aside by rename and the verified
  // staged entry lands by rename, so no installed file is ever deleted and rewritten in place.
  // The pre-flight runs before the first rename: a leftover temp path we did not create is a
  // refusal, not something to adopt or delete.
  async function landEntries(id, journal, files, treeDir) {
    const entries = [...new Set(files.map(f => String(f.name).split('/')[0]))].sort();
    for (const file of files) {
      const target = path.join(root, file.name);
      const temp = target + '.update-' + id;
      // A temp path can only exist where its parent directory exists, so the probe creates the
      // parent's absence as "no leftover" instead of creating directories before the switch.
      let parent = true;
      try { const st = await fs.lstat(path.dirname(target)); parent = st.isDirectory(); } catch { parent = false; }
      if (!parent) continue;
      const handle = await fs.open(temp, 'wx');
      try { await handle.close(); } catch { /* a probe handle needs no identity check */ }
      await fs.rm(temp, { force: true });
    }
    await fs.mkdir(path.join(home, 'old'), { recursive: true });
    for (const entry of entries) {
      await gate();
      await noLinks(root, entry);
      const plan = journal.swaps.find(s => s.entry === entry);
      const live = path.join(root, entry);
      if (plan && plan.existed) {
        const side = path.join(home, 'old', entry);
        await fs.rm(side, { recursive: true, force: true });
        await fs.rename(live, side);
      }
      await fs.rename(path.join(treeDir, entry), live);
    }
  }
  // The rename replaces a whole directory, so anything living inside it that the package does not
  // describe (personal data, or a file an earlier version left behind) would be carried away and
  // then dropped with the old tree. Those files are therefore copied into the staged entry first:
  // the switch then carries them over exactly as the previous file-level landing did, and the
  // post-switch check still reports them as "unexpected" without ever deleting one.
  async function carryExtraInto(tree, entry, expectedLower) {
    const stack = [entry];
    while (stack.length) {
      const relative = stack.pop();
      const absolute = path.join(root, relative);
      let st; try { st = await fs.lstat(absolute); } catch (e) { if (e.code === 'ENOENT') continue; throw e; }
      if (st.isSymbolicLink()) continue;
      if (st.isDirectory()) {
        let children = []; try { children = await fs.readdir(absolute); } catch { continue; }
        for (const name of children) stack.push(relative + '/' + name);
        continue;
      }
      if (!st.isFile()) continue;
      if (expectedLower.has(relative.toLowerCase())) continue;
      // The staged tree mirrors the installation root, so the carried file keeps its full relative
      // path: tree/app/save.dat, not tree/save.dat.
      const target = path.join(tree, relative);
      await fs.mkdir(path.dirname(target), { recursive: true });
      try { await fs.copyFile(absolute, target, fs.constants.COPYFILE_EXCL); }
      catch (e) { if (e.code !== 'EEXIST') throw e; }
    }
  }
  // Post-switch health proof. Injected by the caller (the production applier supplies one), so the
  // core stays free of process management; a failure here is an ordinary transaction failure that
  // rolls back.
  async function runHealthCheck(id, p, phase) {
    if (typeof options.healthCheck !== 'function') return null;
    const result = await options.healthCheck({ root, version: phase === 'apply' ? p.version : null, stageId: id, phase });
    state = { ...state, health: result ?? null };
    if (!result || result.ok !== true) {
      if (result && result.skipped === true && options.requireHealthCheck !== true) return result;
      fail('HEALTH_CHECK_FAILED', 'the client did not start after the switch: ' + ((result && result.reason) || 'no result'));
    }
    return result;
  }
  async function applyFull(dir, id, p, stagedEnvelope) {
    const bytes = await stagedBytes(path.join(dir, 'package.zip'), p.package, 'staged package');
    const files = unpack(bytes);
    verifyPackageManifest(files, { packageRoot: options.packageRoot, requireItemizedManifest: options.requireItemizedManifest === true });
    const identity = baselineIdentity(p);
    const owned = buildOwnedManifest(files, {
      preservePaths: preserved, product: identity.product, endpoint: identity.endpoint,
      version: p.version, packageSha256: p.package.sha256.toLowerCase(), packageSize: p.package.size
    });
    // The staged tree the switch renames in. A stage written by an older build (or left behind by
    // a crash) is rebuilt here from the already verified package bytes.
    const treeDir = path.join(dir, 'tree');
    // A crash during an earlier switch consumes the staged entries (they were renamed into place),
    // so the tree is rebuilt whenever any entry it must rename is missing.
    const wantedEntries = [...new Set(files.map(f => String(f.name).split('/')[0]))];
    let treeReady = true;
    try { const st = await fs.lstat(treeDir); treeReady = st.isDirectory(); } catch { treeReady = false; }
    if (treeReady) {
      for (const entry of wantedEntries) {
        try { await fs.lstat(path.join(treeDir, entry)); }
        catch { treeReady = false; break; }
      }
    }
    if (!treeReady) await writeStageTree(dir, files);
    // The swap plan is part of the journal, which is durable BEFORE the first rename, so a crash in
    // the middle of the switch is always recoverable from the journal alone.
    const entryNames = [...new Set(files.map(f => String(f.name).split('/')[0]))].sort();
    const expectedLower = new Set(files.map(f => String(f.name).toLowerCase()));
    const swaps = [];
    for (const entry of entryNames) {
      await noLinks(root, entry);
      let existed = true;
      try { const st = await fs.lstat(path.join(root, entry)); if (st.isSymbolicLink()) fail('SYMLINK_PATH'); }
      catch (e) { if (e.code !== 'ENOENT') throw e; existed = false; }
      if (existed) await carryExtraInto(treeDir, entry, expectedLower);
      swaps.push({ entry, existed, old: existed ? '.client-update/old/' + entry : null });
    }
    // Snapshot of the personal data BEFORE the first rename, so the post-switch proof compares
    // against what was actually there rather than against an assumption.
    const preserveBefore = preserved.length ? await snapshotPreserved(root, preserved) : null;
    const journal = {
      schema: 3, mode: 'full', version: p.version, stageId: id, envelope: stagedEnvelope,
      zipSha256: p.package.sha256.toLowerCase(),
      priorReceipt: await receiptSnapshot(), priorBaseline: await baselineSnapshot(),
      installedManifestSha256: owned.sha256, puts: [], deletes: [], swaps
    };
    await fs.rm(path.join(home, 'backup'), { recursive: true, force: true });
    for (const f of files) {
      await noLinks(root, f.name); const target = path.join(root, f.name); let existed = false;
      try { const st = await fs.lstat(target); if (!st.isFile()) fail('NON_FILE_TARGET'); existed = true; const backup = path.join(home, 'backup', f.name); await fs.mkdir(path.dirname(backup), { recursive: true }); await fs.copyFile(target, backup); }
      catch (e) { if (e.code !== 'ENOENT') throw e; }
      journal.puts.push({ name: f.name, existed, installedHash: sha(f.data), ...(existed ? { backupHash: sha(await fs.readFile(path.join(home, 'backup', f.name))) } : {}) });
    }
    await commit(path.join(home, 'journal.json'), journal, async () => {
      // Pre-check done, staging verified: now the switch.
      await landEntries(id, journal, files, treeDir);
      for (const f of files) options.testOnlyAfterReplace?.(f.name);
      // (1) the bytes that are on disk now, hashed file by file, not the return value of a copy
      await verifyTreeOrFail(owned.manifest, 'the installed tree does not match the signed package');
      // (2) the personal data list, item by item
      if (preserveBefore) {
        const preserveAfter = await verifyPreserved(root, preserveBefore);
        journal.preserve = { checked: preserveAfter.checked, added: preserveAfter.addedCount, problems: preserveAfter.problems };
        state = { ...state, preserve: journal.preserve };
        if (!preserveAfter.ok) fail('PRESERVE_PATHS_CHANGED', 'personal data was modified by the switch: ' + preserveAfter.problems.slice(0, 5).map(x => x.path + ' (' + x.reason + ')').join(', '));
      }
      await writeBaseline(root, owned.bytes);
      options.testOnlyStep?.('receipt-write');
      await publishReceipt(stagedEnvelope, p, owned.sha256);
      // (3) it really starts
      await runHealthCheck(id, p, 'apply');
    });
    await cleanupStage(dir); await discardOld();
    state = appliedState(p, id);
    await reclaim({ keepStageId: id });
    return { ...state };
  }
  // A valid artifact must also be the target the signed release names and stay inside local policy.
  function validateDeltaTarget(p, target) {
    const identity = baselineIdentity(p);
    if (target.version !== p.version) fail('TARGET_VERSION_MISMATCH');
    if (target.package.sha256 !== p.package.sha256.toLowerCase() || target.package.size !== p.package.size) fail('TARGET_PACKAGE_MISMATCH');
    if (target.product !== identity.product) fail('PRODUCT_MISMATCH');
    if (target.endpoint !== identity.endpoint) fail('ENDPOINT_MISMATCH');
    if (target.files.length > limits.files || target.files.reduce((total, file) => total + file.size, 0) > limits.unpacked) fail('UNPACK_LIMIT');
    for (const file of target.files) if (!isAllowedPath(file.path, allowed)) fail('NOT_ALLOWLISTED', file.path);
  }
  async function applyDelta(dir, id, p, stagedEnvelope, plan) {
    if (options.deltaApply !== true) fail('DELTA_DISABLED', 'incremental apply is not enabled for this manager');
    if (!p.delta || !p.manifest) fail('INVALID_PATCH', 'the signed feed does not describe both a delta and its target manifest');
    if (!plan || plan.schema !== 1 || plan.mode !== 'delta' || !version(plan.version) || !HEX64.test(plan.baseManifestSha256 ?? '') || !HEX64.test(plan.targetManifestSha256 ?? '') || !Array.isArray(plan.puts) || !Array.isArray(plan.deletes)) fail('INVALID_JOURNAL');
    if (plan.version !== p.version || plan.targetManifestSha256 !== p.manifest.sha256) fail('INVALID_JOURNAL');
    const patchBytes = await stagedBytes(path.join(dir, 'patch.zip'), p.delta, 'staged patch');
    const targetBytes = await stagedBytes(path.join(dir, 'manifest.json'), p.manifest, 'staged manifest');
    // The baseline is re-read here rather than trusted from check(): the patch may have been
    // selected minutes before it was applied, and a baseline the receipt does not name is not ours.
    const base = await readInstalledManifest();
    if (!base) fail('BASELINE_MISSING', 'no installed manifest to apply a patch against');
    if (base.sha256 !== p.delta.from.manifestSha256) fail('BASE_MANIFEST_MISMATCH', 'the installed manifest is not the one this patch starts from');
    if (base.sha256 !== plan.baseManifestSha256) fail('INVALID_JOURNAL');
    const prior = await readEffective();
    if (prior.receipt?.installedManifestSha256 !== base.sha256) fail('BASE_MANIFEST_UNBOUND');
    if (compareVersions(p.delta.from.version, prior.effective) !== 0) fail('BASE_VERSION_MISMATCH');
    const baseManifest = parseManifestBytes(base.bytes, { preservePaths: preserved });
    const target = parseManifestBytes(targetBytes, { preservePaths: preserved });
    validateDeltaTarget(p, target);
    if (manifestSha256(baseManifest) !== base.sha256 || manifestSha256(target) !== p.manifest.sha256 || manifestSha256(target) !== plan.targetManifestSha256) fail('INVALID_JOURNAL');
    const { descriptor, payloads } = readPatchZip(patchBytes);
    const patch = parsePatchBytes(descriptor, { base: baseManifest, target });
    for (const entry of [...patch.ops.put, ...patch.ops.deleted]) if (!isAllowedPath(entry.path, allowed)) fail('NOT_ALLOWLISTED', entry.path);
    if (!samePlan(plan.puts, patch.ops.put) || !samePlan(plan.deletes, patch.ops.deleted)) fail('PATCH_PLAN_MISMATCH');
    for (const entry of patch.ops.put) {
      const data = payloads.get(entry.path);
      if (!data || data.length !== entry.size || sha(data) !== entry.sha256) fail('PAYLOAD_MISMATCH', entry.path);
    }
    if (payloads.size !== patch.ops.put.length) fail('UNEXPECTED_PAYLOAD');
    // The operation list is only meaningful while the installation really is the manifest it names.
    await verifyTreeOrFail(baseManifest, 'the installed tree no longer matches the baseline this patch starts from');
    const preserveBefore = preserved.length ? await snapshotPreserved(root, preserved) : null;
    const journal = {
      schema: 3, mode: 'delta', version: p.version, stageId: id, envelope: stagedEnvelope,
      zipSha256: p.package.sha256.toLowerCase(), patchSha256: p.delta.sha256, manifestSha256: p.manifest.sha256,
      priorReceipt: await receiptSnapshot(),
      priorBaseline: { present: true, sha256: base.sha256, bytes: base.bytes.toString('base64') },
      installedManifestSha256: p.manifest.sha256, puts: [], deletes: []
    };
    await fs.rm(path.join(home, 'backup'), { recursive: true, force: true });
    for (const entry of patch.ops.put) {
      await noLinks(root, entry.path); const target2 = path.join(root, entry.path); let existed = false;
      try { const st = await fs.lstat(target2); if (!st.isFile()) fail('NON_FILE_TARGET'); existed = true; const backup = path.join(home, 'backup', entry.path); await fs.mkdir(path.dirname(backup), { recursive: true }); await fs.copyFile(target2, backup); }
      catch (e) { if (e.code !== 'ENOENT') throw e; }
      journal.puts.push({ name: entry.path, existed, installedHash: entry.sha256, ...(existed ? { backupHash: sha(await fs.readFile(path.join(home, 'backup', entry.path))) } : {}) });
    }
    for (const entry of patch.ops.deleted) {
      await noLinks(root, entry.path); const target2 = path.join(root, entry.path);
      const st = await fs.lstat(target2);
      if (!st.isFile()) fail('NON_FILE_TARGET');
      const data = await fs.readFile(target2);
      if (sha(data) !== entry.sha256) fail('BASE_HASH_MISMATCH', 'a file scheduled for deletion is not the one the patch starts from: ' + entry.path);
      const backup = path.join(home, 'backup', entry.path); await fs.mkdir(path.dirname(backup), { recursive: true }); await fs.copyFile(target2, backup);
      journal.deletes.push({ name: entry.path, installedHash: entry.sha256, backupHash: sha(data) });
    }
    await commit(path.join(home, 'journal.json'), journal, async () => {
      for (const entry of patch.ops.put) { await replaceFile(entry.path, payloads.get(entry.path), id); options.testOnlyAfterReplace?.(entry.path); }
      for (const entry of patch.ops.deleted) {
        await gate(); await noLinks(root, entry.path);
        const target2 = path.join(root, entry.path);
        const st = await fs.lstat(target2);
        if (!st.isFile()) fail('NON_FILE_TARGET');
        // Delete only what the plan marks as deleted AND what is provably still the base bytes.
        if (sha(await fs.readFile(target2)) !== entry.sha256) fail('BASE_HASH_MISMATCH', 'a file scheduled for deletion is not the one the patch starts from: ' + entry.path);
        await fs.rm(target2);
      }
      await verifyTreeOrFail(target, 'the patched tree does not match the signed target manifest');
      if (preserveBefore) {
        const preserveAfter = await verifyPreserved(root, preserveBefore);
        journal.preserve = { checked: preserveAfter.checked, added: preserveAfter.addedCount, problems: preserveAfter.problems };
        state = { ...state, preserve: journal.preserve };
        if (!preserveAfter.ok) fail('PRESERVE_PATHS_CHANGED', 'personal data was modified by the patch');
      }
      await writeBaseline(root, targetBytes);
      options.testOnlyStep?.('receipt-write');
      await publishReceipt(stagedEnvelope, p, p.manifest.sha256);
      await runHealthCheck(id, p, 'apply');
    });
    await cleanupStage(dir); await discardOld();
    state = appliedState(p, id);
    await reclaim({ keepStageId: id });
    return { ...state };
  }
  // An interrupted switch (power loss, killed applier) leaves the journal on disk. Recovering is
  // not a new update and not a retry: it undoes the half-done transaction and leaves the
  // installation on the version that was there before, so the client is usable and can be updated
  // again. It takes the same proof as an apply, because it moves the same files.
  async function recover() { return exclusive(async () => {
    if (state.disabled) fail('UPDATES_DISABLED', state.reason);
    await gate(); await ensureHome();
    const lock = path.join(home, 'apply.lock');
    await acquireLock(lock);
    try {
      const journalFile = path.join(home, 'journal.json');
      await noLinks(root, '.client-update/journal.json');
      let journal = null;
      try { journal = JSON.parse(await fs.readFile(journalFile, 'utf8')); } catch (e) { if (e.code !== 'ENOENT') throw e; }
      if (!journal) { state = { ...state, recoveryRequired: false, recovered: false }; await reclaim({ keepStageId: stageId ?? null }); return { ...state, recovered: false }; }
      if (typeof journal !== 'object' || !/^[0-9a-f-]{36}$/.test(journal.stageId ?? '')) fail('INVALID_JOURNAL');
      await restore(journal); await pruneOld();
      state = { ...state, recoveryRequired: false, recovered: true, recoveredStage: journal.stageId, version: (await readEffective()).effective };
      // The rollback is only finished when the old version really runs.
      if (typeof options.healthCheck === 'function') {
        let health = null;
        try { health = await options.healthCheck({ root, version: null, stageId: journal.stageId, phase: 'rollback' }); }
        catch (healthError) { health = { ok: false, reason: healthError.code ?? healthError.message }; }
        state = { ...state, recoveryHealth: health ?? null };
        if (!health || (health.ok !== true && !(health.skipped === true && options.requireHealthCheck !== true))) {
          const bad = Object.assign(new Error('the restored version did not start: ' + ((health && health.reason) || 'no result')), { code: 'RECOVERY_UNHEALTHY' });
          bad.recoveryHealth = health ?? null;
          throw bad;
        }
      }
      await reclaim({ keepStageId: journal.stageId });
      return { ...state };
    } finally { await fs.rm(lock, { force: true }); }
  }); }
  async function apply(id = stageId) { return exclusive(async () => {
    if (state.disabled) fail('UPDATES_DISABLED', state.reason);
    await gate(); await ensureHome();
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(id ?? '')) fail('INVALID_STAGE_ID');
    const lock = path.join(home, 'apply.lock');
    await acquireLock(lock);
    try {
      const journalFile = path.join(home, 'journal.json');
      await noLinks(root, '.client-update/journal.json');
      let previous; try { previous = JSON.parse(await fs.readFile(journalFile, 'utf8')); } catch (e) { if (e.code !== 'ENOENT') throw e; }
      if (previous) await restore(previous);
      // Recovery first, then compare against effective = max(config baseline, installed receipt).
      const effective = (await readEffective()).effective;
      const dir = path.join(home, 'stages', id);
      await noLinks(root, '.client-update/stages/' + id);
      let plan = null;
      try { plan = JSON.parse(await fs.readFile(path.join(dir, 'plan.json'), 'utf8')); }
      catch (e) { if (e.code !== 'ENOENT') throw e; }
      let stagedEnvelope;
      try { stagedEnvelope = JSON.parse(await fs.readFile(path.join(dir, 'envelope.json'), 'utf8')); }
      catch (e) {
        // A stage consumed by a committed transaction is removed on purpose; there is nothing left
        // to apply, and an already-installed update is a no-update rather than a filesystem error.
        if (e.code === 'ENOENT') fail('NO_UPDATE', 'the staged update is no longer present');
        throw e;
      }
      const p = authenticate(stagedEnvelope);
      // Without a usable feed identity the receipt could not be bound to anything; never write one.
      if (!feedId || !spkiHash) fail('RECEIPT_IDENTITY_UNAVAILABLE');
      if (compareVersions(p.version, effective) <= 0) fail('NO_UPDATE');
      if (plan === null) return await applyFull(dir, id, p, stagedEnvelope);
      return await applyDelta(dir, id, p, stagedEnvelope, plan);
    } finally { await fs.rm(lock, { force: true }); }
  }); }
  return { check, download, stage, apply, recover, status: () => ({ ...state }), refreshStatus, init };
}

#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createUpdateManager } from './index.mjs';

// Production hosts invoke runUpdater in a separate Node process with a trusted
// quiescence adapter. A client button cannot authorize replacement by itself.
export async function runUpdater(argv, adapters = {}) {
  // The independent replace process (client-update-apply.mjs) forwards its whole command line
  // here, so every flag it is allowed to be started with must be accepted here too: --service names
  // the file it restarts, and the ports name where. The three boolean flags must not consume the
  // following token, or "--recover" placed last would be swallowed by "--relaunch" (or by nothing)
  // and a recovery would silently run as a new replacement.
  const BOOLEAN_FLAGS = ['--recover', '--relaunch'];
  const VALUE_FLAGS = ['--root', '--staged', '--client-pid', '--page-port', '--bridge-port', '--service'];
  const args = {};
  for (let i = 0; i < argv.length; i++) {
    const key = argv[i];
    if (BOOLEAN_FLAGS.includes(key)) { if (key in args) throw new Error('INVALID_ARGUMENT'); args[key] = true; continue; }
    if (!VALUE_FLAGS.includes(key) || key in args) throw new Error('INVALID_ARGUMENT');
    args[key] = argv[++i];
  }
  if (!args['--root'] || !args['--staged']) throw new Error('Usage: updater --root ROOT --staged INTERNAL_STAGE_ID --client-pid PID');
  const root = path.resolve(args['--root']);
  const configFile = path.join(root, 'client-update.config.json');
  if ((await fs.lstat(configFile)).isSymbolicLink()) throw new Error('SYMLINK_CONFIG');
  const config = JSON.parse(await fs.readFile(configFile, 'utf8'));
  const pid = Number(args['--client-pid']);
  if (!Number.isSafeInteger(pid) || pid <= 0 || pid === process.pid) throw new Error('CLIENT_PID_REQUIRED');
  const released = () => {
    try { process.kill(pid, 0); return false; } catch (e) { if (e.code === 'ESRCH') return true; throw e; }
  };
  const verifyQuiescence = async () => {
    if (!released()) return { safeToApply: false };
    if (adapters.verifyQuiescence) return adapters.verifyQuiescence();
    throw Object.assign(new Error('Trusted UI/session/process-tree adapter required; CLI does not infer zero active sessions from a dead parent PID.'), { code: 'QUIESCENCE_REQUIRED' });
  };
  // Explicit injection only, so wiring can be asserted without replacing files. The production CLI
  // and client-update-apply.mjs never pass adapters, so config/env can never reach this seam.
  const createManager = typeof adapters.testing?.createUpdateManager === 'function'
    ? adapters.testing.createUpdateManager
    : createUpdateManager;
  const manager = createManager({
    root, feedUrl: config.feedUrl, publicKey: config.publicKey, channel: config.channel,
    currentVersion: config.currentVersion, allowedPaths: config.allowedPaths,
    limits: config.limits, packageRoot: config.packageRoot, preservePaths: config.preservePaths,
    tokenFile: config.tokenFile, authHeader: config.authHeader, authScheme: config.authScheme,
    packageOrigins: config.packageOrigins, packageTokenFile: config.packageTokenFile,
    packageAuthHeader: config.packageAuthHeader, packageAuthScheme: config.packageAuthScheme,
    // Incremental delivery is opt-in per installation: only a literal true in the trusted local
    // config turns it on (index.mjs:289 wants options.deltaApply === true); anything else is left
    // unset so a config that never mentions the field keeps the full-only path unchanged.
    ...(config.deltaApply === true ? { deltaApply: true } : {}),
    // Bounded retention of failed-rollback debris is an operator knob, not a policy the updater may
    // invent: an absent or non-integer field keeps the manager's own default (index.mjs reclaim).
    ...(Number.isSafeInteger(config.failedRetention) && config.failedRetention >= 0 ? { failedRetention: config.failedRetention } : {}),
    ...(Number.isSafeInteger(config.orphanStageGraceMs) && config.orphanStageGraceMs >= 0 ? { orphanStageGraceMs: config.orphanStageGraceMs } : {}),
    // The baseline is an identity, not just a hash: the manifest written at commit names the
    // product/endpoint it belongs to, so an internal installation must pass its own endpoint
    // through. Without this an internal client records an external baseline and no internal
    // patch can ever match it (silent fallback to full, forever).
    ...(typeof config.endpoint === 'string' && config.endpoint ? { endpoint: config.endpoint } : {}),
    ...(typeof config.product === 'string' && config.product ? { product: config.product } : {}),
    // Test HTTP is explicit injection only; the production CLI never supplies adapters.
    testOnlyAllowHttp: adapters.testing?.allowHttp === true, independentUpdater: true,
    isBusy: async () => !released() || (adapters.isBusy ? await adapters.isBusy() : false), verifyQuiescence,
    // Post-switch health proof and the itemized package manifest are injected by the production
    // applier only; a caller that supplies none keeps the previous behaviour unchanged.
    ...(typeof adapters.healthCheck === 'function' ? { healthCheck: adapters.healthCheck, requireHealthCheck: adapters.requireHealthCheck === true } : {}),
    ...(adapters.requireItemizedManifest === true ? { requireItemizedManifest: true } : {}),
  });
  // Recovery takes the same trusted proof but undoes the interrupted transaction instead of
  // starting a new one; a stage id is still needed to name the files the switch would move.
  if (args['--recover'] === true) return manager.recover();
  return manager.apply(args['--staged']);
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  runUpdater(process.argv.slice(2)).then(result => console.log(JSON.stringify(result))).catch(e => { console.error(JSON.stringify({ error: e.code ?? e.message })); process.exitCode = 1; });
}

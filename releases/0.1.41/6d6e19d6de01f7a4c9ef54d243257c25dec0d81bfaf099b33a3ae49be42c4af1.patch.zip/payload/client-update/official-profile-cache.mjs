import fs from 'node:fs';
import path from 'node:path';
import { lookup as dnsLookup } from 'node:dns';
import { OFFICIAL_SOURCE, MAX_SCRIPT_BYTES, parseOfficialOnlineJs, validateSnapshot, publicGameHost } from './official-online-profiles.mjs';

// Validate the actual DNS answers used by net.connect, not a separate preliminary lookup.
export function createPublicLookup(lookup = dnsLookup) {
  return function (host, options, callback) {
    lookup(host, { family: 4, all: true }, (error, entries) => {
      if (error) return callback(error);
      if (!entries.length || entries.some(entry => !publicGameHost(entry.address))) {
        return callback(new Error('Official game target resolved to a non-public address'));
      }
      return options.all ? callback(null, entries) : callback(null, entries[0].address, entries[0].family);
    });
  };
}

/** Fixed HTTPS data-only downloader. No caller-supplied URLs, redirects or credentials. */
export function createOfficialProfileCache({ cacheFile, fetcher = fetch, log = () => {} }) {
  let snapshot = null;
  let inFlight = null;
  let previous = null;
  let previousUntil = 0;
  let lastError = null;
  try { snapshot = validateSnapshot(JSON.parse(fs.readFileSync(cacheFile, 'utf8'))); } catch { /* static fallback */ }
  const current = () => validateSnapshot(snapshot);
  const state = () => ({ source: OFFICIAL_SOURCE, snapshot: current(), refreshing: Boolean(inFlight), lastError });
  function refresh() {
    if (inFlight) return inFlight;
    inFlight = (async () => {
      const response = await fetcher(OFFICIAL_SOURCE, {
        redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(8000)
      });
      if (!response.ok) throw new Error('Official profile HTTP ' + response.status);
      if (Number(response.headers.get('content-length')) > MAX_SCRIPT_BYTES) throw new Error('Official profile safety limit');
      const reader = response.body.getReader();
      const chunks = [];
      let bytes = 0;
      try {
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          bytes += value.byteLength;
          if (bytes > MAX_SCRIPT_BYTES) throw new Error('Official profile safety limit');
          chunks.push(Buffer.from(value));
        }
      } finally { await reader.cancel().catch(() => {}); }
      const parsed = parseOfficialOnlineJs(Buffer.concat(chunks).toString('utf8'));
      // Commit only after full parse + validation. Disk failure retains the previous cache.
      fs.mkdirSync(path.dirname(cacheFile), { recursive: true });
      const temp = cacheFile + '.tmp';
      try {
        fs.writeFileSync(temp, JSON.stringify(parsed) + '\n');
        fs.renameSync(temp, cacheFile);
      } finally { fs.rmSync(temp, { force: true }); }
      previous = current();
      previousUntil = Date.now() + 60000;
      snapshot = parsed;
      lastError = null;
      log('官方线路数据刷新完成：' + Object.keys(parsed.servers).join(', '));
      return { ...state(), refreshing: false };
    })().catch(error => {
      lastError = error.message;
      log('官方线路刷新失败，保留缓存/部署配置：' + lastError);
      return { ...state(), refreshing: false };
    }).finally(() => { inFlight = null; });
    return inFlight;
  }
  function allows(host, port) {
    const generations = [current(), Date.now() < previousUntil ? validateSnapshot(previous) : null].filter(Boolean);
    return generations.some(data => Object.values(data.servers).some(entry => entry.address === host &&
      (entry.port === Number(port) || [24322, 24323].includes(Number(port)))));
  }
  function privateTarget(port, fallback) {
    const data = current();
    if (!data) return fallback;
    const entries = Object.values(data.servers).filter(entry =>
      entry.port === Number(port) || [24322, 24323].includes(Number(port)));
    const hosts = [...new Set(entries.map(entry => entry.address))];
    // Without per-session identity, never guess across distinct official hosts.
    return hosts.length === 1 ? hosts[0] : (hosts.length ? null : fallback);
  }
  return { current, state, refresh, allows, privateTarget, lookup: createPublicLookup() };
}
